Option Strict Off
Option Explicit On
Friend Class frmCust
	Inherits System.Windows.Forms.Form
#Region "Windows Form Designer generated code "
	Public Sub New()
		MyBase.New()
		If m_vb6FormDefInstance Is Nothing Then
			If m_InitializingDefInstance Then
				m_vb6FormDefInstance = Me
			Else
				Try 
					'For the start-up form, the first instance created is the default instance.
					If System.Reflection.Assembly.GetExecutingAssembly.EntryPoint.DeclaringType Is Me.GetType Then
						m_vb6FormDefInstance = Me
					End If
				Catch
				End Try
			End If
		End If
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents txtPhone As System.Windows.Forms.TextBox
	Public WithEvents txtFax As System.Windows.Forms.TextBox
	Public WithEvents txtCountry As System.Windows.Forms.TextBox
	Public WithEvents txtState As System.Windows.Forms.TextBox
	Public WithEvents txtCity As System.Windows.Forms.TextBox
	Public WithEvents txtAddress As System.Windows.Forms.TextBox
	Public WithEvents txtContact As System.Windows.Forms.TextBox
	Public WithEvents txtCompany As System.Windows.Forms.TextBox
	Public WithEvents cmdExit As System.Windows.Forms.Label
	Public WithEvents cmdNext As System.Windows.Forms.Label
	Public WithEvents Label12 As System.Windows.Forms.Label
	Public WithEvents Label11 As System.Windows.Forms.Label
	Public WithEvents Label9 As System.Windows.Forms.Label
	Public WithEvents Label8 As System.Windows.Forms.Label
	Public WithEvents Label7 As System.Windows.Forms.Label
	Public WithEvents Label6 As System.Windows.Forms.Label
	Public WithEvents Label5 As System.Windows.Forms.Label
	Public WithEvents Label4 As System.Windows.Forms.Label
	Public WithEvents Label3 As System.Windows.Forms.Label
	Public WithEvents Label2 As System.Windows.Forms.Label
	Public WithEvents Label1 As System.Windows.Forms.Label
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmCust))
		Me.components = New System.ComponentModel.Container()
		Me.ToolTip1 = New System.Windows.Forms.ToolTip(components)
		Me.ToolTip1.Active = True
		Me.txtPhone = New System.Windows.Forms.TextBox
		Me.txtFax = New System.Windows.Forms.TextBox
		Me.txtCountry = New System.Windows.Forms.TextBox
		Me.txtState = New System.Windows.Forms.TextBox
		Me.txtCity = New System.Windows.Forms.TextBox
		Me.txtAddress = New System.Windows.Forms.TextBox
		Me.txtContact = New System.Windows.Forms.TextBox
		Me.txtCompany = New System.Windows.Forms.TextBox
		Me.cmdExit = New System.Windows.Forms.Label
		Me.cmdNext = New System.Windows.Forms.Label
		Me.Label12 = New System.Windows.Forms.Label
		Me.Label11 = New System.Windows.Forms.Label
		Me.Label9 = New System.Windows.Forms.Label
		Me.Label8 = New System.Windows.Forms.Label
		Me.Label7 = New System.Windows.Forms.Label
		Me.Label6 = New System.Windows.Forms.Label
		Me.Label5 = New System.Windows.Forms.Label
		Me.Label4 = New System.Windows.Forms.Label
		Me.Label3 = New System.Windows.Forms.Label
		Me.Label2 = New System.Windows.Forms.Label
		Me.Label1 = New System.Windows.Forms.Label
		Me.Text = "Client Information"
		Me.ClientSize = New System.Drawing.Size(775, 523)
		Me.Location = New System.Drawing.Point(4, 30)
		Me.Font = New System.Drawing.Font("Arial", 12!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.MaximizeBox = False
		Me.BackgroundImage = CType(resources.GetObject("frmCust.BackgroundImage"), System.Drawing.Image)
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
		Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
		Me.BackColor = System.Drawing.SystemColors.Control
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Sizable
		Me.ControlBox = True
		Me.Enabled = True
		Me.KeyPreview = False
		Me.MinimizeBox = True
		Me.Cursor = System.Windows.Forms.Cursors.Default
		Me.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.ShowInTaskbar = True
		Me.HelpButton = False
		Me.WindowState = System.Windows.Forms.FormWindowState.Normal
		Me.Name = "frmCust"
		Me.txtPhone.AutoSize = False
		Me.txtPhone.Size = New System.Drawing.Size(257, 26)
		Me.txtPhone.Location = New System.Drawing.Point(112, 360)
		Me.txtPhone.TabIndex = 6
		Me.txtPhone.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtPhone.AcceptsReturn = True
		Me.txtPhone.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtPhone.BackColor = System.Drawing.SystemColors.Window
		Me.txtPhone.CausesValidation = True
		Me.txtPhone.Enabled = True
		Me.txtPhone.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtPhone.HideSelection = True
		Me.txtPhone.ReadOnly = False
		Me.txtPhone.Maxlength = 0
		Me.txtPhone.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtPhone.MultiLine = False
		Me.txtPhone.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtPhone.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtPhone.TabStop = True
		Me.txtPhone.Visible = True
		Me.txtPhone.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtPhone.Name = "txtPhone"
		Me.txtFax.AutoSize = False
		Me.txtFax.Size = New System.Drawing.Size(257, 26)
		Me.txtFax.Location = New System.Drawing.Point(488, 360)
		Me.txtFax.TabIndex = 7
		Me.txtFax.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtFax.AcceptsReturn = True
		Me.txtFax.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtFax.BackColor = System.Drawing.SystemColors.Window
		Me.txtFax.CausesValidation = True
		Me.txtFax.Enabled = True
		Me.txtFax.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtFax.HideSelection = True
		Me.txtFax.ReadOnly = False
		Me.txtFax.Maxlength = 0
		Me.txtFax.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtFax.MultiLine = False
		Me.txtFax.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtFax.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtFax.TabStop = True
		Me.txtFax.Visible = True
		Me.txtFax.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtFax.Name = "txtFax"
		Me.txtCountry.AutoSize = False
		Me.txtCountry.Size = New System.Drawing.Size(257, 26)
		Me.txtCountry.Location = New System.Drawing.Point(488, 304)
		Me.txtCountry.TabIndex = 5
		Me.txtCountry.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtCountry.AcceptsReturn = True
		Me.txtCountry.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtCountry.BackColor = System.Drawing.SystemColors.Window
		Me.txtCountry.CausesValidation = True
		Me.txtCountry.Enabled = True
		Me.txtCountry.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtCountry.HideSelection = True
		Me.txtCountry.ReadOnly = False
		Me.txtCountry.Maxlength = 0
		Me.txtCountry.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtCountry.MultiLine = False
		Me.txtCountry.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtCountry.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtCountry.TabStop = True
		Me.txtCountry.Visible = True
		Me.txtCountry.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtCountry.Name = "txtCountry"
		Me.txtState.AutoSize = False
		Me.txtState.Size = New System.Drawing.Size(257, 26)
		Me.txtState.Location = New System.Drawing.Point(112, 304)
		Me.txtState.TabIndex = 4
		Me.txtState.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtState.AcceptsReturn = True
		Me.txtState.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtState.BackColor = System.Drawing.SystemColors.Window
		Me.txtState.CausesValidation = True
		Me.txtState.Enabled = True
		Me.txtState.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtState.HideSelection = True
		Me.txtState.ReadOnly = False
		Me.txtState.Maxlength = 0
		Me.txtState.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtState.MultiLine = False
		Me.txtState.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtState.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtState.TabStop = True
		Me.txtState.Visible = True
		Me.txtState.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtState.Name = "txtState"
		Me.txtCity.AutoSize = False
		Me.txtCity.Size = New System.Drawing.Size(257, 26)
		Me.txtCity.Location = New System.Drawing.Point(488, 248)
		Me.txtCity.TabIndex = 3
		Me.txtCity.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtCity.AcceptsReturn = True
		Me.txtCity.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtCity.BackColor = System.Drawing.SystemColors.Window
		Me.txtCity.CausesValidation = True
		Me.txtCity.Enabled = True
		Me.txtCity.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtCity.HideSelection = True
		Me.txtCity.ReadOnly = False
		Me.txtCity.Maxlength = 0
		Me.txtCity.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtCity.MultiLine = False
		Me.txtCity.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtCity.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtCity.TabStop = True
		Me.txtCity.Visible = True
		Me.txtCity.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtCity.Name = "txtCity"
		Me.txtAddress.AutoSize = False
		Me.txtAddress.Size = New System.Drawing.Size(257, 26)
		Me.txtAddress.Location = New System.Drawing.Point(112, 248)
		Me.txtAddress.MultiLine = True
		Me.txtAddress.TabIndex = 2
		Me.txtAddress.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtAddress.AcceptsReturn = True
		Me.txtAddress.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtAddress.BackColor = System.Drawing.SystemColors.Window
		Me.txtAddress.CausesValidation = True
		Me.txtAddress.Enabled = True
		Me.txtAddress.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtAddress.HideSelection = True
		Me.txtAddress.ReadOnly = False
		Me.txtAddress.Maxlength = 0
		Me.txtAddress.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtAddress.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtAddress.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtAddress.TabStop = True
		Me.txtAddress.Visible = True
		Me.txtAddress.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtAddress.Name = "txtAddress"
		Me.txtContact.AutoSize = False
		Me.txtContact.Size = New System.Drawing.Size(257, 26)
		Me.txtContact.Location = New System.Drawing.Point(488, 192)
		Me.txtContact.TabIndex = 1
		Me.txtContact.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtContact.AcceptsReturn = True
		Me.txtContact.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtContact.BackColor = System.Drawing.SystemColors.Window
		Me.txtContact.CausesValidation = True
		Me.txtContact.Enabled = True
		Me.txtContact.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtContact.HideSelection = True
		Me.txtContact.ReadOnly = False
		Me.txtContact.Maxlength = 0
		Me.txtContact.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtContact.MultiLine = False
		Me.txtContact.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtContact.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtContact.TabStop = True
		Me.txtContact.Visible = True
		Me.txtContact.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtContact.Name = "txtContact"
		Me.txtCompany.AutoSize = False
		Me.txtCompany.Size = New System.Drawing.Size(257, 26)
		Me.txtCompany.Location = New System.Drawing.Point(112, 192)
		Me.txtCompany.TabIndex = 0
		Me.txtCompany.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtCompany.AcceptsReturn = True
		Me.txtCompany.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtCompany.BackColor = System.Drawing.SystemColors.Window
		Me.txtCompany.CausesValidation = True
		Me.txtCompany.Enabled = True
		Me.txtCompany.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtCompany.HideSelection = True
		Me.txtCompany.ReadOnly = False
		Me.txtCompany.Maxlength = 0
		Me.txtCompany.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtCompany.MultiLine = False
		Me.txtCompany.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtCompany.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtCompany.TabStop = True
		Me.txtCompany.Visible = True
		Me.txtCompany.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtCompany.Name = "txtCompany"
		Me.cmdExit.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me.cmdExit.Text = "E&xit"
		Me.cmdExit.Font = New System.Drawing.Font("Arial", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmdExit.ForeColor = System.Drawing.Color.White
		Me.cmdExit.Size = New System.Drawing.Size(121, 25)
		Me.cmdExit.Location = New System.Drawing.Point(424, 495)
		Me.cmdExit.TabIndex = 20
		Me.cmdExit.BackColor = System.Drawing.Color.Transparent
		Me.cmdExit.Enabled = True
		Me.cmdExit.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdExit.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdExit.UseMnemonic = True
		Me.cmdExit.Visible = True
		Me.cmdExit.AutoSize = False
		Me.cmdExit.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.cmdExit.Name = "cmdExit"
		Me.cmdNext.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me.cmdNext.Text = "&Next"
		Me.cmdNext.Font = New System.Drawing.Font("Arial", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmdNext.ForeColor = System.Drawing.Color.White
		Me.cmdNext.Size = New System.Drawing.Size(113, 25)
		Me.cmdNext.Location = New System.Drawing.Point(240, 495)
		Me.cmdNext.TabIndex = 19
		Me.cmdNext.BackColor = System.Drawing.Color.Transparent
		Me.cmdNext.Enabled = True
		Me.cmdNext.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdNext.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdNext.UseMnemonic = True
		Me.cmdNext.Visible = True
		Me.cmdNext.AutoSize = False
		Me.cmdNext.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.cmdNext.Name = "cmdNext"
		Me.Label12.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me.Label12.Text = "PILOT INTERNATIONAL"
		Me.Label12.Font = New System.Drawing.Font("Arial", 24!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label12.ForeColor = System.Drawing.Color.White
		Me.Label12.Size = New System.Drawing.Size(521, 41)
		Me.Label12.Location = New System.Drawing.Point(152, 8)
		Me.Label12.TabIndex = 18
		Me.Label12.BackColor = System.Drawing.Color.Transparent
		Me.Label12.Enabled = True
		Me.Label12.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label12.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label12.UseMnemonic = True
		Me.Label12.Visible = True
		Me.Label12.AutoSize = False
		Me.Label12.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label12.Name = "Label12"
		Me.Label11.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me.Label11.Text = "Bid Calculations"
		Me.Label11.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label11.ForeColor = System.Drawing.Color.White
		Me.Label11.Size = New System.Drawing.Size(521, 33)
		Me.Label11.Location = New System.Drawing.Point(152, 48)
		Me.Label11.TabIndex = 17
		Me.Label11.BackColor = System.Drawing.Color.Transparent
		Me.Label11.Enabled = True
		Me.Label11.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label11.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label11.UseMnemonic = True
		Me.Label11.Visible = True
		Me.Label11.AutoSize = False
		Me.Label11.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label11.Name = "Label11"
		Me.Label9.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me.Label9.Text = "Client Information"
		Me.Label9.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label9.ForeColor = System.Drawing.Color.White
		Me.Label9.Size = New System.Drawing.Size(777, 25)
		Me.Label9.Location = New System.Drawing.Point(0, 128)
		Me.Label9.TabIndex = 16
		Me.Label9.BackColor = System.Drawing.Color.Transparent
		Me.Label9.Enabled = True
		Me.Label9.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label9.UseMnemonic = True
		Me.Label9.Visible = True
		Me.Label9.AutoSize = False
		Me.Label9.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label9.Name = "Label9"
		Me.Label8.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label8.Text = "Phone:"
		Me.Label8.Font = New System.Drawing.Font("Arial", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label8.ForeColor = System.Drawing.Color.White
		Me.Label8.Size = New System.Drawing.Size(81, 17)
		Me.Label8.Location = New System.Drawing.Point(24, 368)
		Me.Label8.TabIndex = 15
		Me.Label8.BackColor = System.Drawing.Color.Transparent
		Me.Label8.Enabled = True
		Me.Label8.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label8.UseMnemonic = True
		Me.Label8.Visible = True
		Me.Label8.AutoSize = False
		Me.Label8.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label8.Name = "Label8"
		Me.Label7.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label7.Text = "Fax:"
		Me.Label7.Font = New System.Drawing.Font("Arial", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label7.ForeColor = System.Drawing.Color.White
		Me.Label7.Size = New System.Drawing.Size(81, 17)
		Me.Label7.Location = New System.Drawing.Point(400, 368)
		Me.Label7.TabIndex = 14
		Me.Label7.BackColor = System.Drawing.Color.Transparent
		Me.Label7.Enabled = True
		Me.Label7.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label7.UseMnemonic = True
		Me.Label7.Visible = True
		Me.Label7.AutoSize = False
		Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label7.Name = "Label7"
		Me.Label6.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label6.Text = "Country:"
		Me.Label6.Font = New System.Drawing.Font("Arial", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label6.ForeColor = System.Drawing.Color.White
		Me.Label6.Size = New System.Drawing.Size(81, 17)
		Me.Label6.Location = New System.Drawing.Point(400, 312)
		Me.Label6.TabIndex = 13
		Me.Label6.BackColor = System.Drawing.Color.Transparent
		Me.Label6.Enabled = True
		Me.Label6.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label6.UseMnemonic = True
		Me.Label6.Visible = True
		Me.Label6.AutoSize = False
		Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label6.Name = "Label6"
		Me.Label5.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label5.Text = "State:"
		Me.Label5.Font = New System.Drawing.Font("Arial", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label5.ForeColor = System.Drawing.Color.White
		Me.Label5.Size = New System.Drawing.Size(81, 17)
		Me.Label5.Location = New System.Drawing.Point(24, 312)
		Me.Label5.TabIndex = 12
		Me.Label5.BackColor = System.Drawing.Color.Transparent
		Me.Label5.Enabled = True
		Me.Label5.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label5.UseMnemonic = True
		Me.Label5.Visible = True
		Me.Label5.AutoSize = False
		Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label5.Name = "Label5"
		Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label4.Text = "City:"
		Me.Label4.Font = New System.Drawing.Font("Arial", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label4.ForeColor = System.Drawing.Color.White
		Me.Label4.Size = New System.Drawing.Size(81, 17)
		Me.Label4.Location = New System.Drawing.Point(400, 256)
		Me.Label4.TabIndex = 11
		Me.Label4.BackColor = System.Drawing.Color.Transparent
		Me.Label4.Enabled = True
		Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label4.UseMnemonic = True
		Me.Label4.Visible = True
		Me.Label4.AutoSize = False
		Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label4.Name = "Label4"
		Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label3.Text = "Address:"
		Me.Label3.Font = New System.Drawing.Font("Arial", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label3.ForeColor = System.Drawing.Color.White
		Me.Label3.Size = New System.Drawing.Size(81, 17)
		Me.Label3.Location = New System.Drawing.Point(24, 256)
		Me.Label3.TabIndex = 10
		Me.Label3.BackColor = System.Drawing.Color.Transparent
		Me.Label3.Enabled = True
		Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label3.UseMnemonic = True
		Me.Label3.Visible = True
		Me.Label3.AutoSize = False
		Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label3.Name = "Label3"
		Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label2.Text = "Contact:"
		Me.Label2.Font = New System.Drawing.Font("Arial", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label2.ForeColor = System.Drawing.Color.White
		Me.Label2.Size = New System.Drawing.Size(81, 17)
		Me.Label2.Location = New System.Drawing.Point(400, 200)
		Me.Label2.TabIndex = 9
		Me.Label2.BackColor = System.Drawing.Color.Transparent
		Me.Label2.Enabled = True
		Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label2.UseMnemonic = True
		Me.Label2.Visible = True
		Me.Label2.AutoSize = False
		Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label2.Name = "Label2"
		Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label1.Text = "Company:"
		Me.Label1.Font = New System.Drawing.Font("Arial", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label1.ForeColor = System.Drawing.Color.White
		Me.Label1.Size = New System.Drawing.Size(89, 17)
		Me.Label1.Location = New System.Drawing.Point(16, 200)
		Me.Label1.TabIndex = 8
		Me.Label1.BackColor = System.Drawing.Color.Transparent
		Me.Label1.Enabled = True
		Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label1.UseMnemonic = True
		Me.Label1.Visible = True
		Me.Label1.AutoSize = False
		Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label1.Name = "Label1"
		Me.Controls.Add(txtPhone)
		Me.Controls.Add(txtFax)
		Me.Controls.Add(txtCountry)
		Me.Controls.Add(txtState)
		Me.Controls.Add(txtCity)
		Me.Controls.Add(txtAddress)
		Me.Controls.Add(txtContact)
		Me.Controls.Add(txtCompany)
		Me.Controls.Add(cmdExit)
		Me.Controls.Add(cmdNext)
		Me.Controls.Add(Label12)
		Me.Controls.Add(Label11)
		Me.Controls.Add(Label9)
		Me.Controls.Add(Label8)
		Me.Controls.Add(Label7)
		Me.Controls.Add(Label6)
		Me.Controls.Add(Label5)
		Me.Controls.Add(Label4)
		Me.Controls.Add(Label3)
		Me.Controls.Add(Label2)
		Me.Controls.Add(Label1)
	End Sub
#End Region 
#Region "Upgrade Support "
	Private Shared m_vb6FormDefInstance As frmCust
	Private Shared m_InitializingDefInstance As Boolean
	Public Shared Property DefInstance() As frmCust
		Get
			If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
				m_InitializingDefInstance = True
				m_vb6FormDefInstance = New frmCust()
				m_InitializingDefInstance = False
			End If
			DefInstance = m_vb6FormDefInstance
		End Get
		Set
			m_vb6FormDefInstance = Value
		End Set
	End Property
#End Region 
	
	Private Sub cmdExit_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdExit.Click
		End
	End Sub
	
	Private Sub cmdNext_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdNext.Click
		frmBidCalc1.DefInstance.Show()
		frmCust.DefInstance.Hide()
	End Sub
	
	'UPGRADE_WARNING: Form event frmCust.Unload has a new behavior. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2065"'
	Private Sub frmCust_Closed(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Closed
		End
	End Sub
End Class