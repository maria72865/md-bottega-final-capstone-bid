Option Strict Off
Option Explicit On
Friend Class frmBidPrint
	Inherits System.Windows.Forms.Form
#Region "Windows Form Designer generated code "
	Public Sub New()
		MyBase.New()
		If m_vb6FormDefInstance Is Nothing Then
			If m_InitializingDefInstance Then
				m_vb6FormDefInstance = Me
			Else
				Try 
					'For the start-up form, the first instance created is the default instance.
					If System.Reflection.Assembly.GetExecutingAssembly.EntryPoint.DeclaringType Is Me.GetType Then
						m_vb6FormDefInstance = Me
					End If
				Catch
				End Try
			End If
		End If
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents txtRadio As System.Windows.Forms.TextBox
	Public WithEvents txtTank As System.Windows.Forms.TextBox
	Public WithEvents txtInsurance As System.Windows.Forms.TextBox
	Public WithEvents txtBidInsTotal As System.Windows.Forms.TextBox
	Public WithEvents txtBidTotal As System.Windows.Forms.TextBox
	Public WithEvents txtDest As System.Windows.Forms.TextBox
	Public WithEvents txtAC As System.Windows.Forms.TextBox
	Public WithEvents txtDate As System.Windows.Forms.TextBox
	Public WithEvents txtOrigin As System.Windows.Forms.TextBox
	Public WithEvents txtContact As System.Windows.Forms.TextBox
	Public WithEvents txtClient As System.Windows.Forms.TextBox
	Public WithEvents txtPerDiem As System.Windows.Forms.TextBox
	Public WithEvents txtDaysAway As System.Windows.Forms.TextBox
	Public WithEvents txtCrew1 As System.Windows.Forms.TextBox
	Public WithEvents txtCrewPD1 As System.Windows.Forms.TextBox
	Public WithEvents txtAF1 As System.Windows.Forms.TextBox
	Public WithEvents txtLanding As System.Windows.Forms.TextBox
	Public WithEvents txtCustoms As System.Windows.Forms.TextBox
	Public WithEvents txtCustComm As System.Windows.Forms.TextBox
	Public WithEvents txtER As System.Windows.Forms.TextBox
	Public WithEvents txtTotalFuelCost As System.Windows.Forms.TextBox
	Public WithEvents cmdPrint As System.Windows.Forms.Button
	Public WithEvents Label13 As System.Windows.Forms.Label
	Public WithEvents Label12 As System.Windows.Forms.Label
	Public WithEvents Label11 As System.Windows.Forms.Label
	Public WithEvents Label10 As System.Windows.Forms.Label
	Public WithEvents Label2 As System.Windows.Forms.Label
	Public WithEvents Label9 As System.Windows.Forms.Label
	Public WithEvents Line1 As System.Windows.Forms.Label
	Public WithEvents Label14 As System.Windows.Forms.Label
	Public WithEvents Label15 As System.Windows.Forms.Label
	Public WithEvents Label16 As System.Windows.Forms.Label
	Public WithEvents Label17 As System.Windows.Forms.Label
	Public WithEvents Label18 As System.Windows.Forms.Label
	Public WithEvents Label19 As System.Windows.Forms.Label
	Public WithEvents Label20 As System.Windows.Forms.Label
	Public WithEvents Label21 As System.Windows.Forms.Label
	Public WithEvents Label22 As System.Windows.Forms.Label
	Public WithEvents Label24 As System.Windows.Forms.Label
	Public WithEvents Label8 As System.Windows.Forms.Label
	Public WithEvents Label7 As System.Windows.Forms.Label
	Public WithEvents Label6 As System.Windows.Forms.Label
	Public WithEvents Label5 As System.Windows.Forms.Label
	Public WithEvents Label4 As System.Windows.Forms.Label
	Public WithEvents Label3 As System.Windows.Forms.Label
	Public WithEvents Label1 As System.Windows.Forms.Label
	Public WithEvents Picture1 As System.Windows.Forms.Panel
	Public WithEvents Picture2 As System.Windows.Forms.PictureBox
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmBidPrint))
		Me.components = New System.ComponentModel.Container()
		Me.ToolTip1 = New System.Windows.Forms.ToolTip(components)
		Me.ToolTip1.Active = True
		Me.Picture1 = New System.Windows.Forms.Panel
		Me.txtRadio = New System.Windows.Forms.TextBox
		Me.txtTank = New System.Windows.Forms.TextBox
		Me.txtInsurance = New System.Windows.Forms.TextBox
		Me.txtBidInsTotal = New System.Windows.Forms.TextBox
		Me.txtBidTotal = New System.Windows.Forms.TextBox
		Me.txtDest = New System.Windows.Forms.TextBox
		Me.txtAC = New System.Windows.Forms.TextBox
		Me.txtDate = New System.Windows.Forms.TextBox
		Me.txtOrigin = New System.Windows.Forms.TextBox
		Me.txtContact = New System.Windows.Forms.TextBox
		Me.txtClient = New System.Windows.Forms.TextBox
		Me.txtPerDiem = New System.Windows.Forms.TextBox
		Me.txtDaysAway = New System.Windows.Forms.TextBox
		Me.txtCrew1 = New System.Windows.Forms.TextBox
		Me.txtCrewPD1 = New System.Windows.Forms.TextBox
		Me.txtAF1 = New System.Windows.Forms.TextBox
		Me.txtLanding = New System.Windows.Forms.TextBox
		Me.txtCustoms = New System.Windows.Forms.TextBox
		Me.txtCustComm = New System.Windows.Forms.TextBox
		Me.txtER = New System.Windows.Forms.TextBox
		Me.txtTotalFuelCost = New System.Windows.Forms.TextBox
		Me.cmdPrint = New System.Windows.Forms.Button
		Me.Label13 = New System.Windows.Forms.Label
		Me.Label12 = New System.Windows.Forms.Label
		Me.Label11 = New System.Windows.Forms.Label
		Me.Label10 = New System.Windows.Forms.Label
		Me.Label2 = New System.Windows.Forms.Label
		Me.Label9 = New System.Windows.Forms.Label
		Me.Line1 = New System.Windows.Forms.Label
		Me.Label14 = New System.Windows.Forms.Label
		Me.Label15 = New System.Windows.Forms.Label
		Me.Label16 = New System.Windows.Forms.Label
		Me.Label17 = New System.Windows.Forms.Label
		Me.Label18 = New System.Windows.Forms.Label
		Me.Label19 = New System.Windows.Forms.Label
		Me.Label20 = New System.Windows.Forms.Label
		Me.Label21 = New System.Windows.Forms.Label
		Me.Label22 = New System.Windows.Forms.Label
		Me.Label24 = New System.Windows.Forms.Label
		Me.Label8 = New System.Windows.Forms.Label
		Me.Label7 = New System.Windows.Forms.Label
		Me.Label6 = New System.Windows.Forms.Label
		Me.Label5 = New System.Windows.Forms.Label
		Me.Label4 = New System.Windows.Forms.Label
		Me.Label3 = New System.Windows.Forms.Label
		Me.Label1 = New System.Windows.Forms.Label
		Me.Picture2 = New System.Windows.Forms.PictureBox
		Me.BackColor = System.Drawing.Color.White
		Me.Text = "Bid Print"
		Me.ClientSize = New System.Drawing.Size(790, 566)
		Me.Location = New System.Drawing.Point(11, 37)
		Me.Font = New System.Drawing.Font("Arial", 12!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
		Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Sizable
		Me.ControlBox = True
		Me.Enabled = True
		Me.KeyPreview = False
		Me.MaximizeBox = True
		Me.MinimizeBox = True
		Me.Cursor = System.Windows.Forms.Cursors.Default
		Me.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.ShowInTaskbar = True
		Me.HelpButton = False
		Me.WindowState = System.Windows.Forms.FormWindowState.Normal
		Me.Name = "frmBidPrint"
		Me.Picture1.BackColor = System.Drawing.SystemColors.ActiveCaptionText
		Me.Picture1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Picture1.Size = New System.Drawing.Size(757, 1209)
		Me.Picture1.Location = New System.Drawing.Point(8, -408)
		Me.Picture1.BackgroundImage = CType(resources.GetObject("Picture1.BackgroundImage"), System.Drawing.Image)
		Me.Picture1.TabIndex = 0
		Me.Picture1.Dock = System.Windows.Forms.DockStyle.None
		Me.Picture1.CausesValidation = True
		Me.Picture1.Enabled = True
		Me.Picture1.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Picture1.Cursor = System.Windows.Forms.Cursors.Default
		Me.Picture1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Picture1.TabStop = True
		Me.Picture1.Visible = True
		Me.Picture1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.Picture1.Name = "Picture1"
		Me.txtRadio.AutoSize = False
		Me.txtRadio.Size = New System.Drawing.Size(201, 26)
		Me.txtRadio.Location = New System.Drawing.Point(496, 736)
		Me.txtRadio.TabIndex = 46
		Me.txtRadio.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtRadio.AcceptsReturn = True
		Me.txtRadio.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtRadio.BackColor = System.Drawing.SystemColors.Window
		Me.txtRadio.CausesValidation = True
		Me.txtRadio.Enabled = True
		Me.txtRadio.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtRadio.HideSelection = True
		Me.txtRadio.ReadOnly = False
		Me.txtRadio.Maxlength = 0
		Me.txtRadio.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtRadio.MultiLine = False
		Me.txtRadio.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtRadio.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtRadio.TabStop = True
		Me.txtRadio.Visible = True
		Me.txtRadio.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtRadio.Name = "txtRadio"
		Me.txtTank.AutoSize = False
		Me.txtTank.Size = New System.Drawing.Size(201, 26)
		Me.txtTank.Location = New System.Drawing.Point(496, 688)
		Me.txtTank.TabIndex = 45
		Me.txtTank.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtTank.AcceptsReturn = True
		Me.txtTank.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtTank.BackColor = System.Drawing.SystemColors.Window
		Me.txtTank.CausesValidation = True
		Me.txtTank.Enabled = True
		Me.txtTank.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtTank.HideSelection = True
		Me.txtTank.ReadOnly = False
		Me.txtTank.Maxlength = 0
		Me.txtTank.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtTank.MultiLine = False
		Me.txtTank.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtTank.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtTank.TabStop = True
		Me.txtTank.Visible = True
		Me.txtTank.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtTank.Name = "txtTank"
		Me.txtInsurance.AutoSize = False
		Me.txtInsurance.Size = New System.Drawing.Size(201, 26)
		Me.txtInsurance.Location = New System.Drawing.Point(496, 784)
		Me.txtInsurance.TabIndex = 42
		Me.txtInsurance.Text = "0.00"
		Me.txtInsurance.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtInsurance.AcceptsReturn = True
		Me.txtInsurance.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtInsurance.BackColor = System.Drawing.SystemColors.Window
		Me.txtInsurance.CausesValidation = True
		Me.txtInsurance.Enabled = True
		Me.txtInsurance.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtInsurance.HideSelection = True
		Me.txtInsurance.ReadOnly = False
		Me.txtInsurance.Maxlength = 0
		Me.txtInsurance.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtInsurance.MultiLine = False
		Me.txtInsurance.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtInsurance.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtInsurance.TabStop = True
		Me.txtInsurance.Visible = True
		Me.txtInsurance.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtInsurance.Name = "txtInsurance"
		Me.txtBidInsTotal.AutoSize = False
		Me.txtBidInsTotal.Font = New System.Drawing.Font("Arial", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtBidInsTotal.Size = New System.Drawing.Size(145, 26)
		Me.txtBidInsTotal.Location = New System.Drawing.Point(496, 912)
		Me.txtBidInsTotal.TabIndex = 38
		Me.txtBidInsTotal.AcceptsReturn = True
		Me.txtBidInsTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtBidInsTotal.BackColor = System.Drawing.SystemColors.Window
		Me.txtBidInsTotal.CausesValidation = True
		Me.txtBidInsTotal.Enabled = True
		Me.txtBidInsTotal.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtBidInsTotal.HideSelection = True
		Me.txtBidInsTotal.ReadOnly = False
		Me.txtBidInsTotal.Maxlength = 0
		Me.txtBidInsTotal.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtBidInsTotal.MultiLine = False
		Me.txtBidInsTotal.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtBidInsTotal.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtBidInsTotal.TabStop = True
		Me.txtBidInsTotal.Visible = True
		Me.txtBidInsTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtBidInsTotal.Name = "txtBidInsTotal"
		Me.txtBidTotal.AutoSize = False
		Me.txtBidTotal.Font = New System.Drawing.Font("Arial", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtBidTotal.Size = New System.Drawing.Size(145, 26)
		Me.txtBidTotal.Location = New System.Drawing.Point(496, 872)
		Me.txtBidTotal.TabIndex = 37
		Me.txtBidTotal.AcceptsReturn = True
		Me.txtBidTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtBidTotal.BackColor = System.Drawing.SystemColors.Window
		Me.txtBidTotal.CausesValidation = True
		Me.txtBidTotal.Enabled = True
		Me.txtBidTotal.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtBidTotal.HideSelection = True
		Me.txtBidTotal.ReadOnly = False
		Me.txtBidTotal.Maxlength = 0
		Me.txtBidTotal.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtBidTotal.MultiLine = False
		Me.txtBidTotal.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtBidTotal.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtBidTotal.TabStop = True
		Me.txtBidTotal.Visible = True
		Me.txtBidTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtBidTotal.Name = "txtBidTotal"
		Me.txtDest.AutoSize = False
		Me.txtDest.Size = New System.Drawing.Size(201, 26)
		Me.txtDest.Location = New System.Drawing.Point(496, 456)
		Me.txtDest.TabIndex = 35
		Me.txtDest.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtDest.AcceptsReturn = True
		Me.txtDest.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtDest.BackColor = System.Drawing.SystemColors.Window
		Me.txtDest.CausesValidation = True
		Me.txtDest.Enabled = True
		Me.txtDest.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtDest.HideSelection = True
		Me.txtDest.ReadOnly = False
		Me.txtDest.Maxlength = 0
		Me.txtDest.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtDest.MultiLine = False
		Me.txtDest.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtDest.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtDest.TabStop = True
		Me.txtDest.Visible = True
		Me.txtDest.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtDest.Name = "txtDest"
		Me.txtAC.AutoSize = False
		Me.txtAC.Size = New System.Drawing.Size(201, 26)
		Me.txtAC.Location = New System.Drawing.Point(496, 416)
		Me.txtAC.TabIndex = 34
		Me.txtAC.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtAC.AcceptsReturn = True
		Me.txtAC.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtAC.BackColor = System.Drawing.SystemColors.Window
		Me.txtAC.CausesValidation = True
		Me.txtAC.Enabled = True
		Me.txtAC.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtAC.HideSelection = True
		Me.txtAC.ReadOnly = False
		Me.txtAC.Maxlength = 0
		Me.txtAC.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtAC.MultiLine = False
		Me.txtAC.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtAC.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtAC.TabStop = True
		Me.txtAC.Visible = True
		Me.txtAC.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtAC.Name = "txtAC"
		Me.txtDate.AutoSize = False
		Me.txtDate.Size = New System.Drawing.Size(200, 26)
		Me.txtDate.Location = New System.Drawing.Point(496, 368)
		Me.txtDate.TabIndex = 33
		Me.txtDate.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtDate.AcceptsReturn = True
		Me.txtDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtDate.BackColor = System.Drawing.SystemColors.Window
		Me.txtDate.CausesValidation = True
		Me.txtDate.Enabled = True
		Me.txtDate.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtDate.HideSelection = True
		Me.txtDate.ReadOnly = False
		Me.txtDate.Maxlength = 0
		Me.txtDate.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtDate.MultiLine = False
		Me.txtDate.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtDate.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtDate.TabStop = True
		Me.txtDate.Visible = True
		Me.txtDate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtDate.Name = "txtDate"
		Me.txtOrigin.AutoSize = False
		Me.txtOrigin.Size = New System.Drawing.Size(200, 26)
		Me.txtOrigin.Location = New System.Drawing.Point(152, 456)
		Me.txtOrigin.TabIndex = 32
		Me.txtOrigin.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtOrigin.AcceptsReturn = True
		Me.txtOrigin.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtOrigin.BackColor = System.Drawing.SystemColors.Window
		Me.txtOrigin.CausesValidation = True
		Me.txtOrigin.Enabled = True
		Me.txtOrigin.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtOrigin.HideSelection = True
		Me.txtOrigin.ReadOnly = False
		Me.txtOrigin.Maxlength = 0
		Me.txtOrigin.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtOrigin.MultiLine = False
		Me.txtOrigin.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtOrigin.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtOrigin.TabStop = True
		Me.txtOrigin.Visible = True
		Me.txtOrigin.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtOrigin.Name = "txtOrigin"
		Me.txtContact.AutoSize = False
		Me.txtContact.Size = New System.Drawing.Size(200, 26)
		Me.txtContact.Location = New System.Drawing.Point(152, 416)
		Me.txtContact.TabIndex = 31
		Me.txtContact.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtContact.AcceptsReturn = True
		Me.txtContact.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtContact.BackColor = System.Drawing.SystemColors.Window
		Me.txtContact.CausesValidation = True
		Me.txtContact.Enabled = True
		Me.txtContact.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtContact.HideSelection = True
		Me.txtContact.ReadOnly = False
		Me.txtContact.Maxlength = 0
		Me.txtContact.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtContact.MultiLine = False
		Me.txtContact.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtContact.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtContact.TabStop = True
		Me.txtContact.Visible = True
		Me.txtContact.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtContact.Name = "txtContact"
		Me.txtClient.AutoSize = False
		Me.txtClient.Size = New System.Drawing.Size(200, 26)
		Me.txtClient.Location = New System.Drawing.Point(152, 368)
		Me.txtClient.TabIndex = 30
		Me.txtClient.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtClient.AcceptsReturn = True
		Me.txtClient.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtClient.BackColor = System.Drawing.SystemColors.Window
		Me.txtClient.CausesValidation = True
		Me.txtClient.Enabled = True
		Me.txtClient.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtClient.HideSelection = True
		Me.txtClient.ReadOnly = False
		Me.txtClient.Maxlength = 0
		Me.txtClient.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtClient.MultiLine = False
		Me.txtClient.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtClient.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtClient.TabStop = True
		Me.txtClient.Visible = True
		Me.txtClient.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtClient.Name = "txtClient"
		Me.txtPerDiem.AutoSize = False
		Me.txtPerDiem.Size = New System.Drawing.Size(200, 26)
		Me.txtPerDiem.Location = New System.Drawing.Point(152, 544)
		Me.txtPerDiem.TabIndex = 19
		Me.txtPerDiem.Text = "0.00"
		Me.txtPerDiem.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtPerDiem.AcceptsReturn = True
		Me.txtPerDiem.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtPerDiem.BackColor = System.Drawing.SystemColors.Window
		Me.txtPerDiem.CausesValidation = True
		Me.txtPerDiem.Enabled = True
		Me.txtPerDiem.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtPerDiem.HideSelection = True
		Me.txtPerDiem.ReadOnly = False
		Me.txtPerDiem.Maxlength = 0
		Me.txtPerDiem.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtPerDiem.MultiLine = False
		Me.txtPerDiem.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtPerDiem.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtPerDiem.TabStop = True
		Me.txtPerDiem.Visible = True
		Me.txtPerDiem.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtPerDiem.Name = "txtPerDiem"
		Me.txtDaysAway.AutoSize = False
		Me.txtDaysAway.Size = New System.Drawing.Size(200, 26)
		Me.txtDaysAway.Location = New System.Drawing.Point(152, 592)
		Me.txtDaysAway.TabIndex = 18
		Me.txtDaysAway.Text = "0"
		Me.txtDaysAway.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtDaysAway.AcceptsReturn = True
		Me.txtDaysAway.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtDaysAway.BackColor = System.Drawing.SystemColors.Window
		Me.txtDaysAway.CausesValidation = True
		Me.txtDaysAway.Enabled = True
		Me.txtDaysAway.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtDaysAway.HideSelection = True
		Me.txtDaysAway.ReadOnly = False
		Me.txtDaysAway.Maxlength = 0
		Me.txtDaysAway.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtDaysAway.MultiLine = False
		Me.txtDaysAway.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtDaysAway.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtDaysAway.TabStop = True
		Me.txtDaysAway.Visible = True
		Me.txtDaysAway.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtDaysAway.Name = "txtDaysAway"
		Me.txtCrew1.AutoSize = False
		Me.txtCrew1.Size = New System.Drawing.Size(200, 26)
		Me.txtCrew1.Location = New System.Drawing.Point(152, 688)
		Me.txtCrew1.TabIndex = 17
		Me.txtCrew1.Text = "0.00"
		Me.txtCrew1.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtCrew1.AcceptsReturn = True
		Me.txtCrew1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtCrew1.BackColor = System.Drawing.SystemColors.Window
		Me.txtCrew1.CausesValidation = True
		Me.txtCrew1.Enabled = True
		Me.txtCrew1.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtCrew1.HideSelection = True
		Me.txtCrew1.ReadOnly = False
		Me.txtCrew1.Maxlength = 0
		Me.txtCrew1.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtCrew1.MultiLine = False
		Me.txtCrew1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtCrew1.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtCrew1.TabStop = True
		Me.txtCrew1.Visible = True
		Me.txtCrew1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtCrew1.Name = "txtCrew1"
		Me.txtCrewPD1.AutoSize = False
		Me.txtCrewPD1.Size = New System.Drawing.Size(200, 26)
		Me.txtCrewPD1.Location = New System.Drawing.Point(152, 640)
		Me.txtCrewPD1.TabIndex = 16
		Me.txtCrewPD1.Text = "0.00"
		Me.txtCrewPD1.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtCrewPD1.AcceptsReturn = True
		Me.txtCrewPD1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtCrewPD1.BackColor = System.Drawing.SystemColors.Window
		Me.txtCrewPD1.CausesValidation = True
		Me.txtCrewPD1.Enabled = True
		Me.txtCrewPD1.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtCrewPD1.HideSelection = True
		Me.txtCrewPD1.ReadOnly = False
		Me.txtCrewPD1.Maxlength = 0
		Me.txtCrewPD1.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtCrewPD1.MultiLine = False
		Me.txtCrewPD1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtCrewPD1.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtCrewPD1.TabStop = True
		Me.txtCrewPD1.Visible = True
		Me.txtCrewPD1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtCrewPD1.Name = "txtCrewPD1"
		Me.txtAF1.AutoSize = False
		Me.txtAF1.Size = New System.Drawing.Size(200, 26)
		Me.txtAF1.Location = New System.Drawing.Point(152, 736)
		Me.txtAF1.TabIndex = 15
		Me.txtAF1.Text = "0.00"
		Me.txtAF1.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtAF1.AcceptsReturn = True
		Me.txtAF1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtAF1.BackColor = System.Drawing.SystemColors.Window
		Me.txtAF1.CausesValidation = True
		Me.txtAF1.Enabled = True
		Me.txtAF1.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtAF1.HideSelection = True
		Me.txtAF1.ReadOnly = False
		Me.txtAF1.Maxlength = 0
		Me.txtAF1.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtAF1.MultiLine = False
		Me.txtAF1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtAF1.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtAF1.TabStop = True
		Me.txtAF1.Visible = True
		Me.txtAF1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtAF1.Name = "txtAF1"
		Me.txtLanding.AutoSize = False
		Me.txtLanding.Size = New System.Drawing.Size(200, 26)
		Me.txtLanding.Location = New System.Drawing.Point(496, 544)
		Me.txtLanding.TabIndex = 14
		Me.txtLanding.Text = "200.00"
		Me.txtLanding.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtLanding.AcceptsReturn = True
		Me.txtLanding.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtLanding.BackColor = System.Drawing.SystemColors.Window
		Me.txtLanding.CausesValidation = True
		Me.txtLanding.Enabled = True
		Me.txtLanding.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtLanding.HideSelection = True
		Me.txtLanding.ReadOnly = False
		Me.txtLanding.Maxlength = 0
		Me.txtLanding.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtLanding.MultiLine = False
		Me.txtLanding.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtLanding.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtLanding.TabStop = True
		Me.txtLanding.Visible = True
		Me.txtLanding.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtLanding.Name = "txtLanding"
		Me.txtCustoms.AutoSize = False
		Me.txtCustoms.Size = New System.Drawing.Size(200, 26)
		Me.txtCustoms.Location = New System.Drawing.Point(496, 592)
		Me.txtCustoms.TabIndex = 13
		Me.txtCustoms.Text = "200.00"
		Me.txtCustoms.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtCustoms.AcceptsReturn = True
		Me.txtCustoms.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtCustoms.BackColor = System.Drawing.SystemColors.Window
		Me.txtCustoms.CausesValidation = True
		Me.txtCustoms.Enabled = True
		Me.txtCustoms.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtCustoms.HideSelection = True
		Me.txtCustoms.ReadOnly = False
		Me.txtCustoms.Maxlength = 0
		Me.txtCustoms.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtCustoms.MultiLine = False
		Me.txtCustoms.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtCustoms.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtCustoms.TabStop = True
		Me.txtCustoms.Visible = True
		Me.txtCustoms.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtCustoms.Name = "txtCustoms"
		Me.txtCustComm.AutoSize = False
		Me.txtCustComm.Size = New System.Drawing.Size(200, 26)
		Me.txtCustComm.Location = New System.Drawing.Point(152, 832)
		Me.txtCustComm.TabIndex = 12
		Me.txtCustComm.Text = "100.00"
		Me.txtCustComm.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtCustComm.AcceptsReturn = True
		Me.txtCustComm.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtCustComm.BackColor = System.Drawing.SystemColors.Window
		Me.txtCustComm.CausesValidation = True
		Me.txtCustComm.Enabled = True
		Me.txtCustComm.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtCustComm.HideSelection = True
		Me.txtCustComm.ReadOnly = False
		Me.txtCustComm.Maxlength = 0
		Me.txtCustComm.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtCustComm.MultiLine = False
		Me.txtCustComm.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtCustComm.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtCustComm.TabStop = True
		Me.txtCustComm.Visible = True
		Me.txtCustComm.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtCustComm.Name = "txtCustComm"
		Me.txtER.AutoSize = False
		Me.txtER.Size = New System.Drawing.Size(200, 26)
		Me.txtER.Location = New System.Drawing.Point(152, 784)
		Me.txtER.TabIndex = 11
		Me.txtER.Text = "200.00"
		Me.txtER.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtER.AcceptsReturn = True
		Me.txtER.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtER.BackColor = System.Drawing.SystemColors.Window
		Me.txtER.CausesValidation = True
		Me.txtER.Enabled = True
		Me.txtER.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtER.HideSelection = True
		Me.txtER.ReadOnly = False
		Me.txtER.Maxlength = 0
		Me.txtER.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtER.MultiLine = False
		Me.txtER.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtER.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtER.TabStop = True
		Me.txtER.Visible = True
		Me.txtER.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtER.Name = "txtER"
		Me.txtTotalFuelCost.AutoSize = False
		Me.txtTotalFuelCost.Size = New System.Drawing.Size(200, 26)
		Me.txtTotalFuelCost.Location = New System.Drawing.Point(496, 640)
		Me.txtTotalFuelCost.TabIndex = 10
		Me.txtTotalFuelCost.Text = "0.00"
		Me.txtTotalFuelCost.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtTotalFuelCost.AcceptsReturn = True
		Me.txtTotalFuelCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtTotalFuelCost.BackColor = System.Drawing.SystemColors.Window
		Me.txtTotalFuelCost.CausesValidation = True
		Me.txtTotalFuelCost.Enabled = True
		Me.txtTotalFuelCost.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtTotalFuelCost.HideSelection = True
		Me.txtTotalFuelCost.ReadOnly = False
		Me.txtTotalFuelCost.Maxlength = 0
		Me.txtTotalFuelCost.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtTotalFuelCost.MultiLine = False
		Me.txtTotalFuelCost.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtTotalFuelCost.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtTotalFuelCost.TabStop = True
		Me.txtTotalFuelCost.Visible = True
		Me.txtTotalFuelCost.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtTotalFuelCost.Name = "txtTotalFuelCost"
		Me.cmdPrint.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.cmdPrint.Text = "Command1"
		Me.cmdPrint.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmdPrint.Size = New System.Drawing.Size(17, 13)
		Me.cmdPrint.Location = New System.Drawing.Point(24, 152)
		Me.cmdPrint.TabIndex = 2
		Me.cmdPrint.BackColor = System.Drawing.SystemColors.Control
		Me.cmdPrint.CausesValidation = True
		Me.cmdPrint.Enabled = True
		Me.cmdPrint.ForeColor = System.Drawing.SystemColors.ControlText
		Me.cmdPrint.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdPrint.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdPrint.TabStop = True
		Me.cmdPrint.Name = "cmdPrint"
		Me.Label13.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label13.BackColor = System.Drawing.Color.White
		Me.Label13.Text = "Radio Costs:"
		Me.Label13.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label13.Size = New System.Drawing.Size(97, 33)
		Me.Label13.Location = New System.Drawing.Point(392, 744)
		Me.Label13.TabIndex = 44
		Me.Label13.Enabled = True
		Me.Label13.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label13.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label13.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label13.UseMnemonic = True
		Me.Label13.Visible = True
		Me.Label13.AutoSize = False
		Me.Label13.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label13.Name = "Label13"
		Me.Label12.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label12.BackColor = System.Drawing.Color.White
		Me.Label12.Text = "Tanking Costs:"
		Me.Label12.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label12.Size = New System.Drawing.Size(105, 17)
		Me.Label12.Location = New System.Drawing.Point(384, 696)
		Me.Label12.TabIndex = 43
		Me.Label12.Enabled = True
		Me.Label12.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label12.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label12.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label12.UseMnemonic = True
		Me.Label12.Visible = True
		Me.Label12.AutoSize = False
		Me.Label12.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label12.Name = "Label12"
		Me.Label11.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label11.BackColor = System.Drawing.Color.White
		Me.Label11.Text = "Insurance:"
		Me.Label11.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label11.Size = New System.Drawing.Size(97, 25)
		Me.Label11.Location = New System.Drawing.Point(392, 792)
		Me.Label11.TabIndex = 41
		Me.Label11.Enabled = True
		Me.Label11.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label11.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label11.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label11.UseMnemonic = True
		Me.Label11.Visible = True
		Me.Label11.AutoSize = False
		Me.Label11.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label11.Name = "Label11"
		Me.Label10.BackColor = System.Drawing.Color.White
		Me.Label10.Text = "Insured"
		Me.Label10.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Italic Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label10.Size = New System.Drawing.Size(129, 17)
		Me.Label10.Location = New System.Drawing.Point(648, 920)
		Me.Label10.TabIndex = 40
		Me.Label10.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label10.Enabled = True
		Me.Label10.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label10.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label10.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label10.UseMnemonic = True
		Me.Label10.Visible = True
		Me.Label10.AutoSize = False
		Me.Label10.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label10.Name = "Label10"
		Me.Label2.BackColor = System.Drawing.Color.White
		Me.Label2.Text = "Uninsured"
		Me.Label2.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Italic Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label2.Size = New System.Drawing.Size(129, 17)
		Me.Label2.Location = New System.Drawing.Point(648, 880)
		Me.Label2.TabIndex = 39
		Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label2.Enabled = True
		Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label2.UseMnemonic = True
		Me.Label2.Visible = True
		Me.Label2.AutoSize = False
		Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label2.Name = "Label2"
		Me.Label9.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label9.BackColor = System.Drawing.Color.White
		Me.Label9.Text = "Bid Total (in U.S.D.):"
		Me.Label9.Font = New System.Drawing.Font("Arial", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label9.Size = New System.Drawing.Size(81, 41)
		Me.Label9.Location = New System.Drawing.Point(408, 856)
		Me.Label9.TabIndex = 36
		Me.Label9.Enabled = True
		Me.Label9.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label9.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label9.UseMnemonic = True
		Me.Label9.Visible = True
		Me.Label9.AutoSize = False
		Me.Label9.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label9.Name = "Label9"
		Me.Line1.BackColor = System.Drawing.SystemColors.WindowText
		Me.Line1.Visible = True
		Me.Line1.Location = New System.Drawing.Point(240, 512)
		Me.Line1.Width = 304
		Me.Line1.Height = 1
		Me.Line1.Name = "Line1"
		Me.Label14.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label14.BackColor = System.Drawing.Color.White
		Me.Label14.Text = "Per Diem:"
		Me.Label14.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label14.Size = New System.Drawing.Size(89, 25)
		Me.Label14.Location = New System.Drawing.Point(56, 552)
		Me.Label14.TabIndex = 29
		Me.Label14.Enabled = True
		Me.Label14.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label14.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label14.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label14.UseMnemonic = True
		Me.Label14.Visible = True
		Me.Label14.AutoSize = False
		Me.Label14.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label14.Name = "Label14"
		Me.Label15.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label15.BackColor = System.Drawing.Color.White
		Me.Label15.Text = "Days Away:"
		Me.Label15.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label15.Size = New System.Drawing.Size(89, 17)
		Me.Label15.Location = New System.Drawing.Point(56, 600)
		Me.Label15.TabIndex = 28
		Me.Label15.Enabled = True
		Me.Label15.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label15.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label15.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label15.UseMnemonic = True
		Me.Label15.Visible = True
		Me.Label15.AutoSize = False
		Me.Label15.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label15.Name = "Label15"
		Me.Label16.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label16.BackColor = System.Drawing.Color.White
		Me.Label16.Text = "Crew Salaries:"
		Me.Label16.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label16.Size = New System.Drawing.Size(121, 25)
		Me.Label16.Location = New System.Drawing.Point(24, 696)
		Me.Label16.TabIndex = 27
		Me.Label16.Enabled = True
		Me.Label16.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label16.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label16.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label16.UseMnemonic = True
		Me.Label16.Visible = True
		Me.Label16.AutoSize = False
		Me.Label16.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label16.Name = "Label16"
		Me.Label17.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label17.BackColor = System.Drawing.Color.White
		Me.Label17.Text = "Total Per Diem:"
		Me.Label17.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label17.Size = New System.Drawing.Size(113, 17)
		Me.Label17.Location = New System.Drawing.Point(32, 648)
		Me.Label17.TabIndex = 26
		Me.Label17.Enabled = True
		Me.Label17.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label17.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label17.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label17.UseMnemonic = True
		Me.Label17.Visible = True
		Me.Label17.AutoSize = False
		Me.Label17.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label17.Name = "Label17"
		Me.Label18.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label18.BackColor = System.Drawing.Color.White
		Me.Label18.Text = "Airline Fares:"
		Me.Label18.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label18.Size = New System.Drawing.Size(105, 25)
		Me.Label18.Location = New System.Drawing.Point(40, 744)
		Me.Label18.TabIndex = 25
		Me.Label18.Enabled = True
		Me.Label18.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label18.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label18.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label18.UseMnemonic = True
		Me.Label18.Visible = True
		Me.Label18.AutoSize = False
		Me.Label18.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label18.Name = "Label18"
		Me.Label19.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label19.BackColor = System.Drawing.Color.White
		Me.Label19.Text = "Landing Costs:"
		Me.Label19.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label19.Size = New System.Drawing.Size(97, 25)
		Me.Label19.Location = New System.Drawing.Point(392, 552)
		Me.Label19.TabIndex = 24
		Me.Label19.Enabled = True
		Me.Label19.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label19.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label19.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label19.UseMnemonic = True
		Me.Label19.Visible = True
		Me.Label19.AutoSize = False
		Me.Label19.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label19.Name = "Label19"
		Me.Label20.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label20.BackColor = System.Drawing.Color.White
		Me.Label20.Text = "Customs Costs:"
		Me.Label20.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label20.Size = New System.Drawing.Size(97, 25)
		Me.Label20.Location = New System.Drawing.Point(392, 600)
		Me.Label20.TabIndex = 23
		Me.Label20.Enabled = True
		Me.Label20.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label20.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label20.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label20.UseMnemonic = True
		Me.Label20.Visible = True
		Me.Label20.AutoSize = False
		Me.Label20.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label20.Name = "Label20"
		Me.Label21.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label21.BackColor = System.Drawing.Color.White
		Me.Label21.Text = "Customer Communications:"
		Me.Label21.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label21.Size = New System.Drawing.Size(113, 33)
		Me.Label21.Location = New System.Drawing.Point(32, 824)
		Me.Label21.TabIndex = 22
		Me.Label21.Enabled = True
		Me.Label21.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label21.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label21.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label21.UseMnemonic = True
		Me.Label21.Visible = True
		Me.Label21.AutoSize = False
		Me.Label21.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label21.Name = "Label21"
		Me.Label22.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label22.BackColor = System.Drawing.Color.White
		Me.Label22.Text = "Emergency Equipment:"
		Me.Label22.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label22.Size = New System.Drawing.Size(97, 33)
		Me.Label22.Location = New System.Drawing.Point(48, 776)
		Me.Label22.TabIndex = 21
		Me.Label22.Enabled = True
		Me.Label22.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label22.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label22.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label22.UseMnemonic = True
		Me.Label22.Visible = True
		Me.Label22.AutoSize = False
		Me.Label22.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label22.Name = "Label22"
		Me.Label24.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label24.BackColor = System.Drawing.Color.White
		Me.Label24.Text = "Fuel Cost:"
		Me.Label24.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label24.Size = New System.Drawing.Size(81, 17)
		Me.Label24.Location = New System.Drawing.Point(408, 648)
		Me.Label24.TabIndex = 20
		Me.Label24.Enabled = True
		Me.Label24.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label24.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label24.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label24.UseMnemonic = True
		Me.Label24.Visible = True
		Me.Label24.AutoSize = False
		Me.Label24.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label24.Name = "Label24"
		Me.Label8.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label8.BackColor = System.Drawing.Color.White
		Me.Label8.Text = "Contact:"
		Me.Label8.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label8.Size = New System.Drawing.Size(81, 25)
		Me.Label8.Location = New System.Drawing.Point(64, 424)
		Me.Label8.TabIndex = 9
		Me.Label8.Enabled = True
		Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label8.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label8.UseMnemonic = True
		Me.Label8.Visible = True
		Me.Label8.AutoSize = False
		Me.Label8.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label8.Name = "Label8"
		Me.Label7.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label7.BackColor = System.Drawing.Color.White
		Me.Label7.Text = "Aircraft:"
		Me.Label7.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label7.Size = New System.Drawing.Size(105, 17)
		Me.Label7.Location = New System.Drawing.Point(384, 424)
		Me.Label7.TabIndex = 8
		Me.Label7.Enabled = True
		Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label7.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label7.UseMnemonic = True
		Me.Label7.Visible = True
		Me.Label7.AutoSize = False
		Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label7.Name = "Label7"
		Me.Label6.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label6.BackColor = System.Drawing.Color.White
		Me.Label6.Text = "Flight Destination:"
		Me.Label6.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label6.Size = New System.Drawing.Size(137, 33)
		Me.Label6.Location = New System.Drawing.Point(352, 464)
		Me.Label6.TabIndex = 7
		Me.Label6.Enabled = True
		Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label6.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label6.UseMnemonic = True
		Me.Label6.Visible = True
		Me.Label6.AutoSize = False
		Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label6.Name = "Label6"
		Me.Label5.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label5.BackColor = System.Drawing.Color.White
		Me.Label5.Text = "Flight Origin:"
		Me.Label5.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label5.Size = New System.Drawing.Size(113, 33)
		Me.Label5.Location = New System.Drawing.Point(32, 464)
		Me.Label5.TabIndex = 6
		Me.Label5.Enabled = True
		Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label5.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label5.UseMnemonic = True
		Me.Label5.Visible = True
		Me.Label5.AutoSize = False
		Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label5.Name = "Label5"
		Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label4.BackColor = System.Drawing.Color.White
		Me.Label4.Text = "Date:"
		Me.Label4.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label4.Size = New System.Drawing.Size(89, 33)
		Me.Label4.Location = New System.Drawing.Point(400, 376)
		Me.Label4.TabIndex = 5
		Me.Label4.Enabled = True
		Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label4.UseMnemonic = True
		Me.Label4.Visible = True
		Me.Label4.AutoSize = False
		Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label4.Name = "Label4"
		Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label3.BackColor = System.Drawing.Color.White
		Me.Label3.Text = "Client:"
		Me.Label3.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label3.Size = New System.Drawing.Size(113, 17)
		Me.Label3.Location = New System.Drawing.Point(32, 376)
		Me.Label3.TabIndex = 4
		Me.Label3.Enabled = True
		Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label3.UseMnemonic = True
		Me.Label3.Visible = True
		Me.Label3.AutoSize = False
		Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label3.Name = "Label3"
		Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me.Label1.BackColor = System.Drawing.Color.White
		Me.Label1.Text = "Ferry Bid"
		Me.Label1.Font = New System.Drawing.Font("Arial", 26.25!, System.Drawing.FontStyle.Underline Or System.Drawing.FontStyle.Italic Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label1.Size = New System.Drawing.Size(749, 41)
		Me.Label1.Location = New System.Drawing.Point(0, 304)
		Me.Label1.TabIndex = 3
		Me.Label1.Enabled = True
		Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label1.UseMnemonic = True
		Me.Label1.Visible = True
		Me.Label1.AutoSize = False
		Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label1.Name = "Label1"
		Me.Picture2.BackColor = System.Drawing.SystemColors.ActiveCaptionText
		Me.Picture2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Picture2.Size = New System.Drawing.Size(497, 113)
		Me.Picture2.Location = New System.Drawing.Point(16, 288)
		Me.Picture2.TabIndex = 1
		Me.Picture2.Dock = System.Windows.Forms.DockStyle.None
		Me.Picture2.CausesValidation = True
		Me.Picture2.Enabled = True
		Me.Picture2.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Picture2.Cursor = System.Windows.Forms.Cursors.Default
		Me.Picture2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Picture2.TabStop = True
		Me.Picture2.Visible = True
		Me.Picture2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Normal
		Me.Picture2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.Picture2.Name = "Picture2"
		Me.Controls.Add(Picture1)
		Me.Controls.Add(Picture2)
		Me.Picture1.Controls.Add(txtRadio)
		Me.Picture1.Controls.Add(txtTank)
		Me.Picture1.Controls.Add(txtInsurance)
		Me.Picture1.Controls.Add(txtBidInsTotal)
		Me.Picture1.Controls.Add(txtBidTotal)
		Me.Picture1.Controls.Add(txtDest)
		Me.Picture1.Controls.Add(txtAC)
		Me.Picture1.Controls.Add(txtDate)
		Me.Picture1.Controls.Add(txtOrigin)
		Me.Picture1.Controls.Add(txtContact)
		Me.Picture1.Controls.Add(txtClient)
		Me.Picture1.Controls.Add(txtPerDiem)
		Me.Picture1.Controls.Add(txtDaysAway)
		Me.Picture1.Controls.Add(txtCrew1)
		Me.Picture1.Controls.Add(txtCrewPD1)
		Me.Picture1.Controls.Add(txtAF1)
		Me.Picture1.Controls.Add(txtLanding)
		Me.Picture1.Controls.Add(txtCustoms)
		Me.Picture1.Controls.Add(txtCustComm)
		Me.Picture1.Controls.Add(txtER)
		Me.Picture1.Controls.Add(txtTotalFuelCost)
		Me.Picture1.Controls.Add(cmdPrint)
		Me.Picture1.Controls.Add(Label13)
		Me.Picture1.Controls.Add(Label12)
		Me.Picture1.Controls.Add(Label11)
		Me.Picture1.Controls.Add(Label10)
		Me.Picture1.Controls.Add(Label2)
		Me.Picture1.Controls.Add(Label9)
		Me.Picture1.Controls.Add(Line1)
		Me.Picture1.Controls.Add(Label14)
		Me.Picture1.Controls.Add(Label15)
		Me.Picture1.Controls.Add(Label16)
		Me.Picture1.Controls.Add(Label17)
		Me.Picture1.Controls.Add(Label18)
		Me.Picture1.Controls.Add(Label19)
		Me.Picture1.Controls.Add(Label20)
		Me.Picture1.Controls.Add(Label21)
		Me.Picture1.Controls.Add(Label22)
		Me.Picture1.Controls.Add(Label24)
		Me.Picture1.Controls.Add(Label8)
		Me.Picture1.Controls.Add(Label7)
		Me.Picture1.Controls.Add(Label6)
		Me.Picture1.Controls.Add(Label5)
		Me.Picture1.Controls.Add(Label4)
		Me.Picture1.Controls.Add(Label3)
		Me.Picture1.Controls.Add(Label1)
	End Sub
#End Region 
#Region "Upgrade Support "
	Private Shared m_vb6FormDefInstance As frmBidPrint
	Private Shared m_InitializingDefInstance As Boolean
	Public Shared Property DefInstance() As frmBidPrint
		Get
			If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
				m_InitializingDefInstance = True
				m_vb6FormDefInstance = New frmBidPrint()
				m_InitializingDefInstance = False
			End If
			DefInstance = m_vb6FormDefInstance
		End Get
		Set
			m_vb6FormDefInstance = Value
		End Set
	End Property
#End Region 
	Dim dteEndDate As Date
	Dim strDest, strOrig, strVia As String
	Private Const twipFactor As Short = 1440
	Private Const WM_PAINT As Short = &HFs
	Private Const WM_PRINT As Short = &H317s
	Private Const PRF_CLIENT As Integer = &H4 ' Draw the window's client area.
	Private Const PRF_CHILDREN As Integer = &H10 ' Draw all visible child windows.
	Private Const PRF_OWNED As Integer = &H20 ' Draw all owned windows.
	
	Private Declare Function SendMessage Lib "user32"  Alias "SendMessageA"(ByVal hwnd As Integer, ByVal wMsg As Integer, ByVal wParam As Integer, ByVal lParam As Integer) As Integer
	
	Private Sub cmdPrint_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdPrint.Click
		
		Dim sWide, sTall As Single
		Dim rv As Integer
		'UPGRADE_ISSUE: Constant vbTwips was not upgraded. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2070"'
		'UPGRADE_ISSUE: Form property frmBidPrint.ScaleMode is not supported. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2038"'
        'Me.ScaleMode = vbTwips ' default
		sWide = 8.5
		sTall = 11 ' or 14, etc.
		Me.Width = VB6.TwipsToPixelsX(twipFactor * sWide)
		Me.Height = VB6.TwipsToPixelsY(twipFactor * sTall)
		cmdPrint.Visible = False
		
		With Picture1
			.Top = 0
			.Left = 0
			.Width = VB6.TwipsToPixelsX(twipFactor * sWide)
			.Height = VB6.TwipsToPixelsY(twipFactor * sTall)
		End With
		
		With Picture2
			.Top = 0
			.Left = 0
			.Width = VB6.TwipsToPixelsX(twipFactor * sWide)
			.Height = VB6.TwipsToPixelsY(twipFactor * sTall)
		End With
		
		Me.Visible = True
		System.Windows.Forms.Application.DoEvents()
		Picture2.Visible = False
		Picture1.Focus()
		'UPGRADE_ISSUE: PictureBox property Picture2.AutoRedraw was not upgraded. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2064"'
        'Picture2.AutoRedraw = True
		'UPGRADE_ISSUE: PictureBox property Picture2.hDC was not upgraded. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2064"'
        'rv = SendMessage(Picture1.Handle.ToInt32, WM_PAINT, Picture2.hDC, 0)
		'UPGRADE_ISSUE: PictureBox property Picture2.hDC was not upgraded. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2064"'
        'rv = SendMessage(Picture1.Handle.ToInt32, WM_PRINT, Picture2.hDC, PRF_CHILDREN + PRF_CLIENT + PRF_OWNED)
		'UPGRADE_ISSUE: PictureBox property Picture2.Image was not upgraded. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2064"'
		Picture2.Image = Picture2.Image
		'UPGRADE_ISSUE: PictureBox property Picture2.AutoRedraw was not upgraded. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2064"'
        'Picture2.AutoRedraw = False
		
		'UPGRADE_ISSUE: Printer object was not upgraded. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2068"'
		'UPGRADE_ISSUE: Printer method Printer.Print was not upgraded. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2069"'
        'Printer.Print("")
		'UPGRADE_ISSUE: Printer method Printer.PaintPicture was not upgraded. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2069"'
        'Printer.PaintPicture(Picture2.Image, 0, 0)
		
		'UPGRADE_ISSUE: Printer method Printer.EndDoc was not upgraded. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2069"'
        'Printer.EndDoc()
		
	End Sub
	
	'UPGRADE_WARNING: Form event frmBidPrint.Activate has a new behavior. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2065"'
	Private Sub frmBidPrint_Activated(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Activated
		Call cmdPrint_Click(cmdPrint, New System.EventArgs())
		frmBidPrint1.DefInstance.Show()
		Me.Close()
	End Sub
	
	Private Sub frmBidPrint_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		
		txtClient.Text = frmCust.DefInstance.txtCompany.Text
		txtContact.Text = frmCust.DefInstance.txtContact.Text
		txtDate.Text = CStr(Today)
		txtAC.Text = frmBidCalc.DefInstance.txtAC.Text
		txtOrigin.Text = frmBidCalc.DefInstance.txtOrig.Text
		txtDest.Text = frmBidCalc.DefInstance.txtDest.Text
		txtPerDiem.Text = frmBidCalc.DefInstance.txtPerDiem.Text
		txtDaysAway.Text = frmBidCalc.DefInstance.txtDaysAway.Text
		txtCrewPD1.Text = CStr(intTotalPD)
		txtCrewPD1.Text = VB6.Format(txtCrewPD1.Text, "Standard")
		txtCrew1.Text = CStr(intTotalSal)
		txtCrew1.Text = VB6.Format(txtCrew1.Text, "Standard")
		txtAF1.Text = CStr(intTotalAF)
		txtAF1.Text = VB6.Format(txtAF1.Text, "Standard")
		txtInsurance.Text = frmBidCalc.DefInstance.txtInsurance.Text
		txtInsurance.Text = VB6.Format(txtInsurance.Text, "Standard")
		txtER.Text = frmBidCalc.DefInstance.txtER.Text
		txtCustComm.Text = frmBidCalc.DefInstance.txtCustComm.Text
		txtLanding.Text = frmBidCalc.DefInstance.txtLanding.Text
		txtCustoms.Text = frmBidCalc.DefInstance.txtCustoms.Text
		txtTotalFuelCost.Text = frmBidCalc.DefInstance.txtTotalFuelCost.Text
		txtBidTotal.Text = frmBidCalc.DefInstance.txtBidTotal.Text
		txtBidTotal.Text = VB6.Format(txtBidTotal.Text, "Currency")
		txtBidInsTotal.Text = frmBidCalc.DefInstance.txtBidInsTotal.Text
		txtBidInsTotal.Text = VB6.Format(txtBidInsTotal.Text, "Currency")
		txtTank.Text = frmBidCalc.DefInstance.txtTank.Text
		txtTank.Text = VB6.Format(txtTank.Text, "Fixed")
		txtRadio.Text = frmBidCalc.DefInstance.txtRadio.Text
		txtRadio.Text = VB6.Format(txtRadio.Text, "Fixed")
		
	End Sub
End Class