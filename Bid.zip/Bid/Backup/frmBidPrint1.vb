Option Strict Off
Option Explicit On
Friend Class frmBidPrint1
	Inherits System.Windows.Forms.Form
#Region "Windows Form Designer generated code "
	Public Sub New()
		MyBase.New()
		If m_vb6FormDefInstance Is Nothing Then
			If m_InitializingDefInstance Then
				m_vb6FormDefInstance = Me
			Else
				Try 
					'For the start-up form, the first instance created is the default instance.
					If System.Reflection.Assembly.GetExecutingAssembly.EntryPoint.DeclaringType Is Me.GetType Then
						m_vb6FormDefInstance = Me
					End If
				Catch
				End Try
			End If
		End If
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents txtICAO15 As System.Windows.Forms.TextBox
	Public WithEvents txtICAO14 As System.Windows.Forms.TextBox
	Public WithEvents txtICAO3 As System.Windows.Forms.TextBox
	Public WithEvents txtICAO1 As System.Windows.Forms.TextBox
	Public WithEvents txtDate As System.Windows.Forms.TextBox
	Public WithEvents txtICAO2 As System.Windows.Forms.TextBox
	Public WithEvents txtICAO As System.Windows.Forms.TextBox
	Public WithEvents txtClient As System.Windows.Forms.TextBox
	Public WithEvents txtICAO4 As System.Windows.Forms.TextBox
	Public WithEvents txtICAO6 As System.Windows.Forms.TextBox
	Public WithEvents txtICAO10 As System.Windows.Forms.TextBox
	Public WithEvents txtICAO8 As System.Windows.Forms.TextBox
	Public WithEvents txtICAO12 As System.Windows.Forms.TextBox
	Public WithEvents txtICAO9 As System.Windows.Forms.TextBox
	Public WithEvents txtICAO11 As System.Windows.Forms.TextBox
	Public WithEvents txtICAO7 As System.Windows.Forms.TextBox
	Public WithEvents txtICAO5 As System.Windows.Forms.TextBox
	Public WithEvents txtICAO13 As System.Windows.Forms.TextBox
	Public WithEvents cmdPrint As System.Windows.Forms.Button
	Public WithEvents Label2 As System.Windows.Forms.Label
	Public WithEvents Label11 As System.Windows.Forms.Label
	Public WithEvents Line1 As System.Windows.Forms.Label
	Public WithEvents Label14 As System.Windows.Forms.Label
	Public WithEvents Label15 As System.Windows.Forms.Label
	Public WithEvents Label16 As System.Windows.Forms.Label
	Public WithEvents Label17 As System.Windows.Forms.Label
	Public WithEvents Label18 As System.Windows.Forms.Label
	Public WithEvents Label19 As System.Windows.Forms.Label
	Public WithEvents Label20 As System.Windows.Forms.Label
	Public WithEvents Label21 As System.Windows.Forms.Label
	Public WithEvents Label22 As System.Windows.Forms.Label
	Public WithEvents Label24 As System.Windows.Forms.Label
	Public WithEvents Label8 As System.Windows.Forms.Label
	Public WithEvents Label7 As System.Windows.Forms.Label
	Public WithEvents Label6 As System.Windows.Forms.Label
	Public WithEvents Label5 As System.Windows.Forms.Label
	Public WithEvents Label4 As System.Windows.Forms.Label
	Public WithEvents Label3 As System.Windows.Forms.Label
	Public WithEvents Label1 As System.Windows.Forms.Label
	Public WithEvents Picture1 As System.Windows.Forms.Panel
	Public WithEvents Picture2 As System.Windows.Forms.PictureBox
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmBidPrint1))
		Me.components = New System.ComponentModel.Container()
		Me.ToolTip1 = New System.Windows.Forms.ToolTip(components)
		Me.ToolTip1.Active = True
		Me.Picture1 = New System.Windows.Forms.Panel
		Me.txtICAO15 = New System.Windows.Forms.TextBox
		Me.txtICAO14 = New System.Windows.Forms.TextBox
		Me.txtICAO3 = New System.Windows.Forms.TextBox
		Me.txtICAO1 = New System.Windows.Forms.TextBox
		Me.txtDate = New System.Windows.Forms.TextBox
		Me.txtICAO2 = New System.Windows.Forms.TextBox
		Me.txtICAO = New System.Windows.Forms.TextBox
		Me.txtClient = New System.Windows.Forms.TextBox
		Me.txtICAO4 = New System.Windows.Forms.TextBox
		Me.txtICAO6 = New System.Windows.Forms.TextBox
		Me.txtICAO10 = New System.Windows.Forms.TextBox
		Me.txtICAO8 = New System.Windows.Forms.TextBox
		Me.txtICAO12 = New System.Windows.Forms.TextBox
		Me.txtICAO9 = New System.Windows.Forms.TextBox
		Me.txtICAO11 = New System.Windows.Forms.TextBox
		Me.txtICAO7 = New System.Windows.Forms.TextBox
		Me.txtICAO5 = New System.Windows.Forms.TextBox
		Me.txtICAO13 = New System.Windows.Forms.TextBox
		Me.cmdPrint = New System.Windows.Forms.Button
		Me.Label2 = New System.Windows.Forms.Label
		Me.Label11 = New System.Windows.Forms.Label
		Me.Line1 = New System.Windows.Forms.Label
		Me.Label14 = New System.Windows.Forms.Label
		Me.Label15 = New System.Windows.Forms.Label
		Me.Label16 = New System.Windows.Forms.Label
		Me.Label17 = New System.Windows.Forms.Label
		Me.Label18 = New System.Windows.Forms.Label
		Me.Label19 = New System.Windows.Forms.Label
		Me.Label20 = New System.Windows.Forms.Label
		Me.Label21 = New System.Windows.Forms.Label
		Me.Label22 = New System.Windows.Forms.Label
		Me.Label24 = New System.Windows.Forms.Label
		Me.Label8 = New System.Windows.Forms.Label
		Me.Label7 = New System.Windows.Forms.Label
		Me.Label6 = New System.Windows.Forms.Label
		Me.Label5 = New System.Windows.Forms.Label
		Me.Label4 = New System.Windows.Forms.Label
		Me.Label3 = New System.Windows.Forms.Label
		Me.Label1 = New System.Windows.Forms.Label
		Me.Picture2 = New System.Windows.Forms.PictureBox
		Me.BackColor = System.Drawing.Color.White
		Me.Text = "Bid Print"
		Me.ClientSize = New System.Drawing.Size(717, 566)
		Me.Location = New System.Drawing.Point(11, 37)
		Me.Font = New System.Drawing.Font("Arial", 12!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
		Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Sizable
		Me.ControlBox = True
		Me.Enabled = True
		Me.KeyPreview = False
		Me.MaximizeBox = True
		Me.MinimizeBox = True
		Me.Cursor = System.Windows.Forms.Cursors.Default
		Me.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.ShowInTaskbar = True
		Me.HelpButton = False
		Me.WindowState = System.Windows.Forms.FormWindowState.Normal
		Me.Name = "frmBidPrint1"
		Me.Picture1.BackColor = System.Drawing.SystemColors.ActiveCaptionText
		Me.Picture1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Picture1.Size = New System.Drawing.Size(757, 1209)
		Me.Picture1.Location = New System.Drawing.Point(0, 0)
		Me.Picture1.BackgroundImage = CType(resources.GetObject("Picture1.BackgroundImage"), System.Drawing.Image)
		Me.Picture1.TabIndex = 0
		Me.Picture1.Dock = System.Windows.Forms.DockStyle.None
		Me.Picture1.CausesValidation = True
		Me.Picture1.Enabled = True
		Me.Picture1.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Picture1.Cursor = System.Windows.Forms.Cursors.Default
		Me.Picture1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Picture1.TabStop = True
		Me.Picture1.Visible = True
		Me.Picture1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.Picture1.Name = "Picture1"
		Me.txtICAO15.AutoSize = False
		Me.txtICAO15.Size = New System.Drawing.Size(201, 26)
		Me.txtICAO15.Location = New System.Drawing.Point(496, 736)
		Me.txtICAO15.TabIndex = 38
		Me.txtICAO15.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtICAO15.AcceptsReturn = True
		Me.txtICAO15.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtICAO15.BackColor = System.Drawing.SystemColors.Window
		Me.txtICAO15.CausesValidation = True
		Me.txtICAO15.Enabled = True
		Me.txtICAO15.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtICAO15.HideSelection = True
		Me.txtICAO15.ReadOnly = False
		Me.txtICAO15.Maxlength = 0
		Me.txtICAO15.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtICAO15.MultiLine = False
		Me.txtICAO15.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtICAO15.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtICAO15.TabStop = True
		Me.txtICAO15.Visible = True
		Me.txtICAO15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtICAO15.Name = "txtICAO15"
		Me.txtICAO14.AutoSize = False
		Me.txtICAO14.Size = New System.Drawing.Size(201, 26)
		Me.txtICAO14.Location = New System.Drawing.Point(152, 736)
		Me.txtICAO14.TabIndex = 37
		Me.txtICAO14.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtICAO14.AcceptsReturn = True
		Me.txtICAO14.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtICAO14.BackColor = System.Drawing.SystemColors.Window
		Me.txtICAO14.CausesValidation = True
		Me.txtICAO14.Enabled = True
		Me.txtICAO14.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtICAO14.HideSelection = True
		Me.txtICAO14.ReadOnly = False
		Me.txtICAO14.Maxlength = 0
		Me.txtICAO14.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtICAO14.MultiLine = False
		Me.txtICAO14.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtICAO14.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtICAO14.TabStop = True
		Me.txtICAO14.Visible = True
		Me.txtICAO14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtICAO14.Name = "txtICAO14"
		Me.txtICAO3.AutoSize = False
		Me.txtICAO3.Size = New System.Drawing.Size(201, 26)
		Me.txtICAO3.Location = New System.Drawing.Point(496, 464)
		Me.txtICAO3.TabIndex = 35
		Me.txtICAO3.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtICAO3.AcceptsReturn = True
		Me.txtICAO3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtICAO3.BackColor = System.Drawing.SystemColors.Window
		Me.txtICAO3.CausesValidation = True
		Me.txtICAO3.Enabled = True
		Me.txtICAO3.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtICAO3.HideSelection = True
		Me.txtICAO3.ReadOnly = False
		Me.txtICAO3.Maxlength = 0
		Me.txtICAO3.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtICAO3.MultiLine = False
		Me.txtICAO3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtICAO3.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtICAO3.TabStop = True
		Me.txtICAO3.Visible = True
		Me.txtICAO3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtICAO3.Name = "txtICAO3"
		Me.txtICAO1.AutoSize = False
		Me.txtICAO1.Size = New System.Drawing.Size(201, 26)
		Me.txtICAO1.Location = New System.Drawing.Point(496, 424)
		Me.txtICAO1.TabIndex = 34
		Me.txtICAO1.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtICAO1.AcceptsReturn = True
		Me.txtICAO1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtICAO1.BackColor = System.Drawing.SystemColors.Window
		Me.txtICAO1.CausesValidation = True
		Me.txtICAO1.Enabled = True
		Me.txtICAO1.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtICAO1.HideSelection = True
		Me.txtICAO1.ReadOnly = False
		Me.txtICAO1.Maxlength = 0
		Me.txtICAO1.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtICAO1.MultiLine = False
		Me.txtICAO1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtICAO1.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtICAO1.TabStop = True
		Me.txtICAO1.Visible = True
		Me.txtICAO1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtICAO1.Name = "txtICAO1"
		Me.txtDate.AutoSize = False
		Me.txtDate.Size = New System.Drawing.Size(200, 26)
		Me.txtDate.Location = New System.Drawing.Point(496, 368)
		Me.txtDate.TabIndex = 33
		Me.txtDate.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtDate.AcceptsReturn = True
		Me.txtDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtDate.BackColor = System.Drawing.SystemColors.Window
		Me.txtDate.CausesValidation = True
		Me.txtDate.Enabled = True
		Me.txtDate.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtDate.HideSelection = True
		Me.txtDate.ReadOnly = False
		Me.txtDate.Maxlength = 0
		Me.txtDate.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtDate.MultiLine = False
		Me.txtDate.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtDate.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtDate.TabStop = True
		Me.txtDate.Visible = True
		Me.txtDate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtDate.Name = "txtDate"
		Me.txtICAO2.AutoSize = False
		Me.txtICAO2.Size = New System.Drawing.Size(200, 26)
		Me.txtICAO2.Location = New System.Drawing.Point(152, 464)
		Me.txtICAO2.TabIndex = 32
		Me.txtICAO2.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtICAO2.AcceptsReturn = True
		Me.txtICAO2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtICAO2.BackColor = System.Drawing.SystemColors.Window
		Me.txtICAO2.CausesValidation = True
		Me.txtICAO2.Enabled = True
		Me.txtICAO2.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtICAO2.HideSelection = True
		Me.txtICAO2.ReadOnly = False
		Me.txtICAO2.Maxlength = 0
		Me.txtICAO2.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtICAO2.MultiLine = False
		Me.txtICAO2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtICAO2.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtICAO2.TabStop = True
		Me.txtICAO2.Visible = True
		Me.txtICAO2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtICAO2.Name = "txtICAO2"
		Me.txtICAO.AutoSize = False
		Me.txtICAO.Size = New System.Drawing.Size(200, 26)
		Me.txtICAO.Location = New System.Drawing.Point(152, 424)
		Me.txtICAO.TabIndex = 31
		Me.txtICAO.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtICAO.AcceptsReturn = True
		Me.txtICAO.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtICAO.BackColor = System.Drawing.SystemColors.Window
		Me.txtICAO.CausesValidation = True
		Me.txtICAO.Enabled = True
		Me.txtICAO.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtICAO.HideSelection = True
		Me.txtICAO.ReadOnly = False
		Me.txtICAO.Maxlength = 0
		Me.txtICAO.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtICAO.MultiLine = False
		Me.txtICAO.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtICAO.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtICAO.TabStop = True
		Me.txtICAO.Visible = True
		Me.txtICAO.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtICAO.Name = "txtICAO"
		Me.txtClient.AutoSize = False
		Me.txtClient.Size = New System.Drawing.Size(200, 26)
		Me.txtClient.Location = New System.Drawing.Point(152, 368)
		Me.txtClient.TabIndex = 30
		Me.txtClient.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtClient.AcceptsReturn = True
		Me.txtClient.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtClient.BackColor = System.Drawing.SystemColors.Window
		Me.txtClient.CausesValidation = True
		Me.txtClient.Enabled = True
		Me.txtClient.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtClient.HideSelection = True
		Me.txtClient.ReadOnly = False
		Me.txtClient.Maxlength = 0
		Me.txtClient.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtClient.MultiLine = False
		Me.txtClient.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtClient.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtClient.TabStop = True
		Me.txtClient.Visible = True
		Me.txtClient.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtClient.Name = "txtClient"
		Me.txtICAO4.AutoSize = False
		Me.txtICAO4.Size = New System.Drawing.Size(200, 26)
		Me.txtICAO4.Location = New System.Drawing.Point(152, 504)
		Me.txtICAO4.TabIndex = 19
		Me.txtICAO4.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtICAO4.AcceptsReturn = True
		Me.txtICAO4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtICAO4.BackColor = System.Drawing.SystemColors.Window
		Me.txtICAO4.CausesValidation = True
		Me.txtICAO4.Enabled = True
		Me.txtICAO4.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtICAO4.HideSelection = True
		Me.txtICAO4.ReadOnly = False
		Me.txtICAO4.Maxlength = 0
		Me.txtICAO4.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtICAO4.MultiLine = False
		Me.txtICAO4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtICAO4.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtICAO4.TabStop = True
		Me.txtICAO4.Visible = True
		Me.txtICAO4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtICAO4.Name = "txtICAO4"
		Me.txtICAO6.AutoSize = False
		Me.txtICAO6.Size = New System.Drawing.Size(200, 26)
		Me.txtICAO6.Location = New System.Drawing.Point(152, 552)
		Me.txtICAO6.TabIndex = 18
		Me.txtICAO6.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtICAO6.AcceptsReturn = True
		Me.txtICAO6.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtICAO6.BackColor = System.Drawing.SystemColors.Window
		Me.txtICAO6.CausesValidation = True
		Me.txtICAO6.Enabled = True
		Me.txtICAO6.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtICAO6.HideSelection = True
		Me.txtICAO6.ReadOnly = False
		Me.txtICAO6.Maxlength = 0
		Me.txtICAO6.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtICAO6.MultiLine = False
		Me.txtICAO6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtICAO6.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtICAO6.TabStop = True
		Me.txtICAO6.Visible = True
		Me.txtICAO6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtICAO6.Name = "txtICAO6"
		Me.txtICAO10.AutoSize = False
		Me.txtICAO10.Size = New System.Drawing.Size(200, 26)
		Me.txtICAO10.Location = New System.Drawing.Point(152, 648)
		Me.txtICAO10.TabIndex = 17
		Me.txtICAO10.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtICAO10.AcceptsReturn = True
		Me.txtICAO10.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtICAO10.BackColor = System.Drawing.SystemColors.Window
		Me.txtICAO10.CausesValidation = True
		Me.txtICAO10.Enabled = True
		Me.txtICAO10.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtICAO10.HideSelection = True
		Me.txtICAO10.ReadOnly = False
		Me.txtICAO10.Maxlength = 0
		Me.txtICAO10.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtICAO10.MultiLine = False
		Me.txtICAO10.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtICAO10.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtICAO10.TabStop = True
		Me.txtICAO10.Visible = True
		Me.txtICAO10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtICAO10.Name = "txtICAO10"
		Me.txtICAO8.AutoSize = False
		Me.txtICAO8.Size = New System.Drawing.Size(200, 26)
		Me.txtICAO8.Location = New System.Drawing.Point(152, 600)
		Me.txtICAO8.TabIndex = 16
		Me.txtICAO8.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtICAO8.AcceptsReturn = True
		Me.txtICAO8.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtICAO8.BackColor = System.Drawing.SystemColors.Window
		Me.txtICAO8.CausesValidation = True
		Me.txtICAO8.Enabled = True
		Me.txtICAO8.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtICAO8.HideSelection = True
		Me.txtICAO8.ReadOnly = False
		Me.txtICAO8.Maxlength = 0
		Me.txtICAO8.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtICAO8.MultiLine = False
		Me.txtICAO8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtICAO8.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtICAO8.TabStop = True
		Me.txtICAO8.Visible = True
		Me.txtICAO8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtICAO8.Name = "txtICAO8"
		Me.txtICAO12.AutoSize = False
		Me.txtICAO12.Size = New System.Drawing.Size(200, 26)
		Me.txtICAO12.Location = New System.Drawing.Point(152, 696)
		Me.txtICAO12.TabIndex = 15
		Me.txtICAO12.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtICAO12.AcceptsReturn = True
		Me.txtICAO12.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtICAO12.BackColor = System.Drawing.SystemColors.Window
		Me.txtICAO12.CausesValidation = True
		Me.txtICAO12.Enabled = True
		Me.txtICAO12.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtICAO12.HideSelection = True
		Me.txtICAO12.ReadOnly = False
		Me.txtICAO12.Maxlength = 0
		Me.txtICAO12.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtICAO12.MultiLine = False
		Me.txtICAO12.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtICAO12.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtICAO12.TabStop = True
		Me.txtICAO12.Visible = True
		Me.txtICAO12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtICAO12.Name = "txtICAO12"
		Me.txtICAO9.AutoSize = False
		Me.txtICAO9.Size = New System.Drawing.Size(200, 26)
		Me.txtICAO9.Location = New System.Drawing.Point(496, 600)
		Me.txtICAO9.TabIndex = 14
		Me.txtICAO9.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtICAO9.AcceptsReturn = True
		Me.txtICAO9.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtICAO9.BackColor = System.Drawing.SystemColors.Window
		Me.txtICAO9.CausesValidation = True
		Me.txtICAO9.Enabled = True
		Me.txtICAO9.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtICAO9.HideSelection = True
		Me.txtICAO9.ReadOnly = False
		Me.txtICAO9.Maxlength = 0
		Me.txtICAO9.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtICAO9.MultiLine = False
		Me.txtICAO9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtICAO9.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtICAO9.TabStop = True
		Me.txtICAO9.Visible = True
		Me.txtICAO9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtICAO9.Name = "txtICAO9"
		Me.txtICAO11.AutoSize = False
		Me.txtICAO11.Size = New System.Drawing.Size(200, 26)
		Me.txtICAO11.Location = New System.Drawing.Point(496, 648)
		Me.txtICAO11.TabIndex = 13
		Me.txtICAO11.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtICAO11.AcceptsReturn = True
		Me.txtICAO11.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtICAO11.BackColor = System.Drawing.SystemColors.Window
		Me.txtICAO11.CausesValidation = True
		Me.txtICAO11.Enabled = True
		Me.txtICAO11.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtICAO11.HideSelection = True
		Me.txtICAO11.ReadOnly = False
		Me.txtICAO11.Maxlength = 0
		Me.txtICAO11.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtICAO11.MultiLine = False
		Me.txtICAO11.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtICAO11.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtICAO11.TabStop = True
		Me.txtICAO11.Visible = True
		Me.txtICAO11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtICAO11.Name = "txtICAO11"
		Me.txtICAO7.AutoSize = False
		Me.txtICAO7.Size = New System.Drawing.Size(200, 26)
		Me.txtICAO7.Location = New System.Drawing.Point(496, 552)
		Me.txtICAO7.TabIndex = 12
		Me.txtICAO7.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtICAO7.AcceptsReturn = True
		Me.txtICAO7.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtICAO7.BackColor = System.Drawing.SystemColors.Window
		Me.txtICAO7.CausesValidation = True
		Me.txtICAO7.Enabled = True
		Me.txtICAO7.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtICAO7.HideSelection = True
		Me.txtICAO7.ReadOnly = False
		Me.txtICAO7.Maxlength = 0
		Me.txtICAO7.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtICAO7.MultiLine = False
		Me.txtICAO7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtICAO7.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtICAO7.TabStop = True
		Me.txtICAO7.Visible = True
		Me.txtICAO7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtICAO7.Name = "txtICAO7"
		Me.txtICAO5.AutoSize = False
		Me.txtICAO5.Size = New System.Drawing.Size(200, 26)
		Me.txtICAO5.Location = New System.Drawing.Point(496, 504)
		Me.txtICAO5.TabIndex = 11
		Me.txtICAO5.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtICAO5.AcceptsReturn = True
		Me.txtICAO5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtICAO5.BackColor = System.Drawing.SystemColors.Window
		Me.txtICAO5.CausesValidation = True
		Me.txtICAO5.Enabled = True
		Me.txtICAO5.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtICAO5.HideSelection = True
		Me.txtICAO5.ReadOnly = False
		Me.txtICAO5.Maxlength = 0
		Me.txtICAO5.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtICAO5.MultiLine = False
		Me.txtICAO5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtICAO5.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtICAO5.TabStop = True
		Me.txtICAO5.Visible = True
		Me.txtICAO5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtICAO5.Name = "txtICAO5"
		Me.txtICAO13.AutoSize = False
		Me.txtICAO13.Size = New System.Drawing.Size(200, 26)
		Me.txtICAO13.Location = New System.Drawing.Point(496, 696)
		Me.txtICAO13.TabIndex = 10
		Me.txtICAO13.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtICAO13.AcceptsReturn = True
		Me.txtICAO13.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtICAO13.BackColor = System.Drawing.SystemColors.Window
		Me.txtICAO13.CausesValidation = True
		Me.txtICAO13.Enabled = True
		Me.txtICAO13.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtICAO13.HideSelection = True
		Me.txtICAO13.ReadOnly = False
		Me.txtICAO13.Maxlength = 0
		Me.txtICAO13.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtICAO13.MultiLine = False
		Me.txtICAO13.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtICAO13.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtICAO13.TabStop = True
		Me.txtICAO13.Visible = True
		Me.txtICAO13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtICAO13.Name = "txtICAO13"
		Me.cmdPrint.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.cmdPrint.Text = "Command1"
		Me.cmdPrint.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmdPrint.Size = New System.Drawing.Size(17, 13)
		Me.cmdPrint.Location = New System.Drawing.Point(24, 152)
		Me.cmdPrint.TabIndex = 2
		Me.cmdPrint.BackColor = System.Drawing.SystemColors.Control
		Me.cmdPrint.CausesValidation = True
		Me.cmdPrint.Enabled = True
		Me.cmdPrint.ForeColor = System.Drawing.SystemColors.ControlText
		Me.cmdPrint.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdPrint.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdPrint.TabStop = True
		Me.cmdPrint.Name = "cmdPrint"
		Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label2.BackColor = System.Drawing.Color.White
		Me.Label2.Text = "ICAO 16:"
		Me.Label2.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label2.Size = New System.Drawing.Size(65, 17)
		Me.Label2.Location = New System.Drawing.Point(424, 744)
		Me.Label2.TabIndex = 39
		Me.Label2.Enabled = True
		Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label2.UseMnemonic = True
		Me.Label2.Visible = True
		Me.Label2.AutoSize = False
		Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label2.Name = "Label2"
		Me.Label11.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label11.BackColor = System.Drawing.Color.White
		Me.Label11.Text = "ICAO 15:"
		Me.Label11.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label11.Size = New System.Drawing.Size(97, 25)
		Me.Label11.Location = New System.Drawing.Point(48, 744)
		Me.Label11.TabIndex = 36
		Me.Label11.Enabled = True
		Me.Label11.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label11.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label11.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label11.UseMnemonic = True
		Me.Label11.Visible = True
		Me.Label11.AutoSize = False
		Me.Label11.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label11.Name = "Label11"
		Me.Line1.BackColor = System.Drawing.SystemColors.WindowText
		Me.Line1.Visible = True
		Me.Line1.Location = New System.Drawing.Point(240, 400)
		Me.Line1.Width = 304
		Me.Line1.Height = 1
		Me.Line1.Name = "Line1"
		Me.Label14.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label14.BackColor = System.Drawing.Color.White
		Me.Label14.Text = "ICAO 5:"
		Me.Label14.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label14.Size = New System.Drawing.Size(89, 25)
		Me.Label14.Location = New System.Drawing.Point(56, 512)
		Me.Label14.TabIndex = 29
		Me.Label14.Enabled = True
		Me.Label14.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label14.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label14.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label14.UseMnemonic = True
		Me.Label14.Visible = True
		Me.Label14.AutoSize = False
		Me.Label14.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label14.Name = "Label14"
		Me.Label15.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label15.BackColor = System.Drawing.Color.White
		Me.Label15.Text = "ICAO 7:"
		Me.Label15.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label15.Size = New System.Drawing.Size(89, 17)
		Me.Label15.Location = New System.Drawing.Point(56, 560)
		Me.Label15.TabIndex = 28
		Me.Label15.Enabled = True
		Me.Label15.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label15.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label15.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label15.UseMnemonic = True
		Me.Label15.Visible = True
		Me.Label15.AutoSize = False
		Me.Label15.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label15.Name = "Label15"
		Me.Label16.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label16.BackColor = System.Drawing.Color.White
		Me.Label16.Text = "ICAO 11:"
		Me.Label16.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label16.Size = New System.Drawing.Size(121, 25)
		Me.Label16.Location = New System.Drawing.Point(24, 656)
		Me.Label16.TabIndex = 27
		Me.Label16.Enabled = True
		Me.Label16.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label16.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label16.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label16.UseMnemonic = True
		Me.Label16.Visible = True
		Me.Label16.AutoSize = False
		Me.Label16.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label16.Name = "Label16"
		Me.Label17.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label17.BackColor = System.Drawing.Color.White
		Me.Label17.Text = "ICAO 9:"
		Me.Label17.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label17.Size = New System.Drawing.Size(113, 17)
		Me.Label17.Location = New System.Drawing.Point(32, 608)
		Me.Label17.TabIndex = 26
		Me.Label17.Enabled = True
		Me.Label17.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label17.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label17.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label17.UseMnemonic = True
		Me.Label17.Visible = True
		Me.Label17.AutoSize = False
		Me.Label17.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label17.Name = "Label17"
		Me.Label18.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label18.BackColor = System.Drawing.Color.White
		Me.Label18.Text = "ICAO 13:"
		Me.Label18.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label18.Size = New System.Drawing.Size(105, 25)
		Me.Label18.Location = New System.Drawing.Point(40, 704)
		Me.Label18.TabIndex = 25
		Me.Label18.Enabled = True
		Me.Label18.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label18.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label18.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label18.UseMnemonic = True
		Me.Label18.Visible = True
		Me.Label18.AutoSize = False
		Me.Label18.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label18.Name = "Label18"
		Me.Label19.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label19.BackColor = System.Drawing.Color.White
		Me.Label19.Text = "ICAO 10:"
		Me.Label19.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label19.Size = New System.Drawing.Size(97, 25)
		Me.Label19.Location = New System.Drawing.Point(392, 608)
		Me.Label19.TabIndex = 24
		Me.Label19.Enabled = True
		Me.Label19.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label19.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label19.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label19.UseMnemonic = True
		Me.Label19.Visible = True
		Me.Label19.AutoSize = False
		Me.Label19.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label19.Name = "Label19"
		Me.Label20.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label20.BackColor = System.Drawing.Color.White
		Me.Label20.Text = "ICAO 12:"
		Me.Label20.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label20.Size = New System.Drawing.Size(97, 25)
		Me.Label20.Location = New System.Drawing.Point(392, 656)
		Me.Label20.TabIndex = 23
		Me.Label20.Enabled = True
		Me.Label20.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label20.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label20.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label20.UseMnemonic = True
		Me.Label20.Visible = True
		Me.Label20.AutoSize = False
		Me.Label20.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label20.Name = "Label20"
		Me.Label21.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label21.BackColor = System.Drawing.Color.White
		Me.Label21.Text = "ICAO 8:"
		Me.Label21.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label21.Size = New System.Drawing.Size(113, 17)
		Me.Label21.Location = New System.Drawing.Point(376, 560)
		Me.Label21.TabIndex = 22
		Me.Label21.Enabled = True
		Me.Label21.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label21.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label21.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label21.UseMnemonic = True
		Me.Label21.Visible = True
		Me.Label21.AutoSize = False
		Me.Label21.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label21.Name = "Label21"
		Me.Label22.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label22.BackColor = System.Drawing.Color.White
		Me.Label22.Text = "ICAO 6:"
		Me.Label22.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label22.Size = New System.Drawing.Size(97, 17)
		Me.Label22.Location = New System.Drawing.Point(392, 512)
		Me.Label22.TabIndex = 21
		Me.Label22.Enabled = True
		Me.Label22.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label22.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label22.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label22.UseMnemonic = True
		Me.Label22.Visible = True
		Me.Label22.AutoSize = False
		Me.Label22.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label22.Name = "Label22"
		Me.Label24.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label24.BackColor = System.Drawing.Color.White
		Me.Label24.Text = "ICAO 14:"
		Me.Label24.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label24.Size = New System.Drawing.Size(81, 17)
		Me.Label24.Location = New System.Drawing.Point(408, 704)
		Me.Label24.TabIndex = 20
		Me.Label24.Enabled = True
		Me.Label24.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label24.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label24.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label24.UseMnemonic = True
		Me.Label24.Visible = True
		Me.Label24.AutoSize = False
		Me.Label24.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label24.Name = "Label24"
		Me.Label8.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label8.BackColor = System.Drawing.Color.White
		Me.Label8.Text = "ICAO 1:"
		Me.Label8.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label8.Size = New System.Drawing.Size(81, 25)
		Me.Label8.Location = New System.Drawing.Point(64, 432)
		Me.Label8.TabIndex = 9
		Me.Label8.Enabled = True
		Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label8.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label8.UseMnemonic = True
		Me.Label8.Visible = True
		Me.Label8.AutoSize = False
		Me.Label8.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label8.Name = "Label8"
		Me.Label7.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label7.BackColor = System.Drawing.Color.White
		Me.Label7.Text = "ICAO 2:"
		Me.Label7.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label7.Size = New System.Drawing.Size(105, 17)
		Me.Label7.Location = New System.Drawing.Point(384, 432)
		Me.Label7.TabIndex = 8
		Me.Label7.Enabled = True
		Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label7.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label7.UseMnemonic = True
		Me.Label7.Visible = True
		Me.Label7.AutoSize = False
		Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label7.Name = "Label7"
		Me.Label6.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label6.BackColor = System.Drawing.Color.White
		Me.Label6.Text = "ICAO 4:"
		Me.Label6.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label6.Size = New System.Drawing.Size(137, 33)
		Me.Label6.Location = New System.Drawing.Point(352, 472)
		Me.Label6.TabIndex = 7
		Me.Label6.Enabled = True
		Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label6.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label6.UseMnemonic = True
		Me.Label6.Visible = True
		Me.Label6.AutoSize = False
		Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label6.Name = "Label6"
		Me.Label5.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label5.BackColor = System.Drawing.Color.White
		Me.Label5.Text = "ICAO 3:"
		Me.Label5.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label5.Size = New System.Drawing.Size(113, 33)
		Me.Label5.Location = New System.Drawing.Point(32, 472)
		Me.Label5.TabIndex = 6
		Me.Label5.Enabled = True
		Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label5.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label5.UseMnemonic = True
		Me.Label5.Visible = True
		Me.Label5.AutoSize = False
		Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label5.Name = "Label5"
		Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label4.BackColor = System.Drawing.Color.White
		Me.Label4.Text = "Date:"
		Me.Label4.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label4.Size = New System.Drawing.Size(89, 33)
		Me.Label4.Location = New System.Drawing.Point(400, 376)
		Me.Label4.TabIndex = 5
		Me.Label4.Enabled = True
		Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label4.UseMnemonic = True
		Me.Label4.Visible = True
		Me.Label4.AutoSize = False
		Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label4.Name = "Label4"
		Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopRight
		Me.Label3.BackColor = System.Drawing.Color.White
		Me.Label3.Text = "Client:"
		Me.Label3.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label3.Size = New System.Drawing.Size(113, 17)
		Me.Label3.Location = New System.Drawing.Point(32, 376)
		Me.Label3.TabIndex = 4
		Me.Label3.Enabled = True
		Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label3.UseMnemonic = True
		Me.Label3.Visible = True
		Me.Label3.AutoSize = False
		Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label3.Name = "Label3"
		Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
		Me.Label1.BackColor = System.Drawing.Color.White
		Me.Label1.Text = "Ferry Bid Flight Routing"
		Me.Label1.Font = New System.Drawing.Font("Arial", 26.25!, System.Drawing.FontStyle.Underline Or System.Drawing.FontStyle.Italic Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label1.Size = New System.Drawing.Size(749, 41)
		Me.Label1.Location = New System.Drawing.Point(0, 304)
		Me.Label1.TabIndex = 3
		Me.Label1.Enabled = True
		Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label1.UseMnemonic = True
		Me.Label1.Visible = True
		Me.Label1.AutoSize = False
		Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label1.Name = "Label1"
		Me.Picture2.BackColor = System.Drawing.SystemColors.ActiveCaptionText
		Me.Picture2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Picture2.Size = New System.Drawing.Size(497, 113)
		Me.Picture2.Location = New System.Drawing.Point(16, 288)
		Me.Picture2.TabIndex = 1
		Me.Picture2.Dock = System.Windows.Forms.DockStyle.None
		Me.Picture2.CausesValidation = True
		Me.Picture2.Enabled = True
		Me.Picture2.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Picture2.Cursor = System.Windows.Forms.Cursors.Default
		Me.Picture2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Picture2.TabStop = True
		Me.Picture2.Visible = True
		Me.Picture2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Normal
		Me.Picture2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.Picture2.Name = "Picture2"
		Me.Controls.Add(Picture1)
		Me.Controls.Add(Picture2)
		Me.Picture1.Controls.Add(txtICAO15)
		Me.Picture1.Controls.Add(txtICAO14)
		Me.Picture1.Controls.Add(txtICAO3)
		Me.Picture1.Controls.Add(txtICAO1)
		Me.Picture1.Controls.Add(txtDate)
		Me.Picture1.Controls.Add(txtICAO2)
		Me.Picture1.Controls.Add(txtICAO)
		Me.Picture1.Controls.Add(txtClient)
		Me.Picture1.Controls.Add(txtICAO4)
		Me.Picture1.Controls.Add(txtICAO6)
		Me.Picture1.Controls.Add(txtICAO10)
		Me.Picture1.Controls.Add(txtICAO8)
		Me.Picture1.Controls.Add(txtICAO12)
		Me.Picture1.Controls.Add(txtICAO9)
		Me.Picture1.Controls.Add(txtICAO11)
		Me.Picture1.Controls.Add(txtICAO7)
		Me.Picture1.Controls.Add(txtICAO5)
		Me.Picture1.Controls.Add(txtICAO13)
		Me.Picture1.Controls.Add(cmdPrint)
		Me.Picture1.Controls.Add(Label2)
		Me.Picture1.Controls.Add(Label11)
		Me.Picture1.Controls.Add(Line1)
		Me.Picture1.Controls.Add(Label14)
		Me.Picture1.Controls.Add(Label15)
		Me.Picture1.Controls.Add(Label16)
		Me.Picture1.Controls.Add(Label17)
		Me.Picture1.Controls.Add(Label18)
		Me.Picture1.Controls.Add(Label19)
		Me.Picture1.Controls.Add(Label20)
		Me.Picture1.Controls.Add(Label21)
		Me.Picture1.Controls.Add(Label22)
		Me.Picture1.Controls.Add(Label24)
		Me.Picture1.Controls.Add(Label8)
		Me.Picture1.Controls.Add(Label7)
		Me.Picture1.Controls.Add(Label6)
		Me.Picture1.Controls.Add(Label5)
		Me.Picture1.Controls.Add(Label4)
		Me.Picture1.Controls.Add(Label3)
		Me.Picture1.Controls.Add(Label1)
	End Sub
#End Region 
#Region "Upgrade Support "
	Private Shared m_vb6FormDefInstance As frmBidPrint1
	Private Shared m_InitializingDefInstance As Boolean
	Public Shared Property DefInstance() As frmBidPrint1
		Get
			If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
				m_InitializingDefInstance = True
				m_vb6FormDefInstance = New frmBidPrint1()
				m_InitializingDefInstance = False
			End If
			DefInstance = m_vb6FormDefInstance
		End Get
		Set
			m_vb6FormDefInstance = Value
		End Set
	End Property
#End Region 
	Dim dteEndDate As Date
	Dim strDest, strOrig, strVia As String
	Private Const twipFactor As Short = 1440
	Private Const WM_PAINT As Short = &HFs
	Private Const WM_PRINT As Short = &H317s
	Private Const PRF_CLIENT As Integer = &H4 ' Draw the window's client area.
	Private Const PRF_CHILDREN As Integer = &H10 ' Draw all visible child windows.
	Private Const PRF_OWNED As Integer = &H20 ' Draw all owned windows.
	
	Private Declare Function SendMessage Lib "user32"  Alias "SendMessageA"(ByVal hwnd As Integer, ByVal wMsg As Integer, ByVal wParam As Integer, ByVal lParam As Integer) As Integer
	
	Private Sub cmdPrint_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdPrint.Click
		
		Dim sWide, sTall As Single
		Dim rv As Integer
		'UPGRADE_ISSUE: Constant vbTwips was not upgraded. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2070"'
		'UPGRADE_ISSUE: Form property frmBidPrint1.ScaleMode is not supported. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2038"'
        'Me.ScaleMode = vbTwips ' default
		sWide = 8.5
		sTall = 11 ' or 14, etc.
		Me.Width = VB6.TwipsToPixelsX(twipFactor * sWide)
		Me.Height = VB6.TwipsToPixelsY(twipFactor * sTall)
		cmdPrint.Visible = False
		
		With Picture1
			.Top = 0
			.Left = 0
			.Width = VB6.TwipsToPixelsX(twipFactor * sWide)
			.Height = VB6.TwipsToPixelsY(twipFactor * sTall)
		End With
		
		With Picture2
			.Top = 0
			.Left = 0
			.Width = VB6.TwipsToPixelsX(twipFactor * sWide)
			.Height = VB6.TwipsToPixelsY(twipFactor * sTall)
		End With
		
		Me.Visible = True
		System.Windows.Forms.Application.DoEvents()
		Picture2.Visible = False
		Picture1.Focus()
		'UPGRADE_ISSUE: PictureBox property Picture2.AutoRedraw was not upgraded. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2064"'
        'Picture2.AutoRedraw = True
		'UPGRADE_ISSUE: PictureBox property Picture2.hDC was not upgraded. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2064"'
        'rv = SendMessage(Picture1.Handle.ToInt32, WM_PAINT, Picture2.hDC, 0)
		'UPGRADE_ISSUE: PictureBox property Picture2.hDC was not upgraded. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2064"'
        'rv = SendMessage(Picture1.Handle.ToInt32, WM_PRINT, Picture2.hDC, PRF_CHILDREN + PRF_CLIENT + PRF_OWNED)
		'UPGRADE_ISSUE: PictureBox property Picture2.Image was not upgraded. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2064"'
		Picture2.Image = Picture2.Image
		'UPGRADE_ISSUE: PictureBox property Picture2.AutoRedraw was not upgraded. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2064"'
        'Picture2.AutoRedraw = False
		
		'UPGRADE_ISSUE: Printer object was not upgraded. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2068"'
		'UPGRADE_ISSUE: Printer method Printer.Print was not upgraded. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2069"'
        'Printer.Print("")
		'UPGRADE_ISSUE: Printer method Printer.PaintPicture was not upgraded. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2069"'
        'Printer.PaintPicture(Picture2.Image, 0, 0)
		
		'UPGRADE_ISSUE: Printer method Printer.EndDoc was not upgraded. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2069"'
        'Printer.EndDoc()
		End
		
	End Sub
	
	'UPGRADE_WARNING: Form event frmBidPrint1.Activate has a new behavior. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2065"'
	Private Sub frmBidPrint1_Activated(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Activated
		Call cmdPrint_Click(cmdPrint, New System.EventArgs())
	End Sub
	
	Private Sub frmBidPrint1_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		
		txtClient.Text = frmCust.DefInstance.txtCompany.Text
		txtDate.Text = CStr(Today)
		
		If frmBidCalc1.DefInstance.cmbICAO.Text = "Other" Then
			txtICAO.Text = frmBidCalc1.DefInstance.txtICAO.Text
		Else
			txtICAO.Text = frmBidCalc1.DefInstance.cmbICAO.Text
		End If
		
		If frmBidCalc1.DefInstance.cmbICAO1.Text = "Other" Then
			txtICAO1.Text = frmBidCalc1.DefInstance.txtICAO1.Text
			txtICAO2.Text = frmBidCalc1.DefInstance.txtICAO2.Text
		Else
			txtICAO1.Text = frmBidCalc1.DefInstance.cmbICAO1.Text
			txtICAO2.Text = frmBidCalc1.DefInstance.cmbICAO2.Text
		End If
		
		If frmBidCalc1.DefInstance.cmbICAO3.Text <> "" Then
			
			If frmBidCalc1.DefInstance.cmbICAO3.Text = "Other" Then
				txtICAO3.Text = frmBidCalc1.DefInstance.txtICAO3.Text
				txtICAO4.Text = frmBidCalc1.DefInstance.txtICAO4.Text
			Else
				txtICAO3.Text = frmBidCalc1.DefInstance.cmbICAO3.Text
				txtICAO4.Text = frmBidCalc1.DefInstance.cmbICAO4.Text
			End If
			
		End If
		
		If frmBidCalc1.DefInstance.cmbICAO5.Text <> "" Then
			
			If frmBidCalc1.DefInstance.cmbICAO5.Text = "Other" Then
				txtICAO5.Text = frmBidCalc1.DefInstance.txtICAO5.Text
				txtICAO6.Text = frmBidCalc1.DefInstance.txtICAO6.Text
			Else
				txtICAO5.Text = frmBidCalc1.DefInstance.cmbICAO5.Text
				txtICAO6.Text = frmBidCalc1.DefInstance.cmbICAO6.Text
			End If
			
		End If
		
		If frmBidCalc1.DefInstance.cmbICAO7.Text <> "" Then
			
			If frmBidCalc1.DefInstance.cmbICAO7.Text = "Other" Then
				txtICAO7.Text = frmBidCalc1.DefInstance.txtICAO7.Text
				txtICAO8.Text = frmBidCalc1.DefInstance.txtICAO8.Text
			Else
				txtICAO7.Text = frmBidCalc1.DefInstance.cmbICAO7.Text
				txtICAO8.Text = frmBidCalc1.DefInstance.cmbICAO8.Text
			End If
			
		End If
		
		If frmBidCalc1.DefInstance.cmbICAO9.Text <> "" Then
			
			If frmBidCalc1.DefInstance.cmbICAO9.Text = "Other" Then
				txtICAO9.Text = frmBidCalc1.DefInstance.txtICAO9.Text
				txtICAO10.Text = frmBidCalc1.DefInstance.txtICAO10.Text
			Else
				txtICAO9.Text = frmBidCalc1.DefInstance.cmbICAO9.Text
				txtICAO10.Text = frmBidCalc1.DefInstance.cmbICAO10.Text
			End If
			
		End If
		
		If frmBidCalc1.DefInstance.cmbICAO11.Text <> "" Then
			
			If frmBidCalc1.DefInstance.cmbICAO11.Text = "Other" Then
				txtICAO11.Text = frmBidCalc1.DefInstance.txtICAO11.Text
				txtICAO12.Text = frmBidCalc1.DefInstance.txtICAO12.Text
			Else
				txtICAO11.Text = frmBidCalc1.DefInstance.cmbICAO11.Text
				txtICAO12.Text = frmBidCalc1.DefInstance.cmbICAO12.Text
			End If
			
		End If
		
		If frmBidCalc1.DefInstance.cmbICAO13.Text <> "" Then
			
			If frmBidCalc1.DefInstance.cmbICAO13.Text = "Other" Then
				txtICAO13.Text = frmBidCalc1.DefInstance.txtICAO13.Text
				txtICAO14.Text = frmBidCalc1.DefInstance.txtICAO14.Text
			Else
				txtICAO13.Text = frmBidCalc1.DefInstance.cmbICAO13.Text
				txtICAO14.Text = frmBidCalc1.DefInstance.cmbICAO14.Text
			End If
			
		End If
		
		If frmBidCalc1.DefInstance.cmbICAO15.Text <> "" Then
			
			If frmBidCalc1.DefInstance.cmbICAO15.Text = "Other" Then
				txtICAO15.Text = frmBidCalc1.DefInstance.txtICAO15.Text
			Else
				txtICAO15.Text = frmBidCalc1.DefInstance.cmbICAO15.Text
			End If
			
		End If
		
	End Sub
End Class