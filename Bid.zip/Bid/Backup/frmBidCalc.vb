Option Strict Off
Option Explicit On
Friend Class frmBidCalc
	Inherits System.Windows.Forms.Form
#Region "Windows Form Designer generated code "
	Public Sub New()
		MyBase.New()
		If m_vb6FormDefInstance Is Nothing Then
			If m_InitializingDefInstance Then
				m_vb6FormDefInstance = Me
			Else
				Try 
					'For the start-up form, the first instance created is the default instance.
					If System.Reflection.Assembly.GetExecutingAssembly.EntryPoint.DeclaringType Is Me.GetType Then
						m_vb6FormDefInstance = Me
					End If
				Catch
				End Try
			End If
		End If
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents txtMU As System.Windows.Forms.TextBox
	Public WithEvents txtRadio As System.Windows.Forms.TextBox
	Public WithEvents txtTank As System.Windows.Forms.TextBox
	Public WithEvents txtBidInsTotal As System.Windows.Forms.TextBox
	Public WithEvents txtInsurance As System.Windows.Forms.TextBox
	Public WithEvents txtOrig As System.Windows.Forms.TextBox
	Public WithEvents txtDest As System.Windows.Forms.TextBox
	Public WithEvents txtTotalFuelCost As System.Windows.Forms.TextBox
	Public WithEvents txtBidTotal As System.Windows.Forms.TextBox
	Public WithEvents txtER As System.Windows.Forms.TextBox
	Public WithEvents txtCustComm As System.Windows.Forms.TextBox
	Public WithEvents txtCustoms As System.Windows.Forms.TextBox
	Public WithEvents txtLanding As System.Windows.Forms.TextBox
	Public WithEvents txtAF3 As System.Windows.Forms.TextBox
	Public WithEvents txtAF2 As System.Windows.Forms.TextBox
	Public WithEvents txtAF1 As System.Windows.Forms.TextBox
	Public WithEvents txtCrewPD3 As System.Windows.Forms.TextBox
	Public WithEvents txtCrewPD2 As System.Windows.Forms.TextBox
	Public WithEvents txtCrewPD1 As System.Windows.Forms.TextBox
	Public WithEvents txtCrew3 As System.Windows.Forms.TextBox
	Public WithEvents txtCrew2 As System.Windows.Forms.TextBox
	Public WithEvents txtCrew1 As System.Windows.Forms.TextBox
	Public WithEvents txtDaysAway As System.Windows.Forms.TextBox
	Public WithEvents txtPerDiem As System.Windows.Forms.TextBox
	Public WithEvents txtTotalFuel As System.Windows.Forms.TextBox
	Public WithEvents txtFuelCost As System.Windows.Forms.TextBox
	Public WithEvents txtRes As System.Windows.Forms.TextBox
	Public WithEvents txtEorW As System.Windows.Forms.TextBox
	Public WithEvents txtTotal As System.Windows.Forms.TextBox
	Public WithEvents txtCalc As System.Windows.Forms.TextBox
	Public WithEvents txtGal As System.Windows.Forms.TextBox
	Public WithEvents txtSpeed As System.Windows.Forms.TextBox
	Public WithEvents txtFuel As System.Windows.Forms.TextBox
	Public WithEvents cmbAC As System.Windows.Forms.ComboBox
	Public WithEvents txtAC As System.Windows.Forms.TextBox
	Public WithEvents cmdExit As System.Windows.Forms.Label
	Public WithEvents cmdBack As System.Windows.Forms.Label
	Public WithEvents cmdPrint As System.Windows.Forms.Label
	Public WithEvents Label2 As System.Windows.Forms.Label
	Public WithEvents Label1 As System.Windows.Forms.Label
	Public WithEvents Label29 As System.Windows.Forms.Label
	Public WithEvents Label28 As System.Windows.Forms.Label
	Public WithEvents Label27 As System.Windows.Forms.Label
	Public WithEvents Label26 As System.Windows.Forms.Label
	Public WithEvents Label25 As System.Windows.Forms.Label
	Public WithEvents Label6 As System.Windows.Forms.Label
	Public WithEvents Label4 As System.Windows.Forms.Label
	Public WithEvents Label5 As System.Windows.Forms.Label
	Public WithEvents Label24 As System.Windows.Forms.Label
	Public WithEvents Label23 As System.Windows.Forms.Label
	Public WithEvents Label22 As System.Windows.Forms.Label
	Public WithEvents Label21 As System.Windows.Forms.Label
	Public WithEvents Label20 As System.Windows.Forms.Label
	Public WithEvents Label19 As System.Windows.Forms.Label
	Public WithEvents Label18 As System.Windows.Forms.Label
	Public WithEvents Label17 As System.Windows.Forms.Label
	Public WithEvents Label16 As System.Windows.Forms.Label
	Public WithEvents Label15 As System.Windows.Forms.Label
	Public WithEvents Label14 As System.Windows.Forms.Label
	Public WithEvents Label13 As System.Windows.Forms.Label
	Public WithEvents Label12 As System.Windows.Forms.Label
	Public WithEvents Label11 As System.Windows.Forms.Label
	Public WithEvents Label10 As System.Windows.Forms.Label
	Public WithEvents Label9 As System.Windows.Forms.Label
	Public WithEvents Label7 As System.Windows.Forms.Label
	Public WithEvents Label8 As System.Windows.Forms.Label
	Public WithEvents Label3 As System.Windows.Forms.Label
	Public WithEvents Image3 As System.Windows.Forms.PictureBox
	Public WithEvents Image2 As System.Windows.Forms.PictureBox
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmBidCalc))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.txtMU = New System.Windows.Forms.TextBox
        Me.txtRadio = New System.Windows.Forms.TextBox
        Me.txtTank = New System.Windows.Forms.TextBox
        Me.txtBidInsTotal = New System.Windows.Forms.TextBox
        Me.txtInsurance = New System.Windows.Forms.TextBox
        Me.txtOrig = New System.Windows.Forms.TextBox
        Me.txtDest = New System.Windows.Forms.TextBox
        Me.txtTotalFuelCost = New System.Windows.Forms.TextBox
        Me.txtBidTotal = New System.Windows.Forms.TextBox
        Me.txtER = New System.Windows.Forms.TextBox
        Me.txtCustComm = New System.Windows.Forms.TextBox
        Me.txtCustoms = New System.Windows.Forms.TextBox
        Me.txtLanding = New System.Windows.Forms.TextBox
        Me.txtAF3 = New System.Windows.Forms.TextBox
        Me.txtAF2 = New System.Windows.Forms.TextBox
        Me.txtAF1 = New System.Windows.Forms.TextBox
        Me.txtCrewPD3 = New System.Windows.Forms.TextBox
        Me.txtCrewPD2 = New System.Windows.Forms.TextBox
        Me.txtCrewPD1 = New System.Windows.Forms.TextBox
        Me.txtCrew3 = New System.Windows.Forms.TextBox
        Me.txtCrew2 = New System.Windows.Forms.TextBox
        Me.txtCrew1 = New System.Windows.Forms.TextBox
        Me.txtDaysAway = New System.Windows.Forms.TextBox
        Me.txtPerDiem = New System.Windows.Forms.TextBox
        Me.txtTotalFuel = New System.Windows.Forms.TextBox
        Me.txtFuelCost = New System.Windows.Forms.TextBox
        Me.txtRes = New System.Windows.Forms.TextBox
        Me.txtEorW = New System.Windows.Forms.TextBox
        Me.txtTotal = New System.Windows.Forms.TextBox
        Me.txtCalc = New System.Windows.Forms.TextBox
        Me.txtGal = New System.Windows.Forms.TextBox
        Me.txtSpeed = New System.Windows.Forms.TextBox
        Me.txtFuel = New System.Windows.Forms.TextBox
        Me.cmbAC = New System.Windows.Forms.ComboBox
        Me.txtAC = New System.Windows.Forms.TextBox
        Me.cmdExit = New System.Windows.Forms.Label
        Me.cmdBack = New System.Windows.Forms.Label
        Me.cmdPrint = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label29 = New System.Windows.Forms.Label
        Me.Label28 = New System.Windows.Forms.Label
        Me.Label27 = New System.Windows.Forms.Label
        Me.Label26 = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label24 = New System.Windows.Forms.Label
        Me.Label23 = New System.Windows.Forms.Label
        Me.Label22 = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Image3 = New System.Windows.Forms.PictureBox
        Me.Image2 = New System.Windows.Forms.PictureBox
        Me.SuspendLayout()
        '
        'txtMU
        '
        Me.txtMU.AcceptsReturn = True
        Me.txtMU.AutoSize = False
        Me.txtMU.BackColor = System.Drawing.SystemColors.Window
        Me.txtMU.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtMU.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMU.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtMU.Location = New System.Drawing.Point(632, 384)
        Me.txtMU.MaxLength = 0
        Me.txtMU.Name = "txtMU"
        Me.txtMU.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtMU.Size = New System.Drawing.Size(114, 26)
        Me.txtMU.TabIndex = 26
        Me.txtMU.Text = ".333"
        '
        'txtRadio
        '
        Me.txtRadio.AcceptsReturn = True
        Me.txtRadio.AutoSize = False
        Me.txtRadio.BackColor = System.Drawing.SystemColors.Window
        Me.txtRadio.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtRadio.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRadio.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtRadio.Location = New System.Drawing.Point(632, 144)
        Me.txtRadio.MaxLength = 0
        Me.txtRadio.Name = "txtRadio"
        Me.txtRadio.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtRadio.Size = New System.Drawing.Size(114, 26)
        Me.txtRadio.TabIndex = 20
        Me.txtRadio.Text = "0.00"
        '
        'txtTank
        '
        Me.txtTank.AcceptsReturn = True
        Me.txtTank.AutoSize = False
        Me.txtTank.BackColor = System.Drawing.SystemColors.Window
        Me.txtTank.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTank.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTank.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTank.Location = New System.Drawing.Point(632, 104)
        Me.txtTank.MaxLength = 0
        Me.txtTank.Name = "txtTank"
        Me.txtTank.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtTank.Size = New System.Drawing.Size(114, 26)
        Me.txtTank.TabIndex = 19
        Me.txtTank.Text = "0.00"
        '
        'txtBidInsTotal
        '
        Me.txtBidInsTotal.AcceptsReturn = True
        Me.txtBidInsTotal.AutoSize = False
        Me.txtBidInsTotal.BackColor = System.Drawing.SystemColors.Window
        Me.txtBidInsTotal.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtBidInsTotal.Font = New System.Drawing.Font("Arial", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBidInsTotal.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtBidInsTotal.Location = New System.Drawing.Point(632, 456)
        Me.txtBidInsTotal.MaxLength = 0
        Me.txtBidInsTotal.Name = "txtBidInsTotal"
        Me.txtBidInsTotal.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtBidInsTotal.Size = New System.Drawing.Size(114, 24)
        Me.txtBidInsTotal.TabIndex = 28
        Me.txtBidInsTotal.Text = ""
        '
        'txtInsurance
        '
        Me.txtInsurance.AcceptsReturn = True
        Me.txtInsurance.AutoSize = False
        Me.txtInsurance.BackColor = System.Drawing.SystemColors.Window
        Me.txtInsurance.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtInsurance.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtInsurance.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtInsurance.Location = New System.Drawing.Point(632, 344)
        Me.txtInsurance.MaxLength = 0
        Me.txtInsurance.Name = "txtInsurance"
        Me.txtInsurance.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtInsurance.Size = New System.Drawing.Size(114, 26)
        Me.txtInsurance.TabIndex = 25
        Me.txtInsurance.Text = "0.00"
        '
        'txtOrig
        '
        Me.txtOrig.AcceptsReturn = True
        Me.txtOrig.AutoSize = False
        Me.txtOrig.BackColor = System.Drawing.SystemColors.Window
        Me.txtOrig.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtOrig.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtOrig.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtOrig.Location = New System.Drawing.Point(752, 336)
        Me.txtOrig.MaxLength = 0
        Me.txtOrig.Name = "txtOrig"
        Me.txtOrig.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtOrig.Size = New System.Drawing.Size(60, 26)
        Me.txtOrig.TabIndex = 53
        Me.txtOrig.Text = ""
        Me.txtOrig.Visible = False
        '
        'txtDest
        '
        Me.txtDest.AcceptsReturn = True
        Me.txtDest.AutoSize = False
        Me.txtDest.BackColor = System.Drawing.SystemColors.Window
        Me.txtDest.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtDest.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDest.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtDest.Location = New System.Drawing.Point(752, 336)
        Me.txtDest.MaxLength = 0
        Me.txtDest.Name = "txtDest"
        Me.txtDest.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtDest.Size = New System.Drawing.Size(63, 26)
        Me.txtDest.TabIndex = 52
        Me.txtDest.Text = ""
        Me.txtDest.Visible = False
        '
        'txtTotalFuelCost
        '
        Me.txtTotalFuelCost.AcceptsReturn = True
        Me.txtTotalFuelCost.AutoSize = False
        Me.txtTotalFuelCost.BackColor = System.Drawing.SystemColors.Window
        Me.txtTotalFuelCost.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTotalFuelCost.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalFuelCost.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTotalFuelCost.Location = New System.Drawing.Point(88, 344)
        Me.txtTotalFuelCost.MaxLength = 0
        Me.txtTotalFuelCost.Name = "txtTotalFuelCost"
        Me.txtTotalFuelCost.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtTotalFuelCost.Size = New System.Drawing.Size(145, 26)
        Me.txtTotalFuelCost.TabIndex = 7
        Me.txtTotalFuelCost.Text = "0.00"
        '
        'txtBidTotal
        '
        Me.txtBidTotal.AcceptsReturn = True
        Me.txtBidTotal.AutoSize = False
        Me.txtBidTotal.BackColor = System.Drawing.SystemColors.Window
        Me.txtBidTotal.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtBidTotal.Font = New System.Drawing.Font("Arial", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBidTotal.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtBidTotal.Location = New System.Drawing.Point(632, 424)
        Me.txtBidTotal.MaxLength = 0
        Me.txtBidTotal.Name = "txtBidTotal"
        Me.txtBidTotal.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtBidTotal.Size = New System.Drawing.Size(114, 24)
        Me.txtBidTotal.TabIndex = 27
        Me.txtBidTotal.Text = ""
        '
        'txtER
        '
        Me.txtER.AcceptsReturn = True
        Me.txtER.AutoSize = False
        Me.txtER.BackColor = System.Drawing.SystemColors.Window
        Me.txtER.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtER.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtER.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtER.Location = New System.Drawing.Point(632, 304)
        Me.txtER.MaxLength = 0
        Me.txtER.Name = "txtER"
        Me.txtER.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtER.Size = New System.Drawing.Size(114, 26)
        Me.txtER.TabIndex = 24
        Me.txtER.Text = "200.00"
        '
        'txtCustComm
        '
        Me.txtCustComm.AcceptsReturn = True
        Me.txtCustComm.AutoSize = False
        Me.txtCustComm.BackColor = System.Drawing.SystemColors.Window
        Me.txtCustComm.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCustComm.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCustComm.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCustComm.Location = New System.Drawing.Point(632, 264)
        Me.txtCustComm.MaxLength = 0
        Me.txtCustComm.Name = "txtCustComm"
        Me.txtCustComm.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtCustComm.Size = New System.Drawing.Size(114, 26)
        Me.txtCustComm.TabIndex = 23
        Me.txtCustComm.Text = "100.00"
        '
        'txtCustoms
        '
        Me.txtCustoms.AcceptsReturn = True
        Me.txtCustoms.AutoSize = False
        Me.txtCustoms.BackColor = System.Drawing.SystemColors.Window
        Me.txtCustoms.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCustoms.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCustoms.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCustoms.Location = New System.Drawing.Point(632, 224)
        Me.txtCustoms.MaxLength = 0
        Me.txtCustoms.Name = "txtCustoms"
        Me.txtCustoms.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtCustoms.Size = New System.Drawing.Size(114, 26)
        Me.txtCustoms.TabIndex = 22
        Me.txtCustoms.Text = "200.00"
        '
        'txtLanding
        '
        Me.txtLanding.AcceptsReturn = True
        Me.txtLanding.AutoSize = False
        Me.txtLanding.BackColor = System.Drawing.SystemColors.Window
        Me.txtLanding.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtLanding.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLanding.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtLanding.Location = New System.Drawing.Point(632, 184)
        Me.txtLanding.MaxLength = 0
        Me.txtLanding.Name = "txtLanding"
        Me.txtLanding.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtLanding.Size = New System.Drawing.Size(114, 26)
        Me.txtLanding.TabIndex = 21
        Me.txtLanding.Text = "200.00"
        '
        'txtAF3
        '
        Me.txtAF3.AcceptsReturn = True
        Me.txtAF3.AutoSize = False
        Me.txtAF3.BackColor = System.Drawing.SystemColors.Window
        Me.txtAF3.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtAF3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAF3.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtAF3.Location = New System.Drawing.Point(376, 280)
        Me.txtAF3.MaxLength = 0
        Me.txtAF3.Name = "txtAF3"
        Me.txtAF3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtAF3.Size = New System.Drawing.Size(80, 26)
        Me.txtAF3.TabIndex = 15
        Me.txtAF3.Text = "0.00"
        '
        'txtAF2
        '
        Me.txtAF2.AcceptsReturn = True
        Me.txtAF2.AutoSize = False
        Me.txtAF2.BackColor = System.Drawing.SystemColors.Window
        Me.txtAF2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtAF2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAF2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtAF2.Location = New System.Drawing.Point(376, 248)
        Me.txtAF2.MaxLength = 0
        Me.txtAF2.Name = "txtAF2"
        Me.txtAF2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtAF2.Size = New System.Drawing.Size(80, 26)
        Me.txtAF2.TabIndex = 13
        Me.txtAF2.Text = "0.00"
        '
        'txtAF1
        '
        Me.txtAF1.AcceptsReturn = True
        Me.txtAF1.AutoSize = False
        Me.txtAF1.BackColor = System.Drawing.SystemColors.Window
        Me.txtAF1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtAF1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAF1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtAF1.Location = New System.Drawing.Point(376, 216)
        Me.txtAF1.MaxLength = 0
        Me.txtAF1.Name = "txtAF1"
        Me.txtAF1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtAF1.Size = New System.Drawing.Size(80, 26)
        Me.txtAF1.TabIndex = 11
        Me.txtAF1.Text = "0.00"
        '
        'txtCrewPD3
        '
        Me.txtCrewPD3.AcceptsReturn = True
        Me.txtCrewPD3.AutoSize = False
        Me.txtCrewPD3.BackColor = System.Drawing.SystemColors.Window
        Me.txtCrewPD3.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCrewPD3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCrewPD3.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCrewPD3.Location = New System.Drawing.Point(376, 392)
        Me.txtCrewPD3.MaxLength = 0
        Me.txtCrewPD3.Name = "txtCrewPD3"
        Me.txtCrewPD3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtCrewPD3.Size = New System.Drawing.Size(80, 26)
        Me.txtCrewPD3.TabIndex = 18
        Me.txtCrewPD3.Text = "0.00"
        '
        'txtCrewPD2
        '
        Me.txtCrewPD2.AcceptsReturn = True
        Me.txtCrewPD2.AutoSize = False
        Me.txtCrewPD2.BackColor = System.Drawing.SystemColors.Window
        Me.txtCrewPD2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCrewPD2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCrewPD2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCrewPD2.Location = New System.Drawing.Point(376, 360)
        Me.txtCrewPD2.MaxLength = 0
        Me.txtCrewPD2.Name = "txtCrewPD2"
        Me.txtCrewPD2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtCrewPD2.Size = New System.Drawing.Size(80, 26)
        Me.txtCrewPD2.TabIndex = 17
        Me.txtCrewPD2.Text = "0.00"
        '
        'txtCrewPD1
        '
        Me.txtCrewPD1.AcceptsReturn = True
        Me.txtCrewPD1.AutoSize = False
        Me.txtCrewPD1.BackColor = System.Drawing.SystemColors.Window
        Me.txtCrewPD1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCrewPD1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCrewPD1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCrewPD1.Location = New System.Drawing.Point(376, 328)
        Me.txtCrewPD1.MaxLength = 0
        Me.txtCrewPD1.Name = "txtCrewPD1"
        Me.txtCrewPD1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtCrewPD1.Size = New System.Drawing.Size(80, 26)
        Me.txtCrewPD1.TabIndex = 16
        Me.txtCrewPD1.Text = "0.00"
        '
        'txtCrew3
        '
        Me.txtCrew3.AcceptsReturn = True
        Me.txtCrew3.AutoSize = False
        Me.txtCrew3.BackColor = System.Drawing.SystemColors.Window
        Me.txtCrew3.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCrew3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCrew3.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCrew3.Location = New System.Drawing.Point(376, 168)
        Me.txtCrew3.MaxLength = 0
        Me.txtCrew3.Name = "txtCrew3"
        Me.txtCrew3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtCrew3.Size = New System.Drawing.Size(80, 26)
        Me.txtCrew3.TabIndex = 14
        Me.txtCrew3.Text = "0.00"
        '
        'txtCrew2
        '
        Me.txtCrew2.AcceptsReturn = True
        Me.txtCrew2.AutoSize = False
        Me.txtCrew2.BackColor = System.Drawing.SystemColors.Window
        Me.txtCrew2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCrew2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCrew2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCrew2.Location = New System.Drawing.Point(376, 136)
        Me.txtCrew2.MaxLength = 0
        Me.txtCrew2.Name = "txtCrew2"
        Me.txtCrew2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtCrew2.Size = New System.Drawing.Size(80, 26)
        Me.txtCrew2.TabIndex = 12
        Me.txtCrew2.Text = "0.00"
        '
        'txtCrew1
        '
        Me.txtCrew1.AcceptsReturn = True
        Me.txtCrew1.AutoSize = False
        Me.txtCrew1.BackColor = System.Drawing.SystemColors.Window
        Me.txtCrew1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCrew1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCrew1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCrew1.Location = New System.Drawing.Point(376, 104)
        Me.txtCrew1.MaxLength = 0
        Me.txtCrew1.Name = "txtCrew1"
        Me.txtCrew1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtCrew1.Size = New System.Drawing.Size(80, 26)
        Me.txtCrew1.TabIndex = 10
        Me.txtCrew1.Text = "0.00"
        '
        'txtDaysAway
        '
        Me.txtDaysAway.AcceptsReturn = True
        Me.txtDaysAway.AutoSize = False
        Me.txtDaysAway.BackColor = System.Drawing.SystemColors.Window
        Me.txtDaysAway.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtDaysAway.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDaysAway.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtDaysAway.Location = New System.Drawing.Point(88, 424)
        Me.txtDaysAway.MaxLength = 0
        Me.txtDaysAway.Name = "txtDaysAway"
        Me.txtDaysAway.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtDaysAway.Size = New System.Drawing.Size(145, 26)
        Me.txtDaysAway.TabIndex = 9
        Me.txtDaysAway.Text = "0"
        '
        'txtPerDiem
        '
        Me.txtPerDiem.AcceptsReturn = True
        Me.txtPerDiem.AutoSize = False
        Me.txtPerDiem.BackColor = System.Drawing.SystemColors.Window
        Me.txtPerDiem.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtPerDiem.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPerDiem.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtPerDiem.Location = New System.Drawing.Point(88, 384)
        Me.txtPerDiem.MaxLength = 0
        Me.txtPerDiem.Name = "txtPerDiem"
        Me.txtPerDiem.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtPerDiem.Size = New System.Drawing.Size(145, 26)
        Me.txtPerDiem.TabIndex = 8
        Me.txtPerDiem.Text = "0.00"
        '
        'txtTotalFuel
        '
        Me.txtTotalFuel.AcceptsReturn = True
        Me.txtTotalFuel.AutoSize = False
        Me.txtTotalFuel.BackColor = System.Drawing.SystemColors.Window
        Me.txtTotalFuel.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTotalFuel.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalFuel.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTotalFuel.Location = New System.Drawing.Point(88, 304)
        Me.txtTotalFuel.MaxLength = 0
        Me.txtTotalFuel.Name = "txtTotalFuel"
        Me.txtTotalFuel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtTotalFuel.Size = New System.Drawing.Size(145, 26)
        Me.txtTotalFuel.TabIndex = 6
        Me.txtTotalFuel.Text = "0"
        '
        'txtFuelCost
        '
        Me.txtFuelCost.AcceptsReturn = True
        Me.txtFuelCost.AutoSize = False
        Me.txtFuelCost.BackColor = System.Drawing.SystemColors.Window
        Me.txtFuelCost.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtFuelCost.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFuelCost.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtFuelCost.Location = New System.Drawing.Point(88, 264)
        Me.txtFuelCost.MaxLength = 0
        Me.txtFuelCost.Name = "txtFuelCost"
        Me.txtFuelCost.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtFuelCost.Size = New System.Drawing.Size(145, 26)
        Me.txtFuelCost.TabIndex = 5
        Me.txtFuelCost.Text = "2.50"
        '
        'txtRes
        '
        Me.txtRes.AcceptsReturn = True
        Me.txtRes.AutoSize = False
        Me.txtRes.BackColor = System.Drawing.SystemColors.Window
        Me.txtRes.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtRes.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRes.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtRes.Location = New System.Drawing.Point(88, 184)
        Me.txtRes.MaxLength = 0
        Me.txtRes.Name = "txtRes"
        Me.txtRes.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtRes.Size = New System.Drawing.Size(145, 26)
        Me.txtRes.TabIndex = 3
        Me.txtRes.Text = "3"
        '
        'txtEorW
        '
        Me.txtEorW.AcceptsReturn = True
        Me.txtEorW.AutoSize = False
        Me.txtEorW.BackColor = System.Drawing.SystemColors.Window
        Me.txtEorW.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtEorW.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEorW.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtEorW.Location = New System.Drawing.Point(88, 224)
        Me.txtEorW.MaxLength = 0
        Me.txtEorW.Name = "txtEorW"
        Me.txtEorW.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtEorW.Size = New System.Drawing.Size(145, 26)
        Me.txtEorW.TabIndex = 4
        Me.txtEorW.Text = "0"
        '
        'txtTotal
        '
        Me.txtTotal.AcceptsReturn = True
        Me.txtTotal.AutoSize = False
        Me.txtTotal.BackColor = System.Drawing.SystemColors.Window
        Me.txtTotal.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTotal.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotal.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTotal.Location = New System.Drawing.Point(88, 144)
        Me.txtTotal.MaxLength = 0
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtTotal.Size = New System.Drawing.Size(145, 26)
        Me.txtTotal.TabIndex = 2
        Me.txtTotal.Text = ""
        '
        'txtCalc
        '
        Me.txtCalc.AcceptsReturn = True
        Me.txtCalc.AutoSize = False
        Me.txtCalc.BackColor = System.Drawing.SystemColors.Window
        Me.txtCalc.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCalc.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCalc.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCalc.Location = New System.Drawing.Point(752, 336)
        Me.txtCalc.MaxLength = 0
        Me.txtCalc.Name = "txtCalc"
        Me.txtCalc.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtCalc.Size = New System.Drawing.Size(53, 26)
        Me.txtCalc.TabIndex = 33
        Me.txtCalc.Text = "1"
        Me.txtCalc.Visible = False
        '
        'txtGal
        '
        Me.txtGal.AcceptsReturn = True
        Me.txtGal.AutoSize = False
        Me.txtGal.BackColor = System.Drawing.SystemColors.Window
        Me.txtGal.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtGal.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGal.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtGal.Location = New System.Drawing.Point(752, 336)
        Me.txtGal.MaxLength = 0
        Me.txtGal.Name = "txtGal"
        Me.txtGal.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtGal.Size = New System.Drawing.Size(45, 26)
        Me.txtGal.TabIndex = 30
        Me.txtGal.Text = "0"
        Me.txtGal.Visible = False
        '
        'txtSpeed
        '
        Me.txtSpeed.AcceptsReturn = True
        Me.txtSpeed.AutoSize = False
        Me.txtSpeed.BackColor = System.Drawing.SystemColors.Window
        Me.txtSpeed.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSpeed.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSpeed.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSpeed.Location = New System.Drawing.Point(712, 336)
        Me.txtSpeed.MaxLength = 0
        Me.txtSpeed.Name = "txtSpeed"
        Me.txtSpeed.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtSpeed.Size = New System.Drawing.Size(49, 26)
        Me.txtSpeed.TabIndex = 29
        Me.txtSpeed.Text = "1"
        Me.txtSpeed.Visible = False
        '
        'txtFuel
        '
        Me.txtFuel.AcceptsReturn = True
        Me.txtFuel.AutoSize = False
        Me.txtFuel.BackColor = System.Drawing.SystemColors.Window
        Me.txtFuel.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtFuel.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFuel.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtFuel.Location = New System.Drawing.Point(752, 336)
        Me.txtFuel.MaxLength = 0
        Me.txtFuel.Name = "txtFuel"
        Me.txtFuel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtFuel.Size = New System.Drawing.Size(53, 26)
        Me.txtFuel.TabIndex = 32
        Me.txtFuel.Text = ""
        Me.txtFuel.Visible = False
        '
        'cmbAC
        '
        Me.cmbAC.BackColor = System.Drawing.SystemColors.Window
        Me.cmbAC.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmbAC.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbAC.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbAC.Location = New System.Drawing.Point(88, 104)
        Me.cmbAC.Name = "cmbAC"
        Me.cmbAC.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmbAC.Size = New System.Drawing.Size(145, 22)
        Me.cmbAC.TabIndex = 0
        '
        'txtAC
        '
        Me.txtAC.AcceptsReturn = True
        Me.txtAC.AutoSize = False
        Me.txtAC.BackColor = System.Drawing.SystemColors.Window
        Me.txtAC.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtAC.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAC.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtAC.Location = New System.Drawing.Point(88, 104)
        Me.txtAC.MaxLength = 0
        Me.txtAC.Name = "txtAC"
        Me.txtAC.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtAC.Size = New System.Drawing.Size(145, 26)
        Me.txtAC.TabIndex = 1
        Me.txtAC.Text = ""
        '
        'cmdExit
        '
        Me.cmdExit.BackColor = System.Drawing.Color.Transparent
        Me.cmdExit.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdExit.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdExit.ForeColor = System.Drawing.Color.White
        Me.cmdExit.Location = New System.Drawing.Point(480, 495)
        Me.cmdExit.Name = "cmdExit"
        Me.cmdExit.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdExit.Size = New System.Drawing.Size(97, 27)
        Me.cmdExit.TabIndex = 66
        Me.cmdExit.Text = "E&xit"
        Me.cmdExit.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'cmdBack
        '
        Me.cmdBack.BackColor = System.Drawing.Color.Transparent
        Me.cmdBack.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdBack.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdBack.ForeColor = System.Drawing.Color.White
        Me.cmdBack.Location = New System.Drawing.Point(334, 495)
        Me.cmdBack.Name = "cmdBack"
        Me.cmdBack.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdBack.Size = New System.Drawing.Size(105, 27)
        Me.cmdBack.TabIndex = 65
        Me.cmdBack.Text = "&Back"
        Me.cmdBack.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'cmdPrint
        '
        Me.cmdPrint.BackColor = System.Drawing.Color.Transparent
        Me.cmdPrint.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdPrint.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdPrint.ForeColor = System.Drawing.Color.White
        Me.cmdPrint.Location = New System.Drawing.Point(184, 495)
        Me.cmdPrint.Name = "cmdPrint"
        Me.cmdPrint.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdPrint.Size = New System.Drawing.Size(113, 27)
        Me.cmdPrint.TabIndex = 64
        Me.cmdPrint.Text = "&Print"
        Me.cmdPrint.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(152, 48)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(521, 33)
        Me.Label2.TabIndex = 63
        Me.Label2.Text = "Bid Calculations"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Arial", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(152, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(521, 41)
        Me.Label1.TabIndex = 62
        Me.Label1.Text = "PILOT INTERNATIONAL"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label29
        '
        Me.Label29.BackColor = System.Drawing.Color.Transparent
        Me.Label29.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label29.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.ForeColor = System.Drawing.Color.White
        Me.Label29.Location = New System.Drawing.Point(560, 392)
        Me.Label29.Name = "Label29"
        Me.Label29.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label29.Size = New System.Drawing.Size(65, 25)
        Me.Label29.TabIndex = 61
        Me.Label29.Text = "Markup:"
        Me.Label29.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label28
        '
        Me.Label28.BackColor = System.Drawing.Color.Transparent
        Me.Label28.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label28.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.ForeColor = System.Drawing.Color.White
        Me.Label28.Location = New System.Drawing.Point(528, 152)
        Me.Label28.Name = "Label28"
        Me.Label28.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label28.Size = New System.Drawing.Size(97, 17)
        Me.Label28.TabIndex = 60
        Me.Label28.Text = "Radio Costs:"
        Me.Label28.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label27
        '
        Me.Label27.BackColor = System.Drawing.Color.Transparent
        Me.Label27.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label27.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.ForeColor = System.Drawing.Color.White
        Me.Label27.Location = New System.Drawing.Point(496, 112)
        Me.Label27.Name = "Label27"
        Me.Label27.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label27.Size = New System.Drawing.Size(129, 17)
        Me.Label27.TabIndex = 59
        Me.Label27.Text = "Tanking Costs:"
        Me.Label27.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label26
        '
        Me.Label26.BackColor = System.Drawing.Color.Transparent
        Me.Label26.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label26.Font = New System.Drawing.Font("Arial", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.ForeColor = System.Drawing.Color.White
        Me.Label26.Location = New System.Drawing.Point(534, 432)
        Me.Label26.Name = "Label26"
        Me.Label26.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label26.Size = New System.Drawing.Size(83, 17)
        Me.Label26.TabIndex = 58
        Me.Label26.Text = "Uninsured "
        Me.Label26.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label25
        '
        Me.Label25.BackColor = System.Drawing.Color.Transparent
        Me.Label25.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label25.Font = New System.Drawing.Font("Arial", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.ForeColor = System.Drawing.Color.White
        Me.Label25.Location = New System.Drawing.Point(534, 464)
        Me.Label25.Name = "Label25"
        Me.Label25.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label25.Size = New System.Drawing.Size(83, 17)
        Me.Label25.TabIndex = 57
        Me.Label25.Text = "Insured "
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label6.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(552, 352)
        Me.Label6.Name = "Label6"
        Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label6.Size = New System.Drawing.Size(73, 25)
        Me.Label6.TabIndex = 56
        Me.Label6.Text = "Insurance:"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label4.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label4.Location = New System.Drawing.Point(704, 344)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(41, 25)
        Me.Label4.TabIndex = 55
        Me.Label4.Text = "Orig:"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.Label4.Visible = False
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.SystemColors.Control
        Me.Label5.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label5.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label5.Location = New System.Drawing.Point(704, 336)
        Me.Label5.Name = "Label5"
        Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label5.Size = New System.Drawing.Size(41, 25)
        Me.Label5.TabIndex = 54
        Me.Label5.Text = "Dest:"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.Label5.Visible = False
        '
        'Label24
        '
        Me.Label24.BackColor = System.Drawing.Color.Transparent
        Me.Label24.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label24.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.Color.White
        Me.Label24.Location = New System.Drawing.Point(32, 336)
        Me.Label24.Name = "Label24"
        Me.Label24.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label24.Size = New System.Drawing.Size(49, 33)
        Me.Label24.TabIndex = 51
        Me.Label24.Text = "Fuel Cost:"
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label23
        '
        Me.Label23.BackColor = System.Drawing.Color.Transparent
        Me.Label23.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label23.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.Color.White
        Me.Label23.Location = New System.Drawing.Point(392, 448)
        Me.Label23.Name = "Label23"
        Me.Label23.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label23.Size = New System.Drawing.Size(113, 25)
        Me.Label23.TabIndex = 50
        Me.Label23.Text = "Bid Totals:"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label22
        '
        Me.Label22.BackColor = System.Drawing.Color.Transparent
        Me.Label22.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label22.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.White
        Me.Label22.Location = New System.Drawing.Point(488, 312)
        Me.Label22.Name = "Label22"
        Me.Label22.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label22.Size = New System.Drawing.Size(137, 17)
        Me.Label22.TabIndex = 49
        Me.Label22.Text = "Emergency Equip:"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label21
        '
        Me.Label21.BackColor = System.Drawing.Color.Transparent
        Me.Label21.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label21.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.White
        Me.Label21.Location = New System.Drawing.Point(496, 272)
        Me.Label21.Name = "Label21"
        Me.Label21.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label21.Size = New System.Drawing.Size(129, 17)
        Me.Label21.TabIndex = 48
        Me.Label21.Text = "Customer Comm:"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label20
        '
        Me.Label20.BackColor = System.Drawing.Color.Transparent
        Me.Label20.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label20.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.White
        Me.Label20.Location = New System.Drawing.Point(512, 232)
        Me.Label20.Name = "Label20"
        Me.Label20.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label20.Size = New System.Drawing.Size(113, 17)
        Me.Label20.TabIndex = 47
        Me.Label20.Text = "Customs Costs:"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label19
        '
        Me.Label19.BackColor = System.Drawing.Color.Transparent
        Me.Label19.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label19.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.White
        Me.Label19.Location = New System.Drawing.Point(512, 192)
        Me.Label19.Name = "Label19"
        Me.Label19.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label19.Size = New System.Drawing.Size(113, 25)
        Me.Label19.TabIndex = 46
        Me.Label19.Text = "Landing Costs:"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label18
        '
        Me.Label18.BackColor = System.Drawing.Color.Transparent
        Me.Label18.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label18.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.White
        Me.Label18.Location = New System.Drawing.Point(264, 224)
        Me.Label18.Name = "Label18"
        Me.Label18.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label18.Size = New System.Drawing.Size(105, 25)
        Me.Label18.TabIndex = 45
        Me.Label18.Text = "Airline Fares:"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label17
        '
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label17.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.White
        Me.Label17.Location = New System.Drawing.Point(264, 336)
        Me.Label17.Name = "Label17"
        Me.Label17.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label17.Size = New System.Drawing.Size(105, 25)
        Me.Label17.TabIndex = 44
        Me.Label17.Text = "Crew Per Diem:"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label16
        '
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label16.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.White
        Me.Label16.Location = New System.Drawing.Point(256, 112)
        Me.Label16.Name = "Label16"
        Me.Label16.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label16.Size = New System.Drawing.Size(113, 25)
        Me.Label16.TabIndex = 43
        Me.Label16.Text = "Crew Salaries:"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label15
        '
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label15.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.White
        Me.Label15.Location = New System.Drawing.Point(24, 416)
        Me.Label15.Name = "Label15"
        Me.Label15.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label15.Size = New System.Drawing.Size(57, 41)
        Me.Label15.TabIndex = 42
        Me.Label15.Text = "Days Away:"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label14
        '
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label14.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.White
        Me.Label14.Location = New System.Drawing.Point(32, 376)
        Me.Label14.Name = "Label14"
        Me.Label14.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label14.Size = New System.Drawing.Size(49, 41)
        Me.Label14.TabIndex = 41
        Me.Label14.Text = "Per Diem:"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label13
        '
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label13.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.White
        Me.Label13.Location = New System.Drawing.Point(0, 296)
        Me.Label13.Name = "Label13"
        Me.Label13.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label13.Size = New System.Drawing.Size(81, 41)
        Me.Label13.TabIndex = 40
        Me.Label13.Text = "Total Fuel Req:"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label12.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.White
        Me.Label12.Location = New System.Drawing.Point(8, 256)
        Me.Label12.Name = "Label12"
        Me.Label12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label12.Size = New System.Drawing.Size(73, 41)
        Me.Label12.TabIndex = 39
        Me.Label12.Text = "Avg Fuel Cost:"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.SystemColors.Control
        Me.Label11.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label11.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label11.Location = New System.Drawing.Point(704, 328)
        Me.Label11.Name = "Label11"
        Me.Label11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label11.Size = New System.Drawing.Size(73, 41)
        Me.Label11.TabIndex = 38
        Me.Label11.Text = "Fuel Per Hour:"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.Label11.Visible = False
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label10.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(8, 176)
        Me.Label10.Name = "Label10"
        Me.Label10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label10.Size = New System.Drawing.Size(73, 33)
        Me.Label10.TabIndex = 37
        Me.Label10.Text = "Res Flt Time:"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label9.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(16, 216)
        Me.Label9.Name = "Label9"
        Me.Label9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label9.Size = New System.Drawing.Size(65, 41)
        Me.Label9.TabIndex = 36
        Me.Label9.Text = "East or West:"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.SystemColors.Control
        Me.Label7.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label7.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label7.Location = New System.Drawing.Point(696, 336)
        Me.Label7.Name = "Label7"
        Me.Label7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label7.Size = New System.Drawing.Size(73, 17)
        Me.Label7.TabIndex = 35
        Me.Label7.Text = "Avg TAS:"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.Label7.Visible = False
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label8.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(8, 152)
        Me.Label8.Name = "Label8"
        Me.Label8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label8.Size = New System.Drawing.Size(73, 17)
        Me.Label8.TabIndex = 34
        Me.Label8.Text = "Total Dist:"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(8, 112)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(73, 25)
        Me.Label3.TabIndex = 31
        Me.Label3.Text = "Aircraft:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Image3
        '
        Me.Image3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Image3.Image = CType(resources.GetObject("Image3.Image"), System.Drawing.Image)
        Me.Image3.Location = New System.Drawing.Point(0, 489)
        Me.Image3.Name = "Image3"
        Me.Image3.Size = New System.Drawing.Size(775, 33)
        Me.Image3.TabIndex = 67
        Me.Image3.TabStop = False
        Me.Image3.Visible = False
        '
        'Image2
        '
        Me.Image2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Image2.Image = CType(resources.GetObject("Image2.Image"), System.Drawing.Image)
        Me.Image2.Location = New System.Drawing.Point(0, 489)
        Me.Image2.Name = "Image2"
        Me.Image2.Size = New System.Drawing.Size(775, 33)
        Me.Image2.TabIndex = 68
        Me.Image2.TabStop = False
        Me.Image2.Visible = False
        '
        'frmBidCalc
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(8, 19)
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(775, 523)
        Me.Controls.Add(Me.txtMU)
        Me.Controls.Add(Me.txtRadio)
        Me.Controls.Add(Me.txtTank)
        Me.Controls.Add(Me.txtBidInsTotal)
        Me.Controls.Add(Me.txtInsurance)
        Me.Controls.Add(Me.txtOrig)
        Me.Controls.Add(Me.txtDest)
        Me.Controls.Add(Me.txtTotalFuelCost)
        Me.Controls.Add(Me.txtBidTotal)
        Me.Controls.Add(Me.txtER)
        Me.Controls.Add(Me.txtCustComm)
        Me.Controls.Add(Me.txtCustoms)
        Me.Controls.Add(Me.txtLanding)
        Me.Controls.Add(Me.txtAF3)
        Me.Controls.Add(Me.txtAF2)
        Me.Controls.Add(Me.txtAF1)
        Me.Controls.Add(Me.txtCrewPD3)
        Me.Controls.Add(Me.txtCrewPD2)
        Me.Controls.Add(Me.txtCrewPD1)
        Me.Controls.Add(Me.txtCrew3)
        Me.Controls.Add(Me.txtCrew2)
        Me.Controls.Add(Me.txtCrew1)
        Me.Controls.Add(Me.txtDaysAway)
        Me.Controls.Add(Me.txtPerDiem)
        Me.Controls.Add(Me.txtTotalFuel)
        Me.Controls.Add(Me.txtFuelCost)
        Me.Controls.Add(Me.txtRes)
        Me.Controls.Add(Me.txtEorW)
        Me.Controls.Add(Me.txtTotal)
        Me.Controls.Add(Me.txtCalc)
        Me.Controls.Add(Me.txtGal)
        Me.Controls.Add(Me.txtSpeed)
        Me.Controls.Add(Me.txtFuel)
        Me.Controls.Add(Me.cmbAC)
        Me.Controls.Add(Me.txtAC)
        Me.Controls.Add(Me.cmdExit)
        Me.Controls.Add(Me.cmdBack)
        Me.Controls.Add(Me.cmdPrint)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label29)
        Me.Controls.Add(Me.Label28)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Image3)
        Me.Controls.Add(Me.Image2)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Location = New System.Drawing.Point(4, 30)
        Me.Name = "frmBidCalc"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Bid Calculations"
        Me.ResumeLayout(False)

    End Sub
#End Region 
#Region "Upgrade Support "
	Private Shared m_vb6FormDefInstance As frmBidCalc
	Private Shared m_InitializingDefInstance As Boolean
	Public Shared Property DefInstance() As frmBidCalc
		Get
			If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
				m_InitializingDefInstance = True
				m_vb6FormDefInstance = New frmBidCalc()
				m_InitializingDefInstance = False
			End If
			DefInstance = m_vb6FormDefInstance
		End Get
		Set
			m_vb6FormDefInstance = Value
		End Set
	End Property
#End Region 
	Dim ctlCurrent As System.Windows.Forms.Control
	Dim intTAS, intDist, intEorW As Double
	Dim intPerHr, intRes, intAvgCost As Double
	Dim intCS2, intTotalFuel, intCS1, intCS3 As Double
	Dim intPD2, intPD1, intPD3 As Double
	Dim intAF3, intAF1, intAF2, intFC As Double
	Dim intCCost, intLCost, intCComm As Double
	Dim intMU1, intBid, intEE, intMU, intMU2 As Double
	Dim strMU As String
	Dim intInsurance As Short
	Dim intRadio, intTank As Short
	
	Private Sub cmdBack_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdBack.Click
		frmBidCalc1.DefInstance.Show()
		frmBidCalc.DefInstance.Hide()
	End Sub
	
	Private Sub cmdBack_MouseMove(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.MouseEventArgs) Handles cmdBack.MouseMove
		Dim Button As Short = eventArgs.Button \ &H100000
		Dim Shift As Short = System.Windows.Forms.Control.ModifierKeys \ &H10000
		Dim X As Single = VB6.PixelsToTwipsX(eventArgs.X)
		Dim Y As Single = VB6.PixelsToTwipsY(eventArgs.Y)
		
		Image2.Visible = True
		Image3.Visible = False
		
	End Sub
	
	Private Sub cmdExit_MouseMove(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.MouseEventArgs) Handles cmdExit.MouseMove
		Dim Button As Short = eventArgs.Button \ &H100000
		Dim Shift As Short = System.Windows.Forms.Control.ModifierKeys \ &H10000
		Dim X As Single = VB6.PixelsToTwipsX(eventArgs.X)
		Dim Y As Single = VB6.PixelsToTwipsY(eventArgs.Y)
		
		Image2.Visible = False
		Image3.Visible = True
		
	End Sub
	
	Private Sub cmdPrint_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdPrint.Click
		intCrewPD1 = CShort(txtCrewPD1.Text)
		intCrewPD2 = CShort(txtCrewPD2.Text)
		intCrewPD3 = CShort(txtCrewPD3.Text)
		intCrew1 = CShort(txtCrew1.Text)
		intCrew2 = CShort(txtCrew2.Text)
		intCrew3 = CShort(txtCrew3.Text)
		intAF1 = CDbl(txtAF1.Text)
		intAF2 = CDbl(txtAF2.Text)
		intAF3 = CDbl(txtAF3.Text)
		intTotalPD = intCrewPD1 + intCrewPD2 + intCrewPD3
		intTotalSal = intCrew1 + intCrew2 + intCrew3
		intTotalAF = intAF1 + intAF2 + intAF3
		frmBidPrint.DefInstance.Show()
		frmBidCalc.DefInstance.Hide()
	End Sub
	
	Private Sub cmdPrint_MouseMove(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.MouseEventArgs) Handles cmdPrint.MouseMove
		Dim Button As Short = eventArgs.Button \ &H100000
		Dim Shift As Short = System.Windows.Forms.Control.ModifierKeys \ &H10000
		Dim X As Single = VB6.PixelsToTwipsX(eventArgs.X)
		Dim Y As Single = VB6.PixelsToTwipsY(eventArgs.Y)
		
		Image2.Visible = False
		Image3.Visible = False
		
	End Sub
	
	'UPGRADE_WARNING: Form event frmBidCalc.Activate has a new behavior. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2065"'
	Private Sub frmBidCalc_Activated(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Activated
		
		If frmBidCalc1.DefInstance.cmbICAO.Text = "ASSY" Then
			txtOrig.Text = "Sidney"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "AYPY" Then 
			txtOrig.Text = "Port Moresby, PNG"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "BGBW" Then 
			txtOrig.Text = "Narsarsuaq"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "BGGH" Then 
			txtOrig.Text = "Godthab"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "BIRK" Then 
			txtOrig.Text = "Reykjavik"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "CYAM" Then 
			txtOrig.Text = "Sault Ste. Marie"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "CYFB" Then 
			txtOrig.Text = "Iqaluit"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "CYQX" Then 
			txtOrig.Text = "Gander"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "CYYQ" Then 
			txtOrig.Text = "Churchill Falls"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "CYYR" Then 
			txtOrig.Text = "Goose Bay"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "CYYT" Then 
			txtOrig.Text = "St John's, NFLD"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "DAAG" Then 
			txtOrig.Text = "Algiers, Algeria"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "DIAP" Then 
			txtOrig.Text = "Abidjan"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "DNMM" Then 
			txtOrig.Text = "Lagos, Nigeria"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "DRRN" Then 
			txtOrig.Text = "Niami, Niger"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "EBBR" Then 
			txtOrig.Text = "Brussels"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "EDDW" Then 
			txtOrig.Text = "Bremen, Germany"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "EFHK" Then 
			txtOrig.Text = "Helsinki, Finland"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "EGPD" Then 
			txtOrig.Text = "Aberdeen"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "EGPK" Then 
			txtOrig.Text = "Prestwick"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "EHBK" Then 
			txtOrig.Text = "Maastricht, Netherlands"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "EINN" Then 
			txtOrig.Text = "Shannon"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "EKCH" Then 
			txtOrig.Text = "Copenhagen"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "ELLX" Then 
			txtOrig.Text = "Luxembourg"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "ENBR" Then 
			txtOrig.Text = "Bergen, Norway"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "FAGM" Then 
			txtOrig.Text = "Rand"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "FALA" Then 
			txtOrig.Text = "Lanseria, RSA"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "FAWM" Then 
			txtOrig.Text = "Windhoek"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "FCBB" Then 
			txtOrig.Text = "Brazzaville, Congo"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "FEFF" Then 
			txtOrig.Text = "Bangui, CAE"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "FMMI" Then 
			txtOrig.Text = "Antananarivo, Madagascar"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "FNLU" Then 
			txtOrig.Text = "Luanda"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "FOOL" Then 
			txtOrig.Text = "Libreville"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "FSIA" Then 
			txtOrig.Text = "Seychelles Intl"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "FVHA" Then 
			txtOrig.Text = "Harare, Zimbabwe"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "FZNA" Then 
			txtOrig.Text = "Goma, Zaire"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "GBYD" Then 
			txtOrig.Text = "Banjul"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "GCXO" Then 
			txtOrig.Text = "Tenerife"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "GMAA" Then 
			txtOrig.Text = "Agadir"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "GOOY" Then 
			txtOrig.Text = "Dakar"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "HELX" Then 
			txtOrig.Text = "Luxor"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "HKNW" Then 
			txtOrig.Text = "Nairobi-Wilson"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "HSSS" Then 
			txtOrig.Text = "Khartoum"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "HTDA" Then 
			txtOrig.Text = "Dar-Es-Salaam"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "I69" Then 
			txtOrig.Text = "Batavia, OH"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "KANC" Then 
			txtOrig.Text = "Anchorage"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "KBGR" Then 
			txtOrig.Text = "Bangor"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "KBOI" Then 
			txtOrig.Text = "Boise"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "KCAE" Then 
			txtOrig.Text = "Columbia, SC"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "KICT" Then 
			txtOrig.Text = "Wichita, KS"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "KIDP" Then 
			txtOrig.Text = "Independence, KS"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "KJNU" Then 
			txtOrig.Text = "Juneau, AK"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "KMIA" Then 
			txtOrig.Text = "Miami, FL"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "KMSP" Then 
			txtOrig.Text = "Minneapolis, MN"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "KNUD" Then 
			txtOrig.Text = "ADAK, AK"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "KOAK" Then 
			txtOrig.Text = "Oakland, CA"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "KPDK" Then 
			txtOrig.Text = "Atlanta, GA"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "KVRB" Then 
			txtOrig.Text = "Vero Beach"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "LCPH" Then 
			txtOrig.Text = "Larnaca, Cyprus"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "LEMD" Then 
			txtOrig.Text = "Madrid"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "LEMG" Then 
			txtOrig.Text = "Malaga"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "LFPN" Then 
			txtOrig.Text = "Toussus Le Noble"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "LGAT" Then 
			txtOrig.Text = "Athens"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "LGIR" Then 
			txtOrig.Text = "Iraklion"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "LIRA" Then 
			txtOrig.Text = "Rome"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "LKPR" Then 
			txtOrig.Text = "Prague, Czech"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "LPAZ" Then 
			txtOrig.Text = "Santa Maria"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "LPPR" Then 
			txtOrig.Text = "Porto, Portugal"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "LROP" Then 
			txtOrig.Text = "Bucharest, Romania"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "LTAC" Then 
			txtOrig.Text = "Ankara"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "LTBA" Then 
			txtOrig.Text = "Istanbul, Turkey"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "MROC" Then 
			txtOrig.Text = "San Jose, CR"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "NTSU" Then 
			txtOrig.Text = "Pago Pago"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "NZAA" Then 
			txtOrig.Text = "Auckland"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "OOMS" Then 
			txtOrig.Text = "SEEB, Oman"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "OPKC" Then 
			txtOrig.Text = "Karachi"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "PAOM" Then 
			txtOrig.Text = "Nome, AK"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "PGSN" Then 
			txtOrig.Text = "Saipan"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "PHNL" Then 
			txtOrig.Text = "Honolulu, HI"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "PHTO" Then 
			txtOrig.Text = "HILO"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "PKMJ" Then 
			txtOrig.Text = "Majuro"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "PLCH" Then 
			txtOrig.Text = "Christmas Island"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "PMDY" Then 
			txtOrig.Text = "Midway"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "PTRO" Then 
			txtOrig.Text = "Palau"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "PWAK" Then 
			txtOrig.Text = "WAKE"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "RCTP" Then 
			txtOrig.Text = "Chiang Kai Shek"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "RJCK" Then 
			txtOrig.Text = "Kushiro"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "RJTT" Then 
			txtOrig.Text = "Tokyo"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "RKSS" Then 
			txtOrig.Text = "Seoul, Korea"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "RPMM" Then 
			txtOrig.Text = "Manilla"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "SAEZ" Then 
			txtOrig.Text = "Ezeiza"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "SBEG" Then 
			txtOrig.Text = "Manaus"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "SBGL" Then 
			txtOrig.Text = "Rio De Janeiro, Brazil"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "SBSP" Then 
			txtOrig.Text = "Sao Paulo"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "SCEL" Then 
			txtOrig.Text = "Santiago, Chile"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "SVMG" Then 
			txtOrig.Text = "Margarita, VE"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "TTPP" Then 
			txtOrig.Text = "Picaro"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "UHHH" Then 
			txtOrig.Text = "Khabarovsk, Russia"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "UHMM" Then 
			txtOrig.Text = "Magadan, Russia"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "UHPP" Then 
			txtOrig.Text = "Petropavlovsk, Russia"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "UHSS" Then 
			txtOrig.Text = "Yuzhno, Russia"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "UTTT" Then 
			txtOrig.Text = "Tashkent, Russia"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "UUEE" Then 
			txtOrig.Text = "Moscow, Russia"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "VABB" Then 
			txtOrig.Text = "Bombay"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "VCBI" Then 
			txtOrig.Text = "Columbo, Sri Lanka"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "VIDP" Then 
			txtOrig.Text = "Delhi"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "VNKT" Then 
			txtOrig.Text = "Katmandu, Nepal"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "VOMM" Then 
			txtOrig.Text = "Madras"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "VOPB" Then 
			txtOrig.Text = "Port Blair, Nicobar"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "VRMM" Then 
			txtOrig.Text = "Male, Maldives"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "VTBD" Then 
			txtOrig.Text = "Bangkok"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "WMKJ" Then 
			txtOrig.Text = "Johor Bahru, Malaysia"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "WMKK" Then 
			txtOrig.Text = "Kuala Lumpur"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "WSSL" Then 
			txtOrig.Text = "Singapore"
		ElseIf frmBidCalc1.DefInstance.cmbICAO.Text = "ZGGG" Then 
			txtOrig.Text = "Guangzhou"
		Else
			txtOrig.Text = frmBidCalc1.DefInstance.txtOrig.Text
		End If
		
		If frmBidCalc1.DefInstance.txtPort1.Text = "" Then
			txtDest.Text = frmBidCalc1.DefInstance.txtPort.Text
		ElseIf frmBidCalc1.DefInstance.txtPort2.Text = "" Then 
			txtDest.Text = frmBidCalc1.DefInstance.txtPort1.Text
		ElseIf frmBidCalc1.DefInstance.txtPort3.Text = "" Then 
			txtDest.Text = frmBidCalc1.DefInstance.txtPort2.Text
		ElseIf frmBidCalc1.DefInstance.txtPort4.Text = "" Then 
			txtDest.Text = frmBidCalc1.DefInstance.txtPort3.Text
		ElseIf frmBidCalc1.DefInstance.txtPort5.Text = "" Then 
			txtDest.Text = frmBidCalc1.DefInstance.txtPort4.Text
		ElseIf frmBidCalc1.DefInstance.txtPort6.Text = "" Then 
			txtDest.Text = frmBidCalc1.DefInstance.txtPort5.Text
		ElseIf frmBidCalc1.DefInstance.txtPort7.Text = "" Then 
			txtDest.Text = frmBidCalc1.DefInstance.txtPort6.Text
		ElseIf frmBidCalc1.DefInstance.txtPort7.Text <> "" Then 
			txtDest.Text = frmBidCalc1.DefInstance.txtPort7.Text
		End If
		
		If frmBidCalc1.DefInstance.txtTotal1.Text = "" Then
			txtTotal.Text = frmBidCalc1.DefInstance.txtTotal.Text
		ElseIf frmBidCalc1.DefInstance.txtTotal2.Text = "" Then 
			txtTotal.Text = frmBidCalc1.DefInstance.txtTotal1.Text
		ElseIf frmBidCalc1.DefInstance.txtTotal3.Text = "" Then 
			txtTotal.Text = frmBidCalc1.DefInstance.txtTotal2.Text
		ElseIf frmBidCalc1.DefInstance.txtTotal4.Text = "" Then 
			txtTotal.Text = frmBidCalc1.DefInstance.txtTotal3.Text
		ElseIf frmBidCalc1.DefInstance.txtTotal5.Text = "" Then 
			txtTotal.Text = frmBidCalc1.DefInstance.txtTotal4.Text
		ElseIf frmBidCalc1.DefInstance.txtTotal6.Text = "" Then 
			txtTotal.Text = frmBidCalc1.DefInstance.txtTotal5.Text
		ElseIf frmBidCalc1.DefInstance.txtTotal7.Text = "" Then 
			txtTotal.Text = frmBidCalc1.DefInstance.txtTotal6.Text
		ElseIf frmBidCalc1.DefInstance.txtTotal7.Text <> "" Then 
			txtTotal.Text = frmBidCalc1.DefInstance.txtTotal7.Text
		End If
		
		strMU = InputBox("Enter Mileage Markup as Decimal", "Mileage Markup", ".15")
		If strMU = "" Then
			intMU = 0
		Else
			intMU = Val(strMU)
		End If
		intDist = Val(txtTotal.Text)
		intMU2 = intDist * intMU
		intDist = intDist + intMU2
		txtTotal.Text = CStr(intDist)
		txtTotal.Text = VB6.Format(txtTotal.Text, "Fixed")
		
		Call CalcFuel()
		Call CalcBid()
		
	End Sub
	
	Private Sub frmBidCalc_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		
		cmbAC.Items.Add("B-200")
		cmbAC.Items.Add("BE-350")
		cmbAC.Items.Add("BE-400A")
		cmbAC.Items.Add("C-172")
		cmbAC.Items.Add("C-182")
		cmbAC.Items.Add("C-206")
		cmbAC.Items.Add("C-208")
		cmbAC.Items.Add("C-210")
		cmbAC.Items.Add("C-303")
		cmbAC.Items.Add("C-406")
		cmbAC.Items.Add("C-421")
		cmbAC.Items.Add("C-425")
		cmbAC.Items.Add("C-500")
		cmbAC.Items.Add("C-525")
		cmbAC.Items.Add("C-550")
		cmbAC.Items.Add("C-560")
		cmbAC.Items.Add("C-650")
		cmbAC.Items.Add("CE-560-XL")
		cmbAC.Items.Add("CE-750")
		cmbAC.Items.Add("CL-604")
		cmbAC.Items.Add("DHC-6")
		cmbAC.Items.Add("DHC-8-300")
		cmbAC.Items.Add("DO-228")
		cmbAC.Items.Add("DO-328")
		cmbAC.Items.Add("F-20")
		cmbAC.Items.Add("G-1")
		cmbAC.Items.Add("LR-25")
		cmbAC.Items.Add("LR-35")
		cmbAC.Items.Add("PA-28R-201T")
		cmbAC.Items.Add("PA-31-350")
		cmbAC.Items.Add("Other")
		
		'    strMU = InputBox("Enter Mileage Markup as Decimal", "Mileage Markup", ".15")
		'    If strMU = "" Then
		'        intMU = 0
		'    Else
		'        intMU = Val(strMU)
		'    End If
		
	End Sub
	
	'UPGRADE_WARNING: Event cmbAC.SelectedIndexChanged may fire when form is initialized. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2075"'
	Private Sub cmbAC_SelectedIndexChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmbAC.SelectedIndexChanged
		
		If cmbAC.Text = "B-200" Then
			txtFuel.Text = "600"
			txtSpeed.Text = "250"
			txtGal.Text = "6.7"
			txtCalc.Text = CStr(Val(txtFuel.Text) / Val(txtGal.Text))
			txtCalc.Text = VB6.Format(txtCalc.Text, "Fixed")
		ElseIf cmbAC.Text = "BE-350" Then 
			txtFuel.Text = "400"
			txtSpeed.Text = "230"
			txtGal.Text = "6.7"
			txtCalc.Text = CStr(Val(txtFuel.Text) / Val(txtGal.Text))
			txtCalc.Text = VB6.Format(txtCalc.Text, "Fixed")
		ElseIf cmbAC.Text = "BE-400A" Then 
			txtFuel.Text = "940"
			txtSpeed.Text = "399"
			txtGal.Text = "6.7"
			txtCalc.Text = CStr(Val(txtFuel.Text) / Val(txtGal.Text))
			txtCalc.Text = VB6.Format(txtCalc.Text, "Fixed")
		ElseIf cmbAC.Text = "C-172" Then 
			txtFuel.Text = "54"
			txtSpeed.Text = "125"
			txtGal.Text = "6"
			txtCalc.Text = CStr(Val(txtFuel.Text) / Val(txtGal.Text))
			txtCalc.Text = VB6.Format(txtCalc.Text, "Fixed")
		ElseIf cmbAC.Text = "C-182" Then 
			txtFuel.Text = "69"
			txtSpeed.Text = "135"
			txtGal.Text = "6"
			txtCalc.Text = CStr(Val(txtFuel.Text) / Val(txtGal.Text))
			txtCalc.Text = VB6.Format(txtCalc.Text, "Fixed")
		ElseIf cmbAC.Text = "C-206" Then 
			txtFuel.Text = "82"
			txtSpeed.Text = "138"
			txtGal.Text = "6"
			txtCalc.Text = CStr(Val(txtFuel.Text) / Val(txtGal.Text))
			txtCalc.Text = VB6.Format(txtCalc.Text, "Fixed")
		ElseIf cmbAC.Text = "C-208" Then 
			txtFuel.Text = "300"
			txtSpeed.Text = "170"
			txtGal.Text = "6.7"
			txtCalc.Text = CStr(Val(txtFuel.Text) / Val(txtGal.Text))
			txtCalc.Text = VB6.Format(txtCalc.Text, "Fixed")
		ElseIf cmbAC.Text = "C-210" Then 
			txtFuel.Text = "82"
			txtSpeed.Text = "162"
			txtGal.Text = "6"
			txtCalc.Text = CStr(Val(txtFuel.Text) / Val(txtGal.Text))
			txtCalc.Text = VB6.Format(txtCalc.Text, "Fixed")
		ElseIf cmbAC.Text = "C-303" Then 
			txtFuel.Text = "147"
			txtSpeed.Text = "170"
			txtGal.Text = "6"
			txtCalc.Text = CStr(Val(txtFuel.Text) / Val(txtGal.Text))
			txtCalc.Text = VB6.Format(txtCalc.Text, "Fixed")
		ElseIf cmbAC.Text = "C-406" Then 
			txtFuel.Text = "425"
			txtSpeed.Text = "176"
			txtGal.Text = "6.7"
			txtCalc.Text = CStr(Val(txtFuel.Text) / Val(txtGal.Text))
			txtCalc.Text = VB6.Format(txtCalc.Text, "Fixed")
		ElseIf cmbAC.Text = "C-421" Then 
			txtFuel.Text = "300"
			txtSpeed.Text = "218"
			txtGal.Text = "6"
			txtCalc.Text = CStr(Val(txtFuel.Text) / Val(txtGal.Text))
			txtCalc.Text = VB6.Format(txtCalc.Text, "Fixed")
		ElseIf cmbAC.Text = "C-425" Then 
			txtFuel.Text = "350"
			txtSpeed.Text = "210"
			txtGal.Text = "6.7"
			txtCalc.Text = CStr(Val(txtFuel.Text) / Val(txtGal.Text))
			txtCalc.Text = VB6.Format(txtCalc.Text, "Fixed")
		ElseIf cmbAC.Text = "C-500" Then 
			txtFuel.Text = "800"
			txtSpeed.Text = "310"
			txtGal.Text = "6.7"
			txtCalc.Text = CStr(Val(txtFuel.Text) / Val(txtGal.Text))
			txtCalc.Text = VB6.Format(txtCalc.Text, "Fixed")
		ElseIf cmbAC.Text = "C-525" Then 
			txtFuel.Text = "675"
			txtSpeed.Text = "347"
			txtGal.Text = "6.7"
			txtCalc.Text = CStr(Val(txtFuel.Text) / Val(txtGal.Text))
			txtCalc.Text = VB6.Format(txtCalc.Text, "Fixed")
		ElseIf cmbAC.Text = "C-550" Then 
			txtFuel.Text = "950"
			txtSpeed.Text = "350"
			txtGal.Text = "6.7"
			txtCalc.Text = CStr(Val(txtFuel.Text) / Val(txtGal.Text))
			txtCalc.Text = VB6.Format(txtCalc.Text, "Fixed")
		ElseIf cmbAC.Text = "C-560" Then 
			txtFuel.Text = "900"
			txtSpeed.Text = "350"
			txtGal.Text = "6.7"
			txtCalc.Text = CStr(Val(txtFuel.Text) / Val(txtGal.Text))
			txtCalc.Text = VB6.Format(txtCalc.Text, "Fixed")
		ElseIf cmbAC.Text = "C-650" Then 
			txtFuel.Text = "1223"
			txtSpeed.Text = "416"
			txtGal.Text = "6.7"
			txtCalc.Text = CStr(Val(txtFuel.Text) / Val(txtGal.Text))
			txtCalc.Text = VB6.Format(txtCalc.Text, "Fixed")
		ElseIf cmbAC.Text = "CE-560-XL" Then 
			txtFuel.Text = "1143"
			txtSpeed.Text = "403"
			txtGal.Text = "6.7"
			txtCalc.Text = CStr(Val(txtFuel.Text) / Val(txtGal.Text))
			txtCalc.Text = VB6.Format(txtCalc.Text, "Fixed")
		ElseIf cmbAC.Text = "CE-750" Then 
			txtFuel.Text = "1667"
			txtSpeed.Text = "463"
			txtGal.Text = "6.7"
			txtCalc.Text = CStr(Val(txtFuel.Text) / Val(txtGal.Text))
			txtCalc.Text = VB6.Format(txtCalc.Text, "Fixed")
		ElseIf cmbAC.Text = "CL-604" Then 
			txtFuel.Text = "1840"
			txtSpeed.Text = "419"
			txtGal.Text = "6.7"
			txtCalc.Text = CStr(Val(txtFuel.Text) / Val(txtGal.Text))
			txtCalc.Text = VB6.Format(txtCalc.Text, "Fixed")
		ElseIf cmbAC.Text = "DHC-6" Then 
			txtFuel.Text = "655"
			txtSpeed.Text = "182"
			txtGal.Text = "6.7"
			txtCalc.Text = CStr(Val(txtFuel.Text) / Val(txtGal.Text))
			txtCalc.Text = VB6.Format(txtCalc.Text, "Fixed")
		ElseIf cmbAC.Text = "DHC-8-300" Then 
			txtFuel.Text = "1000"
			txtSpeed.Text = "248"
			txtGal.Text = "6.7"
			txtCalc.Text = CStr(Val(txtFuel.Text) / Val(txtGal.Text))
			txtCalc.Text = VB6.Format(txtCalc.Text, "Fixed")
		ElseIf cmbAC.Text = "DO-228" Then 
			txtFuel.Text = "750"
			txtSpeed.Text = "220"
			txtGal.Text = "6.7"
			txtCalc.Text = CStr(Val(txtFuel.Text) / Val(txtGal.Text))
			txtCalc.Text = VB6.Format(txtCalc.Text, "Fixed")
		ElseIf cmbAC.Text = "DO-328" Then 
			txtFuel.Text = "1350"
			txtSpeed.Text = "300"
			txtGal.Text = "6.7"
			txtCalc.Text = CStr(Val(txtFuel.Text) / Val(txtGal.Text))
			txtCalc.Text = VB6.Format(txtCalc.Text, "Fixed")
		ElseIf cmbAC.Text = "F-20" Then 
			txtFuel.Text = "1685"
			txtSpeed.Text = "374"
			txtGal.Text = "6.7"
			txtCalc.Text = CStr(Val(txtFuel.Text) / Val(txtGal.Text))
			txtCalc.Text = VB6.Format(txtCalc.Text, "Fixed")
		ElseIf cmbAC.Text = "G-1" Then 
			txtFuel.Text = "1650"
			txtSpeed.Text = "275"
			txtGal.Text = "6.7"
			txtCalc.Text = CStr(Val(txtFuel.Text) / Val(txtGal.Text))
			txtCalc.Text = VB6.Format(txtCalc.Text, "Fixed")
		ElseIf cmbAC.Text = "LR-25" Then 
			txtFuel.Text = "1500"
			txtSpeed.Text = "400"
			txtGal.Text = "6.7"
			txtCalc.Text = CStr(Val(txtFuel.Text) / Val(txtGal.Text))
			txtCalc.Text = VB6.Format(txtCalc.Text, "Fixed")
		ElseIf cmbAC.Text = "LR-35" Then 
			txtFuel.Text = "1000"
			txtSpeed.Text = "424"
			txtGal.Text = "6.7"
			txtCalc.Text = CStr(Val(txtFuel.Text) / Val(txtGal.Text))
			txtCalc.Text = VB6.Format(txtCalc.Text, "Fixed")
		ElseIf cmbAC.Text = "PA-28R-201T" Then 
			txtFuel.Text = "70"
			txtSpeed.Text = "140"
			txtGal.Text = "6"
			txtCalc.Text = CStr(Val(txtFuel.Text) / Val(txtGal.Text))
			txtCalc.Text = VB6.Format(txtCalc.Text, "Fixed")
		ElseIf cmbAC.Text = "PA-31-350" Then 
			txtFuel.Text = "185"
			txtSpeed.Text = "168"
			txtGal.Text = "6"
			txtCalc.Text = CStr(Val(txtFuel.Text) / Val(txtGal.Text))
			txtCalc.Text = VB6.Format(txtCalc.Text, "Fixed")
		ElseIf cmbAC.Text = "Other" Then 
			cmbAC.Visible = False
			txtAC.Text = InputBox("Enter Aircraft Model.", "Other Aircraft")
			txtFuel.Text = InputBox("Enter Total Fuel in Pounds.", "Other Aircraft")
			txtSpeed.Text = InputBox("Enter Aircraft TAS.", "Other Aircraft")
			txtGal.Text = InputBox("Enter Fuel Calculation (AvGas = 6, Jet = 6.7). ", "Other Aircraft")
			txtCalc.Text = CStr(Val(txtFuel.Text) / Val(txtGal.Text))
			txtCalc.Text = VB6.Format(txtCalc.Text, "Fixed")
			'        frmOther.Show
			'        txtCalc.Text = Format(txtCalc.Text, "Fixed")
		End If
		
		If cmbAC.Text <> "Other" Then
			txtAC.Text = cmbAC.Text
		End If
		
		Call CalcFuel()
		Call CalcBid()
		txtEorW.Focus()
		
	End Sub
	
	Private Sub cmdExit_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdExit.Click
		End
	End Sub
	
	'UPGRADE_WARNING: Form event frmBidCalc.Unload has a new behavior. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2065"'
	Private Sub frmBidCalc_Closed(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Closed
		End
	End Sub
	
	Private Sub txtAC_DoubleClick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtAC.DoubleClick
		cmbAC.Text = ""
		cmbAC.Visible = True
	End Sub
	
	Private Sub txtAF1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtAF1.Enter
		txtAF1.SelectionStart = 0
		txtAF1.SelectionLength = Len(txtAF1.Text)
	End Sub
	
	Private Sub txtAF1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtAF1.Leave
		txtAF1.Text = VB6.Format(txtAF1.Text, "Fixed")
		Call CalcBid()
	End Sub
	
	Private Sub txtAF2_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtAF2.Enter
		txtAF2.SelectionStart = 0
		txtAF2.SelectionLength = Len(txtAF2.Text)
	End Sub
	
	Private Sub txtAF2_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtAF2.Leave
		txtAF2.Text = VB6.Format(txtAF2.Text, "Fixed")
		Call CalcBid()
	End Sub
	
	Private Sub txtAF3_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtAF3.Enter
		txtAF3.SelectionStart = 0
		txtAF3.SelectionLength = Len(txtAF3.Text)
	End Sub
	
	Private Sub txtAF3_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtAF3.Leave
		txtAF3.Text = VB6.Format(txtAF3.Text, "Fixed")
		Call CalcBid()
	End Sub
	
	Private Sub txtBidTotal_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtBidTotal.Enter
		txtBidTotal.SelectionStart = 0
		txtBidTotal.SelectionLength = Len(txtBidTotal.Text)
	End Sub
	
	Private Sub txtCalc_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtCalc.Enter
		txtCalc.SelectionStart = 0
		txtCalc.SelectionLength = Len(txtCalc.Text)
	End Sub
	
	Private Sub txtCrew1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtCrew1.Enter
		txtCrew1.SelectionStart = 0
		txtCrew1.SelectionLength = Len(txtCrew1.Text)
	End Sub
	
	Private Sub txtCrew1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtCrew1.Leave
		txtCrew1.Text = VB6.Format(txtCrew1.Text, "Fixed")
		Call CalcBid()
	End Sub
	
	Private Sub txtCrew2_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtCrew2.Enter
		txtCrew2.SelectionStart = 0
		txtCrew2.SelectionLength = Len(txtCrew2.Text)
	End Sub
	
	Private Sub txtCrew2_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtCrew2.Leave
		txtCrew2.Text = VB6.Format(txtCrew2.Text, "Fixed")
		If txtCrew2.Text <> "0.00" Then
			txtCrewPD2.Text = txtCrewPD1.Text
			txtAF2.Focus()
		End If
		Call CalcBid()
	End Sub
	
	Private Sub txtCrew3_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtCrew3.Enter
		txtCrew3.SelectionStart = 0
		txtCrew3.SelectionLength = Len(txtCrew3.Text)
	End Sub
	
	Private Sub txtCrew3_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtCrew3.Leave
		txtCrew3.Text = VB6.Format(txtCrew3.Text, "Fixed")
		If txtCrew3.Text <> "0.00" Then
			txtCrewPD3.Text = txtCrewPD1.Text
			txtAF3.Focus()
		End If
		Call CalcBid()
	End Sub
	
	Private Sub txtCrewPD1_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtCrewPD1.Enter
		txtCrewPD1.SelectionStart = 0
		txtCrewPD1.SelectionLength = Len(txtCrewPD1.Text)
	End Sub
	
	Private Sub txtCrewPD1_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtCrewPD1.Leave
		txtCrewPD1.Text = VB6.Format(txtCrewPD1.Text, "Fixed")
		Call CalcBid()
	End Sub
	
	Private Sub txtCrewPD2_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtCrewPD2.Enter
		txtCrewPD2.SelectionStart = 0
		txtCrewPD2.SelectionLength = Len(txtCrewPD2.Text)
	End Sub
	
	Private Sub txtCrewPD2_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtCrewPD2.Leave
		txtCrewPD2.Text = VB6.Format(txtCrewPD2.Text, "Fixed")
		Call CalcBid()
	End Sub
	
	Private Sub txtCrewPD3_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtCrewPD3.Enter
		txtCrewPD3.SelectionStart = 0
		txtCrewPD3.SelectionLength = Len(txtCrewPD3.Text)
	End Sub
	
	Private Sub txtCrewPD3_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtCrewPD3.Leave
		txtCrewPD3.Text = VB6.Format(txtCrewPD3.Text, "Fixed")
		Call CalcBid()
	End Sub
	
	Private Sub txtCustComm_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtCustComm.Enter
		txtCustComm.SelectionStart = 0
		txtCustComm.SelectionLength = Len(txtCustComm.Text)
	End Sub
	
	Private Sub txtCustComm_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtCustComm.Leave
		txtCustComm.Text = VB6.Format(txtCustComm.Text, "Fixed")
		Call CalcBid()
	End Sub
	
	Private Sub txtCustoms_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtCustoms.Enter
		txtCustoms.SelectionStart = 0
		txtCustoms.SelectionLength = Len(txtCustoms.Text)
	End Sub
	
	Private Sub txtCustoms_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtCustoms.Leave
		txtCustoms.Text = VB6.Format(txtCustoms.Text, "Fixed")
		Call CalcBid()
	End Sub
	
	Private Sub txtDaysAway_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtDaysAway.Enter
		txtDaysAway.SelectionStart = 0
		txtDaysAway.SelectionLength = Len(txtDaysAway.Text)
	End Sub
	
	Private Sub txtDaysAway_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtDaysAway.Leave
		txtCrewPD1.Text = CStr(Val(txtPerDiem.Text) * Val(txtDaysAway.Text))
		txtCrewPD1.Text = VB6.Format(txtCrewPD1.Text, "Fixed")
		Call CalcBid()
	End Sub
	
	Private Sub txtDest_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtDest.Enter
		txtDest.SelectionStart = 0
		txtDest.SelectionLength = Len(txtDest.Text)
	End Sub
	
	Private Sub txtEorW_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtEorW.Enter
		txtEorW.SelectionStart = 0
		txtEorW.SelectionLength = Len(txtEorW.Text)
	End Sub
	
	Private Sub txtEorW_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtEorW.Leave
		Call CalcFuel()
		Call CalcBid()
	End Sub
	
	Private Sub txtER_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtER.Enter
		txtER.SelectionStart = 0
		txtER.SelectionLength = Len(txtER.Text)
	End Sub
	
	Private Sub txtER_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtER.Leave
		txtER.Text = VB6.Format(txtER.Text, "Fixed")
		Call CalcBid()
	End Sub
	
	Private Sub txtFuel_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtFuel.Enter
		txtFuel.SelectionStart = 0
		txtFuel.SelectionLength = Len(txtFuel.Text)
	End Sub
	
	Private Sub txtFuel_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtFuel.Leave
		Call CalcBid()
	End Sub
	
	Private Sub txtFuelCost_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtFuelCost.Enter
		txtFuelCost.SelectionStart = 0
		txtFuelCost.SelectionLength = Len(txtFuelCost.Text)
	End Sub
	
	Private Sub txtFuelCost_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtFuelCost.Leave
		Call CalcFuel()
		Call CalcBid()
		txtPerDiem.Focus()
	End Sub
	
	Private Sub txtGal_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtGal.Enter
		txtGal.SelectionStart = 0
		txtGal.SelectionLength = Len(txtGal.Text)
	End Sub
	
	Private Sub txtGal_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtGal.Leave
		Call CalcBid()
	End Sub
	
	Private Sub txtInsurance_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtInsurance.Enter
		txtInsurance.SelectionStart = 0
		txtInsurance.SelectionLength = Len(txtInsurance.Text)
	End Sub
	
	Private Sub txtInsurance_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtInsurance.Leave
		txtInsurance.Text = VB6.Format(txtInsurance.Text, "Fixed")
		Call CalcIns()
		Call CalcBid()
	End Sub
	
	Private Sub txtLanding_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtLanding.Enter
		txtLanding.SelectionStart = 0
		txtLanding.SelectionLength = Len(txtLanding.Text)
	End Sub
	
	Private Sub txtLanding_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtLanding.Leave
		txtLanding.Text = VB6.Format(txtLanding.Text, "Fixed")
		Call CalcBid()
	End Sub
	
	Private Sub txtMU_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtMU.Enter
		txtMU.SelectionStart = 0
		txtMU.SelectionLength = Len(txtMU.Text)
	End Sub
	
	Private Sub txtMU_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtMU.Leave
		Call CalcBid()
	End Sub
	
	Private Sub txtOrig_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtOrig.Enter
		txtOrig.SelectionStart = 0
		txtOrig.SelectionLength = Len(txtOrig.Text)
	End Sub
	
	Private Sub txtPerDiem_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtPerDiem.Enter
		txtPerDiem.SelectionStart = 0
		txtPerDiem.SelectionLength = Len(txtPerDiem.Text)
	End Sub
	
	Private Sub txtPerDiem_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtPerDiem.Leave
		txtPerDiem.Text = VB6.Format(txtPerDiem.Text, "Fixed")
		Call CalcBid()
	End Sub
	
	Private Sub txtRadio_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtRadio.Enter
		txtRadio.SelectionStart = 0
		txtRadio.SelectionLength = Len(txtRadio.Text)
	End Sub
	
	Private Sub txtRadio_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtRadio.Leave
		txtRadio.Text = VB6.Format(txtRadio.Text, "Fixed")
		Call CalcBid()
	End Sub
	
	Private Sub txtRes_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtRes.Enter
		txtRes.SelectionStart = 0
		txtRes.SelectionLength = Len(txtRes.Text)
	End Sub
	
	Private Sub txtRes_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtRes.Leave
		Call CalcFuel()
		Call CalcBid()
	End Sub
	
	Private Sub txtSpeed_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtSpeed.Enter
		txtSpeed.SelectionStart = 0
		txtSpeed.SelectionLength = Len(txtSpeed.Text)
	End Sub
	
	Private Sub txtSpeed_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtSpeed.Leave
		Call CalcBid()
	End Sub
	
	Private Sub txtTank_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtTank.Enter
		txtTank.SelectionStart = 0
		txtTank.SelectionLength = Len(txtTank.Text)
	End Sub
	
	Private Sub txtTank_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtTank.Leave
		txtTank.Text = VB6.Format(txtTank.Text, "Fixed")
		Call CalcBid()
	End Sub
	
	Private Sub txtTotal_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtTotal.Enter
		txtTotal.SelectionStart = 0
		txtTotal.SelectionLength = Len(txtTotal.Text)
	End Sub
	
	Private Sub txtTotal_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtTotal.Leave
		Call CalcBid()
	End Sub
	
	Private Sub txtTotalFuel_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtTotalFuel.Enter
		txtTotalFuel.SelectionStart = 0
		txtTotalFuel.SelectionLength = Len(txtTotalFuel.Text)
	End Sub
	
	Private Sub txtTotalFuel_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtTotalFuel.Leave
		Call CalcBid()
	End Sub
	
	Private Sub txtTotalFuelCost_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtTotalFuelCost.Enter
		txtTotalFuelCost.SelectionStart = 0
		txtTotalFuelCost.SelectionLength = Len(txtTotalFuelCost.Text)
	End Sub
	
	Private Sub txtTotalFuelCost_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtTotalFuelCost.Leave
		txtTotalFuelCost.Text = VB6.Format(txtTotalFuelCost.Text, "Fixed")
		Call CalcBid()
	End Sub
	
	Private Sub CalcBid()
		
		txtBidTotal.Text = ""
		intTotalFuel = CDbl(txtTotalFuel.Text)
		intAvgCost = CDbl(txtFuelCost.Text)
		txtTotalFuelCost.Text = CStr(intTotalFuel * intAvgCost)
		txtTotalFuelCost.Text = VB6.Format(txtTotalFuelCost.Text, "Fixed")
		intCS1 = CDbl(txtCrew1.Text)
		intCS2 = CDbl(txtCrew2.Text)
		intCS3 = CDbl(txtCrew3.Text)
		intPD1 = CDbl(txtCrewPD1.Text)
		intPD2 = CDbl(txtCrewPD2.Text)
		intPD3 = CDbl(txtCrewPD3.Text)
		intAF1 = CDbl(txtAF1.Text)
		intAF2 = CDbl(txtAF2.Text)
		intAF3 = CDbl(txtAF3.Text)
		intInsurance = CShort(txtInsurance.Text)
		intFC = CDbl(txtTotalFuelCost.Text)
		intLCost = CDbl(txtLanding.Text)
		intCCost = CDbl(txtCustoms.Text)
		intCComm = CDbl(txtCustComm.Text)
		intEE = CDbl(txtER.Text)
		intRadio = CShort(txtRadio.Text)
		intTank = CShort(txtTank.Text)
		intMU1 = CDbl(txtMU.Text)
		
		intBid = intCS1 + intCS2 + intCS3 + intPD1 + intPD2 + intPD3 + intAF1 + intAF2 + intAF3 + intFC + intLCost + intCCost + intCComm + intEE + intRadio + intTank
		intMU1 = intMU1 * intBid
		intBid = intBid + intMU1
		txtBidTotal.Text = CStr(intBid)
		txtBidTotal.Text = VB6.Format(txtBidTotal.Text, "Fixed")
		If txtInsurance.Text <> "0.00" Then
			Call CalcIns()
		End If
		
	End Sub
	
	Private Sub CalcFuel()
		
		intDist = Val(txtTotal.Text)
		intTAS = Val(txtSpeed.Text)
		intEorW = Val(txtEorW.Text)
		intRes = Val(txtRes.Text)
		intPerHr = Val(txtCalc.Text)
		txtTotalFuel.Text = CStr((intDist / (intTAS + intEorW) + intRes) * intPerHr)
		txtTotalFuel.Text = VB6.Format(txtTotalFuel.Text, "Fixed")
		txtFuelCost.Text = VB6.Format(txtFuelCost.Text, "Fixed")
		intTotalFuel = CDbl(txtTotalFuel.Text)
		intAvgCost = CDbl(txtFuelCost.Text)
		txtTotalFuelCost.Text = CStr(intTotalFuel * intAvgCost)
		txtTotalFuelCost.Text = VB6.Format(txtTotalFuelCost.Text, "Fixed")
		
	End Sub
	
	Private Sub CalcIns()
		
		intInsurance = CShort(txtInsurance.Text)
		txtBidInsTotal.Text = CStr(intBid + intInsurance)
		txtBidInsTotal.Text = VB6.Format(txtBidInsTotal.Text, "Fixed")
		txtInsurance.Text = CStr(intInsurance)
		txtInsurance.Text = VB6.Format(txtInsurance.Text, "Fixed")
		
	End Sub
End Class